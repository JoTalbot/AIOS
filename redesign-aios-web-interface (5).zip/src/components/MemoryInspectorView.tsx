'use client';

import React, { useState } from 'react';
import {
  Brain,
  Search,
  Plus,
  Trash2,
  Tag,
  Key,
  Database,
  Layers,
  Sparkles
} from 'lucide-react';

interface MemoryInspectorViewProps {
  memories: any[];
  agents: any[];
  onAddMemory: (memData: any) => void;
  onDeleteMemory: (memId: number) => void;
}

export default function MemoryInspectorView({
  memories,
  agents,
  onAddMemory,
  onDeleteMemory,
}: MemoryInspectorViewProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeType, setActiveType] = useState('all');
  const [modalOpen, setModalOpen] = useState(false);

  const [formData, setFormData] = useState({
    agentId: '',
    memoryType: 'semantic_kv',
    key: '',
    value: '',
    relevanceScore: 0.9,
  });

  const filteredMemories = memories.filter((m) => {
    const matchesType = activeType === 'all' || m.memoryType === activeType;
    const matchesSearch = searchQuery === '' ||
      m.key.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.value.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesType && matchesSearch;
  });

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAddMemory({
      ...formData,
      agentId: formData.agentId ? Number(formData.agentId) : null,
      relevanceScore: Number(formData.relevanceScore),
    });
    setModalOpen(false);
    setFormData({
      agentId: '',
      memoryType: 'semantic_kv',
      key: '',
      value: '',
      relevanceScore: 0.9,
    });
  };

  return (
    <div className="p-4 lg:p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight flex items-center space-x-2">
            <Brain className="w-5 h-5 text-indigo-400" />
            <span>AIOS Kernel Vector Memory & RAG Inspector</span>
          </h1>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Episodic memory store, long-term knowledge retention, and semantic key-value context.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search memory key or value..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9 pr-4 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs font-mono text-slate-200 focus:border-cyan-500 focus:outline-none w-64"
            />
          </div>

          <button
            onClick={() => setModalOpen(true)}
            className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold flex items-center space-x-2 shadow-lg shadow-indigo-600/20 transition-all cursor-pointer shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>Store Memory Slot</span>
          </button>
        </div>
      </div>

      {/* Type Filter Pills */}
      <div className="flex items-center space-x-2 border-b border-slate-800/80 pb-3">
        {['all', 'semantic_kv', 'long_term', 'short_term', 'episodic'].map((t) => (
          <button
            key={t}
            onClick={() => setActiveType(t)}
            className={`px-3 py-1.5 rounded-xl text-xs font-mono uppercase transition-all cursor-pointer border ${
              activeType === t
                ? 'bg-indigo-950 text-indigo-300 border-indigo-700 font-bold'
                : 'bg-slate-900/60 text-slate-400 border-slate-800 hover:text-slate-200'
            }`}
          >
            {t.replace('_', ' ')}
          </button>
        ))}
      </div>

      {/* Memory Slots Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredMemories.map((mem) => (
          <div
            key={mem.id}
            className="glass-panel p-5 rounded-2xl border border-slate-800 hover:border-indigo-800/60 transition-all flex flex-col justify-between space-y-3"
          >
            <div className="space-y-2">
              <div className="flex items-start justify-between">
                <div className="flex items-center space-x-2">
                  <span className="text-xl">{mem.agentAvatar || '🧠'}</span>
                  <div>
                    <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-indigo-950 text-indigo-300 border border-indigo-800">
                      {mem.memoryType}
                    </span>
                    <p className="text-[10px] font-mono text-slate-500 mt-0.5">{mem.agentName || 'Global System'}</p>
                  </div>
                </div>

                <button
                  onClick={() => onDeleteMemory(mem.id)}
                  className="text-slate-600 hover:text-rose-400 transition-colors p-1 cursor-pointer"
                  title="Purge Memory Slot"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 space-y-1">
                <span className="text-[10px] font-mono text-cyan-400 block font-semibold">
                  KEY: {mem.key}
                </span>
                <p className="text-xs text-slate-200 font-mono whitespace-pre-wrap leading-relaxed">
                  {mem.value}
                </p>
              </div>
            </div>

            <div className="border-t border-slate-800/80 pt-2 flex items-center justify-between text-[10px] font-mono text-slate-400">
              <span>Relevance: <strong className="text-indigo-300">{(mem.relevanceScore * 100).toFixed(0)}%</strong></span>
              <span>Hits: <strong className="text-amber-300">{mem.accessCount}</strong></span>
            </div>
          </div>
        ))}

        {filteredMemories.length === 0 && (
          <div className="col-span-full py-12 text-center text-slate-500 font-mono space-y-2">
            <Brain className="w-10 h-10 mx-auto text-slate-600" />
            <p>No memory records found.</p>
          </div>
        )}
      </div>

      {/* Modal: Store Memory */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="glass-panel p-6 rounded-2xl border border-slate-800 w-full max-w-md space-y-4">
            <h2 className="text-base font-bold text-white flex items-center space-x-2">
              <Brain className="w-5 h-5 text-indigo-400" />
              <span>Insert Vector Memory Slot</span>
            </h2>

            <form onSubmit={handleFormSubmit} className="space-y-3 font-mono text-xs">
              <div>
                <label className="block text-slate-300 mb-1">Target Agent</label>
                <select
                  value={formData.agentId}
                  onChange={(e) => setFormData({ ...formData, agentId: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 focus:border-indigo-500 focus:outline-none"
                >
                  <option value="">Global System Memory</option>
                  {agents.map((a) => (
                    <option key={a.id} value={a.id}>
                      {a.avatar} {a.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 mb-1">Memory Type</label>
                  <select
                    value={formData.memoryType}
                    onChange={(e) => setFormData({ ...formData, memoryType: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 focus:border-indigo-500 focus:outline-none"
                  >
                    <option value="semantic_kv">Semantic KV</option>
                    <option value="long_term">Long-Term Context</option>
                    <option value="short_term">Short-Term Buffer</option>
                    <option value="episodic">Episodic Trace</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 mb-1">Relevance Score</label>
                  <input
                    type="number"
                    step="0.05"
                    min="0"
                    max="1"
                    value={formData.relevanceScore}
                    onChange={(e) => setFormData({ ...formData, relevanceScore: Number(e.target.value) })}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 focus:border-indigo-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Memory Key *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. system_database_schema_cache"
                  value={formData.key}
                  onChange={(e) => setFormData({ ...formData, key: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 focus:border-indigo-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Memory Value Context *</label>
                <textarea
                  rows={3}
                  required
                  placeholder="Vector embedding text content..."
                  value={formData.value}
                  onChange={(e) => setFormData({ ...formData, value: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 focus:border-indigo-500 focus:outline-none font-mono"
                />
              </div>

              <div className="flex items-center justify-end space-x-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-900 text-slate-400 hover:text-slate-200 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold shadow-lg cursor-pointer"
                >
                  Save Vector
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
