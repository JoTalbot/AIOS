import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { agentMemories } from '@/db/schema';
import { eq } from 'drizzle-orm';

export async function DELETE(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const memId = parseInt(id, 10);
    if (isNaN(memId)) {
      return NextResponse.json({ success: false, error: 'Invalid memory ID' }, { status: 400 });
    }

    await db.delete(agentMemories).where(eq(agentMemories.id, memId));
    return NextResponse.json({ success: true, message: 'Memory deleted' });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error?.message || 'Failed to delete memory' }, { status: 500 });
  }
}
