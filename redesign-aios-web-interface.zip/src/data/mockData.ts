import { toRoman } from "../lib/format";
import type {
  PlatformInfo,
  AgentProfile,
  ConstitutionArticle,
  AndroidDevice,
  ServiceInfo,
  OlxAd,
  OlxSummary,
  AuditEvent,
  SafetyData,
  MLModelInfo,
  KnowledgeGraphData,
  ApiKey,
  Webhook,
  Backup,
  Subscription,
} from "../types";

export function makeSeries(seed: number, len = 24, base = 60, amp = 40): number[] {
  const out: number[] = [];
  let v = base;
  let s = (seed % 23) + 1;
  for (let i = 0; i < len; i++) {
    s = (s * 9301 + 49297) % 233280;
    const rnd = s / 233280;
    v = Math.max(2, base + Math.sin(i / 3 + seed) * amp * 0.4 + (rnd - 0.5) * amp);
    out.push(Math.round(v));
  }
  return out;
}

export const PLATFORMS: PlatformInfo[] = [
  { id: "olx", name: "OLX.ua", package: "ua.slando", status: "full", emoji: "🟢", color: "#22c55e", profiles: 48, actionsToday: 1284, successRate: 99.2, region: "Kyiv", trend: makeSeries(3, 18, 50, 40) },
  { id: "instagram", name: "Instagram", package: "com.instagram.android", status: "full", emoji: "📷", color: "#e1306c", profiles: 32, actionsToday: 842, successRate: 97.8, region: "EU-West", trend: makeSeries(7, 18, 40, 38) },
  { id: "facebook", name: "Facebook", package: "com.facebook.katana", status: "full", emoji: "🔵", color: "#1877f2", profiles: 27, actionsToday: 615, successRate: 96.4, region: "EU-West", trend: makeSeries(11, 18, 35, 34) },
  { id: "tiktok", name: "TikTok", package: "com.zhiliaoapp.musically", status: "collector", emoji: "🎵", color: "#00f2ea", profiles: 18, actionsToday: 408, successRate: 94.1, region: "Global", trend: makeSeries(5, 18, 30, 30) },
  { id: "whatsapp", name: "WhatsApp", package: "com.whatsapp", status: "messaging", emoji: "💬", color: "#25d366", profiles: 54, actionsToday: 2210, successRate: 99.6, region: "EU-West", trend: makeSeries(9, 18, 60, 36) },
  { id: "viber", name: "Viber", package: "com.viber.voip", status: "messaging", emoji: "📞", color: "#7360f2", profiles: 39, actionsToday: 1376, successRate: 98.9, region: "EU-East", trend: makeSeries(13, 18, 45, 30) },
  { id: "prom", name: "Prom.ua", package: "com.prom.ua", status: "scaffold", emoji: "🛍️", color: "#f59e0b", profiles: 6, actionsToday: 92, successRate: 88.0, region: "Kyiv", trend: makeSeries(17, 18, 18, 18) },
  { id: "bigl", name: "Bigl.ua", package: "com.bigl.ua", status: "scaffold", emoji: "🧱", color: "#fb923c", profiles: 4, actionsToday: 51, successRate: 85.5, region: "Kyiv", trend: makeSeries(21, 18, 14, 14) },
  { id: "shafa", name: "Shafa.ua", package: "com.shafa.ua", status: "scaffold", emoji: "👗", color: "#ec4899", profiles: 5, actionsToday: 73, successRate: 86.7, region: "Kyiv", trend: makeSeries(25, 18, 16, 16) },
];

export const AGENTS: AgentProfile[] = [
  { agent_id: "orchestrator", name: "Maestro", role: "Lead Orchestrator", autonomy: 5, autonomy_label: "L5 · Supervised Autonomous", status: "executing", current_task: "Coordinating 3-platform publish pipeline", completed_tasks: 4821, platform: "cross", load: 74, trend: makeSeries(1, 16, 60, 30) },
  { agent_id: "scout", name: "Scout-α", role: "Marketplace Scout", autonomy: 4, autonomy_label: "L4 · High Autonomy", status: "executing", current_task: "Scanning OLX listings for iPhone 15 Pro", completed_tasks: 2190, platform: "olx", load: 58, trend: makeSeries(4, 16, 50, 26) },
  { agent_id: "scribe", name: "Scribe", role: "Content Composer", autonomy: 3, autonomy_label: "L3 · Conditional", status: "thinking", current_task: "Drafting listing copy (awaiting approval)", completed_tasks: 1340, platform: "instagram", load: 33, trend: makeSeries(8, 16, 40, 24) },
  { agent_id: "echo", name: "Echo", role: "Messaging Relay", autonomy: 4, autonomy_label: "L4 · High Autonomy", status: "executing", current_task: "Auto-replying to 14 WhatsApp inquiries", completed_tasks: 5612, platform: "whatsapp", load: 81, trend: makeSeries(12, 16, 70, 28) },
  { agent_id: "warden", name: "Warden", role: "Compliance Guardian", autonomy: 2, autonomy_label: "L2 · Advisory", status: "executing", current_task: "Validating 67 constitutional articles", completed_tasks: 9844, platform: "cross", load: 22, trend: makeSeries(16, 16, 30, 16) },
  { agent_id: "forager", name: "Forager", role: "Data Collector", autonomy: 4, autonomy_label: "L4 · High Autonomy", status: "executing", current_task: "Harvesting TikTok creator metrics", completed_tasks: 1872, platform: "tiktok", load: 47, trend: makeSeries(20, 16, 45, 24) },
  { agent_id: "broker", name: "Broker", role: "Negotiation Agent", autonomy: 3, autonomy_label: "L3 · Conditional", status: "blocked", current_task: "Awaiting human approval for €4,200 offer", completed_tasks: 612, platform: "facebook", load: 12, trend: makeSeries(24, 16, 22, 18) },
  { agent_id: "sentinel", name: "Sentinel", role: "Risk & Anti-Ban", autonomy: 5, autonomy_label: "L5 · Supervised Autonomous", status: "executing", current_task: "Throttling cadence to stay under risk threshold", completed_tasks: 3310, platform: "cross", load: 65, trend: makeSeries(28, 16, 55, 30) },
];

const CONSTITUTION_TITLES: [string, string, string][] = [
  ["Supremacy of Human Oversight", "Governance", "Fundamental"],
  ["Operator Chain of Command", "Governance", "Fundamental"],
  ["Role-Based Access Control", "Governance", "Operational"],
  ["Principle of Least Privilege", "Governance", "Operational"],
  ["Separation of Duties", "Governance", "Operational"],
  ["Emergency Stop Authority", "Governance", "Fundamental"],
  ["Central Policy Configuration", "Governance", "Operational"],
  ["Versioned Policy Registry", "Governance", "Advisory"],
  ["Pre-Action Compliance Pipeline", "Safety & Guardrails", "Fundamental"],
  ["Law Veto Engine", "Safety & Guardrails", "Fundamental"],
  ["Real-Time Tula Scanner", "Safety & Guardrails", "Operational"],
  ["Bounded Action Spaces", "Safety & Guardrails", "Fundamental"],
  ["Dry-Run by Default", "Safety & Guardrails", "Operational"],
  ["Human Approval for High-Risk Actions", "Safety & Guardrails", "Fundamental"],
  ["Predictive Risk Scoring", "Safety & Guardrails", "Operational"],
  ["Circuit Breakers & Backoff", "Safety & Guardrails", "Operational"],
  ["Rate Pacing & Throttling", "Safety & Guardrails", "Operational"],
  ["Anomaly Detection Hooks", "Safety & Guardrails", "Advisory"],
  ["Data Minimization", "Privacy & Data", "Fundamental"],
  ["Profile Identity Isolation", "Privacy & Data", "Fundamental"],
  ["Encryption at Rest", "Privacy & Data", "Operational"],
  ["Encryption in Transit", "Privacy & Data", "Operational"],
  ["Secrets Rotation", "Privacy & Data", "Operational"],
  ["Right to Erasure", "Privacy & Data", "Fundamental"],
  ["PII Redaction in Logs", "Privacy & Data", "Operational"],
  ["Five-Level Autonomy Scale", "Autonomy Levels", "Fundamental"],
  ["Autonomy Escalation Gates", "Autonomy Levels", "Operational"],
  ["Self-Correction Limits", "Autonomy Levels", "Operational"],
  ["Forbidden Autonomous States", "Autonomy Levels", "Fundamental"],
  ["Skill Evolution Boundaries", "Autonomy Levels", "Advisory"],
  ["Terms-of-Service Adherence", "Compliance", "Fundamental"],
  ["Marketplace Policy Mapping", "Compliance", "Operational"],
  ["Geographic Compliance Zones", "Compliance", "Operational"],
  ["Prohibited Listing Categories", "Compliance", "Fundamental"],
  ["Anti-Spam & Cadence Rules", "Compliance", "Operational"],
  ["Evidence of Consent", "Compliance", "Fundamental"],
  ["Device Lease Contracts", "Resource Management", "Operational"],
  ["Shard Routing via HRW Hashing", "Resource Management", "Operational"],
  ["Context Window Budgets", "Resource Management", "Operational"],
  ["Memory Compaction Triggers", "Resource Management", "Advisory"],
  ["Storage Quotas", "Resource Management", "Advisory"],
  ["Background Daemon Limits", "Resource Management", "Operational"],
  ["Immutable Audit Trail", "Audit & Transparency", "Fundamental"],
  ["Structured Context Logging", "Audit & Transparency", "Operational"],
  ["OpenTelemetry Tracing", "Audit & Transparency", "Operational"],
  ["Explainability of Decisions", "Audit & Transparency", "Fundamental"],
  ["Tamper-Evident Records", "Audit & Transparency", "Operational"],
  ["Non-Deception Principle", "Ethics", "Fundamental"],
  ["Fair Representation", "Ethics", "Fundamental"],
  ["Honest Content Disclosure", "Ethics", "Operational"],
  ["No Manipulative Patterns", "Ethics", "Fundamental"],
  ["Federated Knowledge Graphs", "Federation", "Operational"],
  ["Cross-Agent Trust Scores", "Federation", "Operational"],
  ["Swarm Coordination Protocol", "Federation", "Operational"],
  ["Conflict Resolution Quorum", "Federation", "Advisory"],
  ["Bearer Token Authentication", "Security", "Operational"],
  ["Per-Key Data Isolation", "Security", "Fundamental"],
  ["Input Validation & Sandboxing", "Security", "Operational"],
  ["Dependency Scanning", "Security", "Advisory"],
  ["Least-Privilege Containers", "Security", "Operational"],
  ["Health Check & Liveness", "Operations", "Operational"],
  ["Backup & Restore Verification", "Operations", "Fundamental"],
  ["Graceful Degradation", "Operations", "Operational"],
  ["Webhook Delivery Guarantees", "Operations", "Advisory"],
  ["Change Management & Approvals", "Operations", "Fundamental"],
  ["Telemetry Export Standards", "Operations", "Advisory"],
  ["Continuous Validation Suite", "Operations", "Operational"],
];

const SCOPES = ["Global", "Module", "Agent", "Profile", "Tenant"];

export const CONSTITUTION: ConstitutionArticle[] = CONSTITUTION_TITLES.map(([title, category, level], i) => {
  const number = i + 1;
  const draftSet = new Set([8, 18, 30, 40, 55, 65]);
  const status = draftSet.has(number) ? "Draft" : "Active";
  return {
    number,
    numeral: toRoman(number),
    title,
    category,
    status,
    level,
    scope: SCOPES[i % SCOPES.length],
    valid: status === "Active",
  };
});

export const DEVICES: AndroidDevice[] = [
  { serial: "emulator-5554", model: "Pixel 6 (API 34)", host: "ubu-node-01", status: "online", profile: "olx_kyiv_01", battery: 87, platform: "olx", uptime: 92400 },
  { serial: "emulator-5556", model: "Pixel 6 (API 34)", host: "ubu-node-01", status: "busy", profile: "ig_eu_02", battery: 64, platform: "instagram", uptime: 51200 },
  { serial: "emulator-5558", model: "Pixel 7 (API 33)", host: "ubu-node-02", status: "online", profile: "wa_relay_07", battery: 92, platform: "whatsapp", uptime: 138000 },
  { serial: "emulator-5560", model: "Pixel 5 (API 32)", host: "ubu-node-02", status: "busy", profile: "fb_market_03", battery: 41, platform: "facebook", uptime: 33800 },
  { serial: "physical-A1B2", model: "Galaxy S22 (API 33)", host: "ubu-node-03", status: "online", profile: "tt_collector_01", battery: 73, platform: "tiktok", uptime: 76100 },
  { serial: "emulator-5562", model: "Pixel 6 (API 34)", host: "ubu-node-03", status: "offline", profile: "viber_pool_05", battery: 9, platform: "viber", uptime: 0 },
  { serial: "physical-C3D4", model: "Galaxy A52 (API 31)", host: "ubu-node-04", status: "online", profile: "olx_lviv_02", battery: 88, platform: "olx", uptime: 105300 },
  { serial: "emulator-5564", model: "Pixel 6 (API 34)", host: "ubu-node-04", status: "busy", profile: "ig_eu_09", battery: 56, platform: "instagram", uptime: 47900 },
];

export const SERVICES: ServiceInfo[] = [
  { name: "aios-api", label: "AIOS REST API", port: 8500, state: "active", active: true, since: "2026-07-21T08:14:00", cpu: 18, mem: 312 },
  { name: "aios-mcp", label: "MCP Gateway", port: 8571, state: "active", active: true, since: "2026-07-21T08:14:00", cpu: 9, mem: 148 },
  { name: "aios-dash", label: "Web Dashboard", port: 8580, state: "active", active: true, since: "2026-07-21T08:14:00", cpu: 5, mem: 96 },
  { name: "aios-olx-collector", label: "OLX HTTP Collector", state: "active", active: true, since: "2026-07-21T08:15:00", cpu: 22, mem: 174 },
  { name: "aios-tg", label: "Telegram Bot", state: "active", active: true, since: "2026-07-21T08:15:00", cpu: 4, mem: 72 },
  { name: "aios-autopilot", label: "Production Autopilot", state: "active", active: true, since: "2026-07-21T08:16:00", cpu: 12, mem: 138 },
  { name: "prometheus", label: "Prometheus Metrics", port: 9090, state: "active", active: true, since: "2026-07-20T22:01:00", cpu: 7, mem: 210 },
  { name: "grafana", label: "Grafana Dashboards", port: 3000, state: "inactive", active: false, since: "2026-07-21T02:40:00", cpu: 0, mem: 0 },
];

const OLX_AD_TITLES = [
  ["iPhone 15 Pro Max 256GB Titanium", 48500, "Київ", "iphone 15 pro", true],
  ["Samsung Galaxy S24 Ultra 12/512", 42000, "Львів", "galaxy s24", true],
  ["MacBook Pro 14 M3 Pro 2024", 68000, "Київ", "macbook pro m3", true],
  ["PlayStation 5 Slim + 2 джойстики", 23500, "Одеса", "ps5 slim", false],
  ["Велосипед горный Cube Attention", 31000, "Харків", "велосипед cube", false],
  ["Toyota Corolla 2018, автомат", 525000, "Київ", "toyota corolla", true],
  ["Квартира 2к, Оболонь, 56м²", 4850000, "Київ", "квартира оболонь", true],
  ["Дрель акумуляторна Bosch GSR", 5400, "Дніпро", "дрель bosch", true],
  ["Ноутбук ASUS ROG Strix G16", 56000, "Запоріжжя", "asus rog", false],
  ["Apple Watch Ultra 2 Cellular", 33000, "Львів", "apple watch ultra", true],
  ["Холодильник Samsung No Frost", 28900, "Київ", "холодильник samsung", true],
  ["AirPods Pro 2 USB-C нові", 9800, "Вінниця", "airpods pro 2", false],
];

export const OLX_ADS: OlxAd[] = OLX_AD_TITLES.map(([title, price, city, query, business], i) => ({
  id: `ad-${1000 + i}`,
  title: title as string,
  price_value: price as number,
  price_currency: "UAH",
  city: city as string,
  query: query as string,
  business: business as boolean,
  url: "https://www.olx.ua/d/uk/",
  published: Date.now() - (i * 7 + 3) * 60000,
}));

export const OLX_SUMMARY: OlxSummary = {
  available: true,
  ads_total: 184293,
  ads_active: 152841,
  new_24h: 3412,
  price_avg: 48200,
};

export const SAFETY: SafetyData = {
  safety_score: 0.978,
  status: "healthy",
  metrics: {
    "Ban Risk Index": 0.04,
    "Captcha Rate": 0.011,
    "Detection Probability": 0.06,
    "Policy Violations": 0.0,
    "Cadence Drift": 0.02,
  },
  thresholds: {
    "Ban Risk Index": 0.15,
    "Captcha Rate": 0.05,
    "Detection Probability": 0.2,
    "Policy Violations": 0.01,
    "Cadence Drift": 0.1,
  },
  incidents: [
    { id: "inc-204", severity: "warning", description: "TikTok captcha spike on tt_collector_01 (auto-throttled)", timestamp: Date.now() - 1000 * 60 * 42, resolved: true },
    { id: "inc-203", severity: "critical", description: "Facebook login challenge on fb_market_03 — paused profile", timestamp: Date.now() - 1000 * 60 * 60 * 3, resolved: true },
    { id: "inc-202", severity: "info", description: "Rate pacer adjusted Viber cadence -12%", timestamp: Date.now() - 1000 * 60 * 60 * 6, resolved: true },
  ],
};

export const ML_MODELS: MLModelInfo[] = [
  { name: "ban-risk-classifier", version: "v3.2.1", framework: "XGBoost", stage: "production", sha256: "9f2a…c71e", eval_metrics: { AUC: 0.94, F1: 0.89, Precision: 0.91 }, size_mb: 14 },
  { name: "intent-router", version: "v2.0.4", framework: "sentence-transformers", stage: "production", sha256: "1b7d…44af", eval_metrics: { Accuracy: 0.93, Latency_ms: 41 }, size_mb: 92 },
  { name: "price-predictor", version: "v1.4.0", framework: "LightGBM", stage: "production", sha256: "a3c0…0e92", eval_metrics: { MAE: 480, R2: 0.88 }, size_mb: 8 },
  { name: "listing-scorer", version: "v1.9.0-rc", framework: "PyTorch", stage: "staging", sha256: "ef81…2b04", eval_metrics: { AUC: 0.95, Recall: 0.86 }, size_mb: 224 },
  { name: "sentiment-nlp", version: "v0.9.2", framework: "spaCy", stage: "archived", sha256: "77ac…9d51", eval_metrics: { F1: 0.84 }, size_mb: 56 },
];

export const KG: KnowledgeGraphData = {
  nodes: [
    { id: "orchestrator", label: "Maestro", type: "agent" },
    { id: "scout", label: "Scout-α", type: "agent" },
    { id: "warden", label: "Warden", type: "agent" },
    { id: "echo", label: "Echo", type: "agent" },
    { id: "rule-art14", label: "Art XIV · Approval", type: "rule" },
    { id: "rule-art9", label: "Art IX · Compliance", type: "rule" },
    { id: "task-publish", label: "Publish Task", type: "task" },
    { id: "mem-listings", label: "Listing Memory", type: "memory" },
    { id: "model-ban", label: "ban-risk-classifier", type: "model" },
    { id: "task-scan", label: "Scan Task", type: "task" },
  ],
  edges: [
    { source: "orchestrator", target: "scout", relation: "delegates" },
    { source: "orchestrator", target: "echo", relation: "delegates" },
    { source: "orchestrator", target: "warden", relation: "consults" },
    { source: "scout", target: "task-scan", relation: "executes" },
    { source: "echo", target: "task-publish", relation: "executes" },
    { source: "task-publish", target: "rule-art14", relation: "gated_by" },
    { source: "task-scan", target: "rule-art9", relation: "gated_by" },
    { source: "warden", target: "rule-art14", relation: "enforces" },
    { source: "warden", target: "rule-art9", relation: "enforces" },
    { source: "scout", target: "mem-listings", relation: "reads" },
    { source: "warden", target: "model-ban", relation: "invokes" },
    { source: "model-ban", target: "task-publish", relation: "scores" },
  ],
};

export const API_KEYS: ApiKey[] = [
  { id: "k1", subject: "operator@aios", prefix: "aios_live_8f2a", roles: ["operator", "writer"], created: "2026-06-12", ttl_days: 90, status: "active", uses: 18421 },
  { id: "k2", subject: "dashboard", prefix: "aios_live_2c91", roles: ["viewer"], created: "2026-05-30", ttl_days: 365, status: "active", uses: 99210 },
  { id: "k3", subject: "autopilot", prefix: "aios_live_b7d4", roles: ["operator"], created: "2026-07-01", ttl_days: 60, status: "active", uses: 5042 },
  { id: "k4", subject: "legacy-bot", prefix: "aios_live_0a55", roles: ["writer"], created: "2026-02-10", ttl_days: 30, status: "expired", uses: 2210 },
];

export const WEBHOOKS: Webhook[] = [
  { id: "w1", name: "Slack #ops", url: "https://hooks.slack.com/services/T0/B0/x", events: ["ban_detected", "approval_required"], status: "active", delivered: 4210, failed: 3 },
  { id: "w2", name: "Teams Alerts", url: "https://outlook.office.com/webhook/...", events: ["critical_incident"], status: "active", delivered: 88, failed: 0 },
  { id: "w3", name: "Internal CRM", url: "https://crm.internal/api/aios-hook", events: ["listing_published", "inquiry_received"], status: "paused", delivered: 12940, failed: 41 },
];

export const BACKUPS: Backup[] = [
  { id: "b1", label: "pre-deploy", created: "2026-07-21 08:12", size_mb: 248, verified: true, kind: "manual" },
  { id: "b2", label: "nightly-auto", created: "2026-07-21 03:00", size_mb: 246, verified: true, kind: "auto" },
  { id: "b3", label: "nightly-auto", created: "2026-07-20 03:00", size_mb: 244, verified: true, kind: "auto" },
  { id: "b4", label: "nightly-auto", created: "2026-07-19 03:00", size_mb: 241, verified: false, kind: "auto" },
];

export const SUBSCRIPTIONS: Subscription[] = [
  { id: "s1", query: "iphone 15 pro", min: 30000, max: 60000, matches: 18, active: true },
  { id: "s2", query: "macbook pro m3", min: 50000, max: 90000, matches: 7, active: true },
  { id: "s3", query: "ps5 slim", min: 18000, max: 28000, matches: 12, active: true },
  { id: "s4", query: "toyota corolla", min: 400000, max: 600000, matches: 4, active: false },
];

const AUDIT_TEMPLATES: Array<Omit<AuditEvent, "id" | "ts">> = [
  { type: "compliance", actor: "Warden", action: "Compliance gate passed", detail: "67/67 articles validated for publish task #8421", severity: "success" },
  { type: "agent", actor: "Maestro", action: "Pipeline dispatched", detail: "Cross-platform publish across OLX + Instagram + WhatsApp", severity: "info" },
  { type: "platform", actor: "Scout-α", action: "Listings scanned", detail: "OLX query 'iphone 15 pro' returned 42 new ads", severity: "info" },
  { type: "approval", actor: "Broker", action: "Approval requested", detail: "High-value offer €4,200 pending human sign-off", severity: "warning" },
  { type: "security", actor: "Sentinel", action: "Cadence throttled", detail: "TikTok collector rate reduced 12% to stay under risk threshold", severity: "warning" },
  { type: "platform", actor: "Echo", action: "Messages sent", detail: "14 WhatsApp auto-replies delivered within pacing window", severity: "success" },
  { type: "system", actor: "aios-api", action: "API key rotated", detail: "Subject 'autopilot' key rotated, TTL 60d", severity: "info" },
  { type: "security", actor: "Sentinel", action: "Profile paused", detail: "fb_market_03 paused after login challenge", severity: "critical" },
  { type: "compliance", actor: "Warden", action: "Veto enforced", detail: "Action blocked: violates Art XXXIV (prohibited category)", severity: "warning" },
  { type: "agent", actor: "Scribe", action: "Draft created", detail: "Listing copy drafted, queued for human approval", severity: "info" },
  { type: "system", actor: "Backup", action: "Backup verified", detail: "nightly-auto 246MB — checksum OK", severity: "success" },
];

let auditCounter = 0;
export function makeAuditEvent(ts = Date.now()): AuditEvent {
  const t = AUDIT_TEMPLATES[Math.floor(Math.random() * AUDIT_TEMPLATES.length)];
  auditCounter += 1;
  return { ...t, id: `ev-${Date.now()}-${auditCounter}`, ts };
}

export function seedAuditFeed(count = 14): AuditEvent[] {
  const out: AuditEvent[] = [];
  for (let i = 0; i < count; i++) {
    out.push(makeAuditEvent(Date.now() - i * 90000));
  }
  return out;
}
