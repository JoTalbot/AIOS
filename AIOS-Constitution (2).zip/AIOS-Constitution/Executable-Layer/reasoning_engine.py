"""
AIOS Reasoning Engine Layer v2.1.1

Builds explainable reasoning chains from rules, knowledge and constraints.
"""


class ReasoningEngine:
    def __init__(self):
        self.traces = []

    def reason(self, decision: str, rules: list, sources: list):
        trace = {
            "decision": decision,
            "rules": rules,
            "knowledge_sources": sources,
        }
        self.traces.append(trace)
        return trace

    def last_trace(self):
        return self.traces[-1] if self.traces else None
