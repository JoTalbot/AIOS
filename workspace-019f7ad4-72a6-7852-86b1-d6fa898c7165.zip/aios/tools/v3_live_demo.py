#!/usr/bin/env python3
"""AIOS v3.0 Live End-to-End Demonstration Script

Run a live simulation of the newly implemented v3.0 architecture:
1. Booting AIOS API server in-memory
2. Checking Diagnostic Health & Telemetry
3. Proposing an Autonomous AI Model Evolution candidate (`Reasoning-DeepSeek-v3.1`)
4. Executing Constitutional Validation (`ARTICLE-VIII`, `ARTICLE-XXXVI`)
5. Simulating Multi-Agent Guard Panel Consensus
6. Deploying candidate to production runtime
7. Simulating post-deployment telemetry anomaly -> Automated Safety Rollback
8. Exporting Prometheus / OpenMetrics telemetry
"""

import asyncio
import json
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from httpx import AsyncClient, ASGITransport

from aios_core.api.app import create_app
from aios_core.monitoring import AlertLevel

CONSTITUTION_DIR = str(Path(__file__).parent.parent / "docs" / "constitution")
POLICIES_DIR = str(Path(__file__).parent.parent / "policies")


def print_step(step_num: int, title: str):
    print(f"\n{'='*60}\n[STEP {step_num}] {title}\n{'='*60}")


async def main():
    print("\n🚀 [BOOT] Initializing AIOS v3.1.0 Executive Layer with SQLite In-Memory Storage...")
    app = create_app(db_path=":memory:", constitution_dir=CONSTITUTION_DIR, policies_dir=POLICIES_DIR)

    # Access API instance directly for simulated anomalies
    api_instance = app.routes[0].endpoint.__self__

    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://localhost:8000") as client:
        # Step 1: Health & Telemetry Check
        print_step(1, "Diagnostic Health Check (/api/v1/monitoring/health)")
        resp = await client.get("/api/v1/monitoring/health")
        health = resp.json()
        print(f"Status: {health['status']} | Uptime: {health['uptime_seconds']}s | Version: {health['version']}")
        print(f"Subsystems: {json.dumps(health['subsystems'], indent=2)}")

        # Step 2: Propose Model Candidate
        print_step(2, "Proposing Autonomous AI Model Evolution (/api/v1/model-evolution-v3/proposals)")
        proposal_payload = {
            "name": "Reasoning-DeepSeek-v3.1",
            "version": "3.1.0-prod",
            "model_type": "llm_reasoning_core",
            "target_module": "reasoning_engine",
            "description": "Integration of self-verifying chain-of-thought with strict constitutional guardrails.",
            "parameters_hash": "sha256:e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
        }
        resp = await client.post("/api/v1/model-evolution-v3/proposals", json=proposal_payload)
        candidate = resp.json()
        cid = candidate["id"]
        print(f"✅ Candidate Registered:\n  ID: {cid}\n  Name: {candidate['name']} v{candidate['version']}\n  Status: {candidate['status'].upper()}")

        # Step 3: Constitutional Validation
        print_step(3, f"Executing Constitutional Validation on Candidate '{cid}'")
        resp = await client.post(f"/api/v1/model-evolution-v3/proposals/{cid}/validate")
        val_report = resp.json()
        print(f"Checks Run: {val_report['checks_run']} | Passed: {val_report['passed']} | Decision: {val_report.get('constitutional_decision', 'allow').upper()}")
        for check_name, check_res in val_report["details"].items():
            print(f"  - {check_name}: {check_res}")

        # Step 4: Multi-Agent Consensus
        print_step(4, "Simulating Multi-Agent Guard Panel Consensus")
        resp = await client.post(f"/api/v1/model-evolution-v3/proposals/{cid}/consensus")
        consensus = resp.json()
        print(f"Overall Status: {consensus['status'].upper()}")
        for panel, vote in consensus["votes"].items():
            icon = "👍 APPROVE" if vote else "👎 REJECT"
            print(f"  - {panel:20s} : {icon}")

        # Step 5: Production Deployment
        print_step(5, f"Deploying Approved Candidate to Active Runtime")
        resp = await client.post(f"/api/v1/model-evolution-v3/proposals/{cid}/deploy")
        dep_res = resp.json()
        print(f"✅ Deployment Status: {dep_res['status'].upper()} (Active Model ID: {cid})")

        # Step 6: Simulate Post-Deployment Anomaly & Automated Safety Rollback
        print_step(6, "Simulating Post-Deployment Telemetry Anomaly & Automated Safety Rollback")
        print("  [SYSTEM ALERT] Injecting simulated high constitutional denial spike post-deployment...")
        # Inject 7 deny evaluations into monitoring engine
        for _ in range(7):
            api_instance.monitoring.record_action_evaluation("deny", latency_ms=18.4)
        for _ in range(2):
            api_instance.monitoring.record_action_evaluation("allow", latency_ms=9.1)

        print("  [SYSTEM ALERT] Executing /api/v1/model-evolution-v3/proposals/{cid}/rollback-check...")
        resp = await client.post(f"/api/v1/model-evolution-v3/proposals/{cid}/rollback-check")
        rollback_data = resp.json()
        if rollback_data["triggered"]:
            print(f"🚨 AUTOMATED SAFETY ROLLBACK TRIGGERED!")
            print(f"  Rolled Back Model ID: {rollback_data['rolled_back_id']}")
            active_candidate = api_instance.model_evolution_v3.candidates[cid]
            print(f"  Candidate Status Reverted To: {active_candidate.status.value.upper()}")

        # Step 7: Export OpenMetrics / Prometheus Telemetry
        print_step(7, "Exporting OpenMetrics / Prometheus Telemetry (/api/v1/monitoring/metrics)")
        resp = await client.get("/api/v1/monitoring/metrics")
        lines = resp.text.strip().split("\n")
        for line in lines[:15]:
            print(f"  {line}")

    print("\n🏁 [SUCCESS] AIOS v3.0 Live Demonstration Completed without errors.")


if __name__ == "__main__":
    asyncio.run(main())
