"""AIOS Support and Monitoring Layer v3.0.0

Real-time system health monitoring, telemetry tracking, anomaly alerting,
and Prometheus/OpenMetrics metrics export for AIOS subsystems.
"""

from __future__ import annotations

import os
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from .storage import Database
    from .constitution_engine import ConstitutionEngine
    from .evolution_manager import EvolutionManager
    from .audit_logger import AuditLogger


class AlertLevel(Enum):
    INFO = "INFO"
    WARNING = "WARNING"
    CRITICAL = "CRITICAL"


@dataclass
class Alert:
    id: str
    level: AlertLevel
    subsystem: str
    message: str
    timestamp: str
    resolved: bool = False
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "level": self.level.value,
            "subsystem": self.subsystem,
            "message": self.message,
            "timestamp": self.timestamp,
            "resolved": self.resolved,
            "metadata": self.metadata,
        }


class SystemMonitor:
    """Central monitoring and telemetry hub for AIOS v3.0.0.

    Tracks subsystem health, evaluates anomaly conditions, maintains alert lists,
    and formats data for Prometheus/OpenMetrics ingestion.
    """

    def __init__(
        self,
        db: Optional["Database"] = None,
        constitution_engine: Optional["ConstitutionEngine"] = None,
        evolution_manager: Optional["EvolutionManager"] = None,
        audit_logger: Optional["AuditLogger"] = None,
    ):
        self.db = db
        self.constitution_engine = constitution_engine
        self.evolution_manager = evolution_manager
        self.audit_logger = audit_logger
        self.alerts: list[Alert] = []
        self._latencies: list[float] = []
        self._action_counts = {"allow": 0, "deny": 0, "review": 0}
        self.start_time = time.time()

    def record_action_evaluation(self, outcome: str, latency_ms: float = 0.0) -> None:
        """Record a constitutional decision and latency."""
        outcome_lower = outcome.lower()
        if outcome_lower in self._action_counts:
            self._action_counts[outcome_lower] += 1
        else:
            self._action_counts[outcome_lower] = 1

        if latency_ms > 0:
            self._latencies.append(latency_ms)
            if len(self._latencies) > 1000:
                self._latencies.pop(0)

        # Trigger anomaly check on spikes in denies
        total = sum(self._action_counts.values())
        if total >= 10 and (self._action_counts.get("deny", 0) / total) > 0.4:
            self.emit_alert(
                level=AlertLevel.WARNING,
                subsystem="ConstitutionEngine",
                message=f"High constitutional denial rate: {self._action_counts.get('deny', 0)} of {total} actions denied.",
            )

    def emit_alert(
        self, level: AlertLevel, subsystem: str, message: str, metadata: Optional[dict[str, Any]] = None
    ) -> Alert:
        """Create and register a system alert."""
        from .storage import Database

        alert_id = Database.new_id()
        alert = Alert(
            id=alert_id,
            level=level,
            subsystem=subsystem,
            message=message,
            timestamp=datetime.now(timezone.utc).isoformat(),
            metadata=metadata or {},
        )
        self.alerts.append(alert)
        return alert

    def resolve_alert(self, alert_id: str) -> bool:
        """Mark an active alert as resolved."""
        for alert in self.alerts:
            if alert.id == alert_id and not alert.resolved:
                alert.resolved = True
                return True
        return False

    def get_active_alerts(self, min_level: Optional[AlertLevel] = None) -> list[dict[str, Any]]:
        """Return all unresolved alerts, optionally filtered by minimum severity."""
        levels_order = {AlertLevel.INFO: 0, AlertLevel.WARNING: 1, AlertLevel.CRITICAL: 2}
        min_rank = levels_order[min_level] if min_level else 0

        active = [
            a for a in self.alerts
            if not a.resolved and levels_order[a.level] >= min_rank
        ]
        return [a.to_dict() for a in active]

    def check_health(self) -> dict[str, Any]:
        """Perform full diagnostic health check across subsystems."""
        uptime_sec = time.time() - self.start_time
        avg_latency = (sum(self._latencies) / len(self._latencies)) if self._latencies else 0.0

        db_healthy = True
        db_stats = {}
        if self.db:
            try:
                db_stats = self.db.stats()
            except Exception as e:
                db_healthy = False
                self.emit_alert(AlertLevel.CRITICAL, "Storage", f"Database check failed: {e}")

        const_stats = {}
        if self.constitution_engine:
            try:
                const_stats = self.constitution_engine.stats()
            except Exception as e:
                self.emit_alert(AlertLevel.WARNING, "ConstitutionEngine", f"Stats check failed: {e}")

        evo_stats = {}
        if self.evolution_manager:
            try:
                evo_stats = self.evolution_manager.stats()
            except Exception as e:
                self.emit_alert(AlertLevel.WARNING, "EvolutionManager", f"Stats check failed: {e}")

        active_critical = any(a.level == AlertLevel.CRITICAL and not a.resolved for a in self.alerts)
        overall_status = "CRITICAL" if active_critical else ("WARNING" if any(not a.resolved for a in self.alerts) else "OK")

        return {
            "status": overall_status,
            "version": "3.0.0",
            "uptime_seconds": round(uptime_sec, 2),
            "telemetry": {
                "avg_evaluation_latency_ms": round(avg_latency, 2),
                "action_evaluations": self._action_counts,
                "active_alerts_count": len([a for a in self.alerts if not a.resolved]),
            },
            "subsystems": {
                "database": {"status": "OK" if db_healthy else "CRITICAL", "details": db_stats},
                "constitution": {"status": "OK" if const_stats else "N/A", "details": const_stats},
                "evolution": {"status": "OK" if evo_stats else "N/A", "details": evo_stats},
            },
        }

    def export_openmetrics(self) -> str:
        """Export current telemetry and subsystem stats in OpenMetrics/Prometheus format."""
        health = self.check_health()
        lines = [
            "# HELP aios_uptime_seconds Total system uptime in seconds.",
            "# TYPE aios_uptime_seconds counter",
            f"aios_uptime_seconds {health['uptime_seconds']}",
            "",
            "# HELP aios_evaluation_latency_ms Average latency of constitutional evaluations.",
            "# TYPE aios_evaluation_latency_ms gauge",
            f"aios_evaluation_latency_ms {health['telemetry']['avg_evaluation_latency_ms']}",
            "",
            "# HELP aios_actions_total Total constitutional action evaluations by outcome.",
            "# TYPE aios_actions_total counter",
            f"aios_actions_total{{outcome=\"allow\"}} {self._action_counts.get('allow', 0)}",
            f"aios_actions_total{{outcome=\"deny\"}} {self._action_counts.get('deny', 0)}",
            f"aios_actions_total{{outcome=\"review\"}} {self._action_counts.get('review', 0)}",
            "",
            "# HELP aios_active_alerts Active unresolved system alerts.",
            "# TYPE aios_active_alerts gauge",
            f"aios_active_alerts {health['telemetry']['active_alerts_count']}",
        ]

        if self.db:
            try:
                db_s = self.db.stats()
                for table, cnt in db_s.get("tables", {}).items():
                    lines.append(f"aios_db_table_rows{{table=\"{table}\"}} {cnt}")
            except Exception:
                pass

        return "\n".join(lines) + "\n"
