"""Phase 6 — AIOS v3.0 Roadmap Implementation Tests

Tests the 4 pillars of the post-v2.0 roadmap:
1. Support & Monitoring (`SystemMonitor`, OpenMetrics export, alerts)
2. Test Expansion & Tula Tool (`TulaAuditor` scanning, template generation, compliance matrix)
3. Deployment & Integration (`DeploymentManager` readiness checks, Docker / K8s manifest generation)
4. Model Evolution 3.0 (`ModelEvolutionV3Engine` candidate proposal, constitutional validation, consensus, rollback)
5. REST API v3.0 routes (`/api/v1/monitoring/*`, `/api/v1/deployment/*`, `/api/v1/model-evolution-v3/*`)
"""

import os
import pytest
from pathlib import Path
from httpx import AsyncClient, ASGITransport

from aios_core.storage import Database
from aios_core.monitoring import SystemMonitor, AlertLevel
from aios_core.deployment_manager import DeploymentManager
from aios_core.model_evolution_v3 import ModelEvolutionV3Engine, ModelCandidateStatus
from aios_core.constitution_engine import ConstitutionEngine
from aios_core.evolution_manager import EvolutionManager
from aios_core.audit_logger import AuditLogger
from tools.complete_constitution_tula import TulaAuditor


CONSTITUTION_DIR = str(Path(__file__).parent.parent / "docs" / "constitution")
POLICIES_DIR = str(Path(__file__).parent.parent / "policies")


# ============================================================
# 1. Support & Monitoring Tests (`SystemMonitor`)
# ============================================================

class TestSystemMonitor:
    def test_monitor_init_and_health(self):
        db = Database(":memory:")
        monitor = SystemMonitor(db=db)
        health = monitor.check_health()
        assert health["status"] == "OK"
        assert health["version"] == "3.0.0"
        assert "uptime_seconds" in health

    def test_record_actions_and_alert_trigger(self):
        monitor = SystemMonitor()
        for _ in range(6):
            monitor.record_action_evaluation("deny", latency_ms=12.5)
        for _ in range(4):
            monitor.record_action_evaluation("allow", latency_ms=8.0)

        health = monitor.check_health()
        assert health["telemetry"]["action_evaluations"]["deny"] == 6
        assert len(monitor.get_active_alerts()) > 0
        alert = monitor.get_active_alerts()[0]
        assert "High constitutional denial rate" in alert["message"]

    def test_resolve_alert(self):
        monitor = SystemMonitor()
        alert = monitor.emit_alert(AlertLevel.CRITICAL, "TestSubsystem", "Test critical error")
        assert len(monitor.get_active_alerts()) == 1
        resolved = monitor.resolve_alert(alert.id)
        assert resolved is True
        assert len(monitor.get_active_alerts()) == 0

    def test_openmetrics_export(self):
        monitor = SystemMonitor()
        monitor.record_action_evaluation("allow", latency_ms=10.0)
        metrics = monitor.export_openmetrics()
        assert "aios_uptime_seconds" in metrics
        assert "aios_actions_total{outcome=\"allow\"} 1" in metrics


# ============================================================
# 2. Tula Constitutional Auditor Tests (`TulaAuditor`)
# ============================================================

class TestTulaAuditor:
    def test_scan_constitution(self):
        auditor = TulaAuditor(CONSTITUTION_DIR)
        result = auditor.scan()
        assert result["valid_articles_found"] >= 60
        assert result["fully_compliant_articles"] >= 60
        assert isinstance(result["anomalies_found"], list)

    def test_generate_template_and_matrix(self, tmp_path):
        auditor = TulaAuditor(str(tmp_path))
        tpl_path = auditor.write_template("99", "TEST-GUARDRAIL")
        assert os.path.exists(tpl_path)
        content = Path(tpl_path).read_text()
        assert "# ARTICLE XCIX — TEST-GUARDRAIL" in content
        assert "## Status" in content
        assert "## Laws" in content

        matrix_path = os.path.join(str(tmp_path), "COMPLIANCE_MATRIX.md")
        auditor.export_compliance_matrix(matrix_path)
        assert os.path.exists(matrix_path)


# ============================================================
# 3. Deployment Manager Tests (`DeploymentManager`)
# ============================================================

class TestDeploymentManager:
    def test_readiness_verification_clean(self):
        db = Database(":memory:")
        monitor = SystemMonitor(db=db)
        deployment = DeploymentManager(system_monitor=monitor)
        report = deployment.verify_production_readiness()
        assert report.ready is True
        assert report.checks["zero_critical_alerts"] is True

    def test_readiness_verification_blocked_by_alert(self):
        monitor = SystemMonitor()
        monitor.emit_alert(AlertLevel.CRITICAL, "Core", "Fatal corruption simulated")
        deployment = DeploymentManager(system_monitor=monitor)
        report = deployment.verify_production_readiness()
        assert report.ready is False
        assert "active CRITICAL alerts" in report.reasons[0]

    def test_manifest_generation(self):
        deployment = DeploymentManager()
        docker_manifest = deployment.generate_docker_compose(version="3.1.0", port=8000)
        assert "aios/core:3.1.0" in docker_manifest
        assert "8000:8000" in docker_manifest

        k8s_manifest = deployment.generate_k8s_manifest(namespace="prod-aios")
        assert "kind: Deployment" in k8s_manifest
        assert "prod-aios" in k8s_manifest
        assert "kind: Service" in k8s_manifest


# ============================================================
# 4. Model Evolution 3.0 Tests (`ModelEvolutionV3Engine`)
# ============================================================

class TestModelEvolutionV3Engine:
    def test_full_model_candidate_lifecycle(self):
        db = Database(":memory:")
        audit = AuditLogger(db=db)
        const = ConstitutionEngine(CONSTITUTION_DIR, POLICIES_DIR)
        evo = EvolutionManager(db=db)
        monitor = SystemMonitor(db=db)

        engine = ModelEvolutionV3Engine(
            evolution_manager=evo,
            system_monitor=monitor,
            constitution_engine=const,
            audit_logger=audit,
        )

        # 1. Propose
        candidate = engine.propose_candidate(
            name="ReasoningLM-v3",
            version="3.0.0-rc1",
            model_type="llm",
            target_module="reasoning_engine",
            description="Upgraded reasoning algorithm with autonomous safety verification",
            parameters_hash="sha256:abcd1234ef5678",
        )
        assert candidate.status == ModelCandidateStatus.PROPOSED
        assert candidate.id in engine.candidates

        # 2. Validate
        report = engine.validate_candidate(candidate.id)
        assert report["passed"] is True
        assert candidate.status == ModelCandidateStatus.CONSENSUS_PENDING

        # 3. Consensus
        votes = engine.run_consensus(candidate.id)
        assert all(votes.values())
        assert candidate.status == ModelCandidateStatus.APPROVED

        # 4. Deploy
        deployed = engine.deploy_candidate(candidate.id)
        assert deployed is True
        assert engine.active_model_id == candidate.id
        assert candidate.status == ModelCandidateStatus.DEPLOYED

        # 5. Rollback check on clean state
        rolled_back = engine.check_rollback_trigger()
        assert rolled_back is None

        # 6. Simulate critical telemetry failure -> auto-rollback
        monitor.emit_alert(AlertLevel.CRITICAL, "ReasoningEngine", "Latency/hallucination anomaly post-deploy")
        rolled_back = engine.check_rollback_trigger()
        assert rolled_back == candidate.id
        assert candidate.status == ModelCandidateStatus.ROLLED_BACK
        assert engine.active_model_id is None


# ============================================================
# 5. REST API v3.0 Routes Tests
# ============================================================

@pytest.fixture
def app():
    from aios_core.api.app import create_app
    return create_app(
        db_path=":memory:",
        constitution_dir=CONSTITUTION_DIR,
        policies_dir=POLICIES_DIR,
    )


@pytest.fixture
async def client(app):
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as c:
        yield c


@pytest.mark.asyncio
class TestRESTAPIv3:
    async def test_monitoring_endpoints(self, client):
        resp_health = await client.get("/api/v1/monitoring/health")
        assert resp_health.status_code == 200
        data = resp_health.json()
        assert data["status"] == "OK"
        assert data["version"] == "3.0.0"

        resp_metrics = await client.get("/api/v1/monitoring/metrics")
        assert resp_metrics.status_code == 200
        assert "aios_uptime_seconds" in resp_metrics.text

        resp_alerts = await client.get("/api/v1/monitoring/alerts")
        assert resp_alerts.status_code == 200
        assert "alerts" in resp_alerts.json()

    async def test_deployment_endpoints(self, client):
        resp_check = await client.get("/api/v1/deployment/check")
        assert resp_check.status_code == 200
        data = resp_check.json()
        assert "ready" in data

        resp_docker = await client.get("/api/v1/deployment/manifests/docker")
        assert resp_docker.status_code == 200
        assert "aios/core:3.1.0" in resp_docker.json()["manifest"]

        resp_k8s = await client.get("/api/v1/deployment/manifests/k8s")
        assert resp_k8s.status_code == 200
        assert "kind: Deployment" in resp_k8s.json()["manifest"]

    async def test_model_evolution_endpoints(self, client):
        # 1. Propose
        payload = {
            "name": "SafetyFineTune",
            "version": "3.1.0-alpha",
            "model_type": "guard_classifier",
            "target_module": "privacy_guard",
            "description": "Improved PII detection weights",
            "parameters_hash": "sha256:998877665544",
        }
        resp_prop = await client.post("/api/v1/model-evolution-v3/proposals", json=payload)
        assert resp_prop.status_code == 201
        data = resp_prop.json()
        cid = data["id"]
        assert data["status"] == "proposed"

        # 2. Validate
        resp_val = await client.post(f"/api/v1/model-evolution-v3/proposals/{cid}/validate")
        assert resp_val.status_code == 200
        assert resp_val.json()["passed"] is True

        # 3. Consensus
        resp_con = await client.post(f"/api/v1/model-evolution-v3/proposals/{cid}/consensus")
        assert resp_con.status_code == 200
        assert resp_con.json()["status"] == "approved"

        # 4. Deploy
        resp_dep = await client.post(f"/api/v1/model-evolution-v3/proposals/{cid}/deploy")
        assert resp_dep.status_code == 200
        assert resp_dep.json()["status"] == "deployed"

        # 5. Rollback check
        resp_roll = await client.post(f"/api/v1/model-evolution-v3/proposals/{cid}/rollback-check")
        assert resp_roll.status_code == 200
        assert resp_roll.json()["triggered"] is False
