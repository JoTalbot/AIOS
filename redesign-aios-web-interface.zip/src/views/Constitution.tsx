import { useMemo, useState } from "react";
import { Scale, Search, BookText, ShieldCheck, Globe, CheckCircle2, FileEdit } from "lucide-react";
import { Card, PanelHeader, Badge, Segmented } from "../components/ui/primitives";
import { CONSTITUTION } from "../data/mockData";
import { cn } from "../utils/cn";

const LEVEL_TONE: Record<string, any> = { Fundamental: "rose", Operational: "indigo", Advisory: "slate" };

export function Constitution() {
  const [q, setQ] = useState("");
  const [cat, setCat] = useState("All");
  const [level, setLevel] = useState<"All" | "Fundamental" | "Operational" | "Advisory">("All");
  const [selectedNum, setSelectedNum] = useState(1);

  const categories = useMemo(() => ["All", ...Array.from(new Set(CONSTITUTION.map((a) => a.category)))], []);
  const filtered = useMemo(
    () =>
      CONSTITUTION.filter(
        (a) =>
          (cat === "All" || a.category === cat) &&
          (level === "All" || a.level === level) &&
          (q === "" || a.title.toLowerCase().includes(q.toLowerCase()) || a.numeral.toLowerCase().includes(q.toLowerCase()))
      ),
    [q, cat, level]
  );
  const selected = CONSTITUTION.find((a) => a.number === selectedNum) ?? CONSTITUTION[0];
  const fundamental = CONSTITUTION.filter((a) => a.level === "Fundamental").length;

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {[
          { label: "Total articles", value: CONSTITUTION.length, icon: BookText, tone: "indigo" },
          { label: "Fundamental", value: fundamental, icon: Scale, tone: "rose" },
          { label: "Categories", value: categories.length - 1, icon: ShieldCheck, tone: "cyan" },
          { label: "Enforced", value: CONSTITUTION.filter((a) => a.valid).length, icon: CheckCircle2, tone: "emerald" },
        ].map((s) => (
          <Card key={s.label} className="flex items-center gap-3 p-4">
            <div className={`grid h-10 w-10 place-items-center rounded-xl bg-${s.tone}-500/10 text-${s.tone}-300`}>
              <s.icon className="h-5 w-5" />
            </div>
            <div>
              <div className="text-xl font-extrabold tabular text-white">{s.value}</div>
              <div className="text-[11px] uppercase tracking-wide text-slate-500">{s.label}</div>
            </div>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 gap-5 xl:grid-cols-3">
        <Card className="xl:col-span-2">
          <div className="mb-4 space-y-3">
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
                <input
                  value={q}
                  onChange={(e) => setQ(e.target.value)}
                  placeholder="Search articles by title or numeral…"
                  className="w-full rounded-xl border border-white/[0.08] bg-white/[0.03] py-2.5 pl-9 pr-3 text-sm text-slate-200 outline-none placeholder:text-slate-600 focus:border-indigo-400/50"
                />
              </div>
              <Segmented
                size="sm"
                value={level}
                onChange={setLevel}
                options={[
                  { value: "All", label: "All" },
                  { value: "Fundamental", label: "Fund." },
                  { value: "Operational", label: "Oper." },
                  { value: "Advisory", label: "Adv." },
                ]}
              />
            </div>
            <div className="flex flex-wrap gap-1.5">
              {categories.map((c) => (
                <button
                  key={c}
                  onClick={() => setCat(c)}
                  className={cn(
                    "rounded-full px-2.5 py-1 text-[11px] font-medium transition-colors",
                    cat === c ? "bg-indigo-500/90 text-white" : "bg-white/[0.04] text-slate-400 hover:text-slate-200"
                  )}
                >
                  {c}
                </button>
              ))}
            </div>
          </div>

          <div className="grid max-h-[560px] grid-cols-1 gap-2 overflow-y-auto pr-1 sm:grid-cols-2">
            {filtered.map((a) => (
              <button
                key={a.number}
                onClick={() => setSelectedNum(a.number)}
                className={cn(
                  "flex items-start gap-3 rounded-xl border p-3 text-left transition-all",
                  selectedNum === a.number ? "border-indigo-400/40 bg-indigo-500/[0.07]" : "border-white/[0.05] bg-white/[0.02] hover:border-white/15"
                )}
              >
                <div className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-white/[0.04] font-mono text-[11px] font-bold text-indigo-300 ring-1 ring-inset ring-white/[0.06]">
                  {a.numeral}
                </div>
                <div className="min-w-0">
                  <div className="text-sm font-semibold leading-snug text-slate-100">{a.title}</div>
                  <div className="mt-1 flex flex-wrap items-center gap-1.5">
                    <span className="text-[10px] text-slate-500">{a.category}</span>
                    <Badge tone={LEVEL_TONE[a.level]}>{a.level}</Badge>
                    {!a.valid && <Badge tone="amber"><FileEdit className="h-2.5 w-2.5" /> Draft</Badge>}
                  </div>
                </div>
              </button>
            ))}
            {filtered.length === 0 && (
              <div className="col-span-2 py-10 text-center text-sm text-slate-500">No articles match your filters.</div>
            )}
          </div>
        </Card>

        {/* Detail */}
        <Card>
          <PanelHeader icon={<Scale className="h-[18px] w-[18px]" />} title="Article Detail" subtitle={`Constitution · ${filtered.length} shown`} />
          <div className="rounded-2xl border border-white/[0.06] bg-gradient-to-b from-indigo-500/[0.06] to-transparent p-5">
            <div className="flex items-center gap-3">
              <div className="grid h-14 w-14 place-items-center rounded-xl bg-indigo-500/15 font-mono text-base font-bold text-indigo-300 ring-1 ring-inset ring-indigo-400/20">
                {selected.numeral}
              </div>
              <div>
                <div className="text-[11px] uppercase tracking-wide text-slate-500">Article {selected.number}</div>
                <Badge tone={LEVEL_TONE[selected.level]}>{selected.level}</Badge>
              </div>
            </div>
            <h3 className="mt-4 text-lg font-bold leading-snug text-white">{selected.title}</h3>
            <div className="mt-4 space-y-2.5 text-sm">
              <Row label="Category" value={selected.category} />
              <Row label="Scope" value={selected.scope} icon={Globe} />
              <Row label="Status" value={selected.valid ? "Active · enforced at runtime" : "Draft · pending ratification"} />
            </div>
          </div>
          <div className="mt-4 flex items-center gap-2 rounded-xl bg-white/[0.02] p-3 ring-1 ring-inset ring-white/[0.04]">
            {selected.valid ? (
              <>
                <CheckCircle2 className="h-5 w-5 text-emerald-400" />
                <div>
                  <div className="text-sm font-semibold text-slate-200">Enforced by Constitution Engine</div>
                  <div className="text-[11px] text-slate-500">Evaluated in the pre-action compliance pipeline before every action.</div>
                </div>
              </>
            ) : (
              <>
                <FileEdit className="h-5 w-5 text-amber-400" />
                <div>
                  <div className="text-sm font-semibold text-slate-200">Draft — not yet enforced</div>
                  <div className="text-[11px] text-slate-500">Awaiting ratification via change management (Art. LXV).</div>
                </div>
              </>
            )}
          </div>
        </Card>
      </div>
    </div>
  );
}

function Row({ label, value, icon: Icon }: { label: string; value: string; icon?: any }) {
  return (
    <div className="flex items-center justify-between gap-3 border-b border-white/[0.04] pb-2">
      <span className="text-slate-500">{label}</span>
      <span className="inline-flex items-center gap-1.5 text-right font-medium text-slate-200">
        {Icon && <Icon className="h-3.5 w-3.5 text-slate-500" />} {value}
      </span>
    </div>
  );
}
