import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { llmProviders } from '@/db/schema';
import { seedDatabase } from '@/db/seed';
import { eq } from 'drizzle-orm';

export async function GET() {
  try {
    await seedDatabase();
    const providers = await db.select().from(llmProviders);
    return NextResponse.json({ success: true, data: providers });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error?.message || 'Failed to fetch providers' }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, status, isDefault, apiBaseUrl } = body;

    if (!id) {
      return NextResponse.json({ success: false, error: 'Provider id is required' }, { status: 400 });
    }

    if (isDefault) {
      // Clear default flag on others
      const allP = await db.select().from(llmProviders);
      for (const p of allP) {
        if (p.id !== id && p.isDefault) {
          await db.update(llmProviders).set({ isDefault: false }).where(eq(llmProviders.id, p.id));
        }
      }
    }

    const [updated] = await db.update(llmProviders)
      .set({
        status,
        isDefault,
        apiBaseUrl,
      })
      .where(eq(llmProviders.id, id))
      .returning();

    return NextResponse.json({ success: true, data: updated });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error?.message || 'Failed to update provider' }, { status: 500 });
  }
}
