import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { conversations, chatMessages, agents } from '@/db/schema';
import { eq, asc } from 'drizzle-orm';

export async function GET(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const convId = parseInt(id, 10);
    if (isNaN(convId)) {
      return NextResponse.json({ success: false, error: 'Invalid conversation ID' }, { status: 400 });
    }

    const [conv] = await db
      .select({
        id: conversations.id,
        title: conversations.title,
        agentId: conversations.agentId,
        agentName: agents.name,
        agentAvatar: agents.avatar,
        agentSlug: agents.slug,
        agentModel: agents.model,
        agentProvider: agents.provider,
        mode: conversations.mode,
        pinned: conversations.pinned,
        tokenCount: conversations.tokenCount,
        createdAt: conversations.createdAt,
        updatedAt: conversations.updatedAt,
      })
      .from(conversations)
      .leftJoin(agents, eq(conversations.agentId, agents.id))
      .where(eq(conversations.id, convId))
      .limit(1);

    if (!conv) {
      return NextResponse.json({ success: false, error: 'Conversation not found' }, { status: 404 });
    }

    const messages = await db
      .select({
        id: chatMessages.id,
        conversationId: chatMessages.conversationId,
        agentId: chatMessages.agentId,
        agentName: agents.name,
        agentAvatar: agents.avatar,
        role: chatMessages.role,
        content: chatMessages.content,
        toolName: chatMessages.toolName,
        toolArgs: chatMessages.toolArgs,
        toolResult: chatMessages.toolResult,
        executionTimeMs: chatMessages.executionTimeMs,
        tokensUsed: chatMessages.tokensUsed,
        requiresApproval: chatMessages.requiresApproval,
        approvalStatus: chatMessages.approvalStatus,
        createdAt: chatMessages.createdAt,
      })
      .from(chatMessages)
      .leftJoin(agents, eq(chatMessages.agentId, agents.id))
      .where(eq(chatMessages.conversationId, convId))
      .orderBy(asc(chatMessages.createdAt));

    return NextResponse.json({ success: true, data: { ...conv, messages } });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error?.message || 'Error fetching conversation' }, { status: 500 });
  }
}

export async function PUT(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const convId = parseInt(id, 10);
    if (isNaN(convId)) {
      return NextResponse.json({ success: false, error: 'Invalid conversation ID' }, { status: 400 });
    }

    const body = await request.json();
    const [updated] = await db.update(conversations)
      .set({
        ...body,
        updatedAt: new Date(),
      })
      .where(eq(conversations.id, convId))
      .returning();

    return NextResponse.json({ success: true, data: updated });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error?.message || 'Error updating conversation' }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const convId = parseInt(id, 10);
    if (isNaN(convId)) {
      return NextResponse.json({ success: false, error: 'Invalid conversation ID' }, { status: 400 });
    }

    await db.delete(conversations).where(eq(conversations.id, convId));
    return NextResponse.json({ success: true, message: 'Conversation deleted' });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error?.message || 'Error deleting conversation' }, { status: 500 });
  }
}
