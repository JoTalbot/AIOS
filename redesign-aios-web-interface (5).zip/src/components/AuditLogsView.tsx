'use client';

import React, { useState } from 'react';
import {
  ShieldAlert,
  Search,
  Filter,
  Terminal,
  AlertTriangle,
  Info,
  ShieldCheck,
  Clock,
  Layers
} from 'lucide-react';

interface AuditLogsViewProps {
  logs: any[];
}

export default function AuditLogsView({ logs }: AuditLogsViewProps) {
  const [levelFilter, setLevelFilter] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredLogs = logs.filter((log) => {
    const matchesLevel = levelFilter === 'all' || log.level === levelFilter;
    const matchesSearch = searchQuery === '' ||
      log.message.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.category.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesLevel && matchesSearch;
  });

  return (
    <div className="p-4 lg:p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight flex items-center space-x-2">
            <ShieldAlert className="w-5 h-5 text-amber-400" />
            <span>AIOS Kernel Security & Audit Event Logs</span>
          </h1>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Timestamped execution audit trail, human-in-the-loop actions, and privilege verification events.
          </p>
        </div>

        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Filter logs by keyword..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9 pr-4 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs font-mono text-slate-200 focus:border-cyan-500 focus:outline-none w-64"
          />
        </div>
      </div>

      {/* Level Filters */}
      <div className="flex items-center space-x-2 border-b border-slate-800/80 pb-3">
        {['all', 'info', 'warn', 'error', 'security', 'kernel'].map((lvl) => (
          <button
            key={lvl}
            onClick={() => setLevelFilter(lvl)}
            className={`px-3 py-1.5 rounded-xl text-xs font-mono uppercase transition-all cursor-pointer border ${
              levelFilter === lvl
                ? 'bg-amber-950 text-amber-300 border-amber-700 font-bold'
                : 'bg-slate-900/60 text-slate-400 border-slate-800 hover:text-slate-200'
            }`}
          >
            {lvl}
          </button>
        ))}
      </div>

      {/* Log Table */}
      <div className="glass-panel p-5 rounded-2xl border border-slate-800">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 bg-slate-900/60">
                <th className="py-2.5 px-3">Timestamp</th>
                <th className="py-2.5 px-3">Level</th>
                <th className="py-2.5 px-3">Category</th>
                <th className="py-2.5 px-3">Message</th>
                <th className="py-2.5 px-3">Agent / PID</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredLogs.map((log) => {
                const isError = log.level === 'error';
                const isWarn = log.level === 'warn';
                const isSecurity = log.level === 'security';

                return (
                  <tr key={log.id} className="hover:bg-slate-900/40 transition-colors">
                    <td className="py-3 px-3 text-slate-500 shrink-0 whitespace-nowrap">
                      {new Date(log.timestamp).toLocaleString()}
                    </td>
                    <td className="py-3 px-3">
                      <span className={`px-2 py-0.5 rounded text-[10px] uppercase font-bold border ${
                        isError ? 'bg-rose-950 text-rose-300 border-rose-800' :
                        isWarn ? 'bg-amber-950 text-amber-300 border-amber-800' :
                        isSecurity ? 'bg-purple-950 text-purple-300 border-purple-800' :
                        'bg-cyan-950 text-cyan-300 border-cyan-800'
                      }`}>
                        {log.level}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-slate-400 uppercase font-semibold">
                      [{log.category}]
                    </td>
                    <td className="py-3 px-3 text-slate-200">
                      {log.message}
                    </td>
                    <td className="py-3 px-3 text-slate-400">
                      {log.agentId ? `Agent #${log.agentId}` : log.processId ? `PID #${log.processId}` : 'Kernel Root'}
                    </td>
                  </tr>
                );
              })}

              {filteredLogs.length === 0 && (
                <tr>
                  <td colSpan={5} className="py-8 text-center text-slate-500 font-mono">
                    No log events match the query filter.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
