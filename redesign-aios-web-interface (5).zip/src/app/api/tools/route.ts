import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { tools } from '@/db/schema';
import { seedDatabase } from '@/db/seed';
import { desc, eq } from 'drizzle-orm';

export async function GET() {
  try {
    await seedDatabase();
    const allTools = await db.select().from(tools).orderBy(desc(tools.totalCalls));
    return NextResponse.json({ success: true, data: allTools });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error?.message || 'Failed to fetch tools' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { name, description, category, isMcp, mcpServerUrl, riskLevel, parametersSchema } = body;

    if (!name || !description) {
      return NextResponse.json({ success: false, error: 'Name and description are required' }, { status: 400 });
    }

    const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/(^_|_$)+/g, '');

    const [newTool] = await db.insert(tools).values({
      name,
      slug,
      description,
      category: category || 'system',
      isMcp: Boolean(isMcp),
      mcpServerUrl: mcpServerUrl || null,
      riskLevel: riskLevel || 'safe',
      parametersSchema: parametersSchema || {},
      isEnabled: true,
      totalCalls: 0,
      avgLatencyMs: Math.floor(Math.random() * 100) + 50,
    }).returning();

    return NextResponse.json({ success: true, data: newTool });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error?.message || 'Failed to create tool' }, { status: 500 });
  }
}
