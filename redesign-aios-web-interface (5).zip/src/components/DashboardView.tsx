'use client';

import React, { useState } from 'react';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar
} from 'recharts';
import {
  Cpu,
  Activity,
  HardDrive,
  Zap,
  Terminal,
  Pause,
  Play,
  XSquare,
  PlusCircle,
  ShieldCheck,
  RefreshCw,
  Clock,
  Layers,
  Sparkles
} from 'lucide-react';

interface DashboardViewProps {
  metrics: any;
  processes: any[];
  logs: any[];
  agents: any[];
  setActiveTab: (tab: string) => void;
  onRefresh: () => void;
  onProcessAction: (procId: number, action: string) => void;
  onSpawnProcess: (agentId: number) => void;
}

export default function DashboardView({
  metrics,
  processes,
  logs,
  agents,
  setActiveTab,
  onRefresh,
  onProcessAction,
  onSpawnProcess,
}: DashboardViewProps) {
  const [selectedAgentForSpawn, setSelectedAgentForSpawn] = useState<number | ''>('');
  const [spawnModalOpen, setSpawnModalOpen] = useState(false);

  const summary = metrics?.summary || {
    totalAgents: 6,
    activeProcesses: processes.filter(p => p.status === 'running').length,
    totalExecutions: 3600,
    totalTokens: 3898200,
    memoryUsedTotalMb: processes.reduce((a, b) => a + (b.memoryUsedMb || 0), 0) || 714,
    activeTools: 8
  };

  const chartData = metrics?.tokenTimeSeries || [];
  const categoryData = metrics?.categoryBreakdown || [];

  const handleSpawnSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedAgentForSpawn) {
      onSpawnProcess(Number(selectedAgentForSpawn));
      setSpawnModalOpen(false);
      setSelectedAgentForSpawn('');
    }
  };

  return (
    <div className="p-4 lg:p-6 space-y-6 max-w-7xl mx-auto">
      {/* Top Welcome & Quick OS Banner */}
      <div className="glass-panel p-5 rounded-2xl relative overflow-hidden border border-slate-800 bg-gradient-to-r from-slate-900/90 via-slate-900/60 to-cyan-950/40">
        <div className="absolute top-0 right-0 -mt-10 -mr-10 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-status-pulse" />
              <h1 className="text-xl font-bold text-white tracking-tight">AIOS Kernel System Dashboard</h1>
            </div>
            <p className="text-xs text-slate-400 mt-1 max-w-2xl font-mono">
              Real-time process scheduler, LLM context window memory footprint, and Model Context Protocol (MCP) tool activity.
            </p>
          </div>

          <div className="flex items-center space-x-2 shrink-0">
            <button
              onClick={() => setSpawnModalOpen(true)}
              className="px-3.5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-medium flex items-center space-x-2 shadow-lg shadow-cyan-600/20 transition-all cursor-pointer"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Spawn Agent Process</span>
            </button>
            <button
              onClick={() => setActiveTab('chat')}
              className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-medium flex items-center space-x-2 transition-all cursor-pointer"
            >
              <Terminal className="w-4 h-4 text-cyan-400" />
              <span>Open AgentChat</span>
            </button>
          </div>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 lg:gap-4">
        <div className="glass-panel p-4 rounded-xl border border-slate-800 hover:border-cyan-800/60 transition-colors">
          <div className="flex items-center justify-between text-slate-400 text-xs font-mono">
            <span>Installed Agents</span>
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
          </div>
          <div className="mt-2 flex items-baseline space-x-2">
            <span className="text-2xl font-bold text-white font-mono">{summary.totalAgents}</span>
            <span className="text-[10px] text-cyan-400 font-mono">Ready</span>
          </div>
        </div>

        <div className="glass-panel p-4 rounded-xl border border-slate-800 hover:border-emerald-800/60 transition-colors">
          <div className="flex items-center justify-between text-slate-400 text-xs font-mono">
            <span>Active PIDs</span>
            <Activity className="w-3.5 h-3.5 text-emerald-400" />
          </div>
          <div className="mt-2 flex items-baseline space-x-2">
            <span className="text-2xl font-bold text-emerald-400 font-mono">{summary.activeProcesses}</span>
            <span className="text-[10px] text-emerald-500/80 font-mono">Threads</span>
          </div>
        </div>

        <div className="glass-panel p-4 rounded-xl border border-slate-800 hover:border-indigo-800/60 transition-colors">
          <div className="flex items-center justify-between text-slate-400 text-xs font-mono">
            <span>Kernel Memory</span>
            <Cpu className="w-3.5 h-3.5 text-indigo-400" />
          </div>
          <div className="mt-2 flex items-baseline space-x-2">
            <span className="text-2xl font-bold text-indigo-300 font-mono">{summary.memoryUsedTotalMb}</span>
            <span className="text-[10px] text-indigo-400 font-mono">MB VRAM</span>
          </div>
        </div>

        <div className="glass-panel p-4 rounded-xl border border-slate-800 hover:border-amber-800/60 transition-colors">
          <div className="flex items-center justify-between text-slate-400 text-xs font-mono">
            <span>Total Tokens</span>
            <Zap className="w-3.5 h-3.5 text-amber-400" />
          </div>
          <div className="mt-2 flex items-baseline space-x-2">
            <span className="text-2xl font-bold text-amber-300 font-mono">{(summary.totalTokens / 1000).toFixed(1)}k</span>
            <span className="text-[10px] text-amber-400/80 font-mono">Context</span>
          </div>
        </div>

        <div className="glass-panel p-4 rounded-xl border border-slate-800 hover:border-purple-800/60 transition-colors">
          <div className="flex items-center justify-between text-slate-400 text-xs font-mono">
            <span>MCP Tools</span>
            <Layers className="w-3.5 h-3.5 text-purple-400" />
          </div>
          <div className="mt-2 flex items-baseline space-x-2">
            <span className="text-2xl font-bold text-purple-300 font-mono">{summary.activeTools}</span>
            <span className="text-[10px] text-purple-400 font-mono">Active</span>
          </div>
        </div>

        <div className="glass-panel p-4 rounded-xl border border-slate-800 hover:border-teal-800/60 transition-colors">
          <div className="flex items-center justify-between text-slate-400 text-xs font-mono">
            <span>Total Execs</span>
            <Clock className="w-3.5 h-3.5 text-teal-400" />
          </div>
          <div className="mt-2 flex items-baseline space-x-2">
            <span className="text-2xl font-bold text-teal-300 font-mono">{summary.totalExecutions}</span>
            <span className="text-[10px] text-teal-400 font-mono">Calls</span>
          </div>
        </div>
      </div>

      {/* Telemetry Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Token Throughput & Memory Area Chart */}
        <div className="lg:col-span-2 glass-panel p-5 rounded-2xl border border-slate-800">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-200 flex items-center space-x-2">
                <Activity className="w-4 h-4 text-cyan-400" />
                <span>Kernel Token Velocity & CPU Load</span>
              </h3>
              <p className="text-[11px] text-slate-400 font-mono">Live throughput stream (Tokens/sec & CPU %)</p>
            </div>
            <div className="flex items-center space-x-3 text-[11px] font-mono">
              <span className="flex items-center space-x-1">
                <span className="w-2.5 h-2.5 rounded-full bg-cyan-500" />
                <span className="text-slate-400">Tok/s</span>
              </span>
              <span className="flex items-center space-x-1">
                <span className="w-2.5 h-2.5 rounded-full bg-indigo-500" />
                <span className="text-slate-400">CPU %</span>
              </span>
            </div>
          </div>

          <div className="h-60 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorTok" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#06b6d4" stopOpacity={0.0}/>
                  </linearGradient>
                  <linearGradient id="colorCpu" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#6366f1" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#6366f1" stopOpacity={0.0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="time" stroke="#64748b" fontSize={10} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={10} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', fontSize: '12px' }}
                  labelStyle={{ color: '#94a3b8' }}
                />
                <Area type="monotone" dataKey="tokensPerSec" stroke="#06b6d4" strokeWidth={2} fillOpacity={1} fill="url(#colorTok)" name="Tokens/s" />
                <Area type="monotone" dataKey="cpuPercent" stroke="#6366f1" strokeWidth={2} fillOpacity={1} fill="url(#colorCpu)" name="CPU %" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Category Breakdown Bar Chart */}
        <div className="glass-panel p-5 rounded-2xl border border-slate-800">
          <div className="mb-4">
            <h3 className="text-sm font-bold text-slate-200 flex items-center space-x-2">
              <Layers className="w-4 h-4 text-purple-400" />
              <span>Token Distribution by Category</span>
            </h3>
            <p className="text-[11px] text-slate-400 font-mono">Agent workload segmentation</p>
          </div>

          <div className="h-60 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={categoryData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="name" stroke="#64748b" fontSize={9} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={10} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', fontSize: '12px' }}
                />
                <Bar dataKey="tokens" fill="#a855f7" radius={[4, 4, 0, 0]} name="Tokens Used" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Active Kernel Processes Table */}
      <div className="glass-panel p-5 rounded-2xl border border-slate-800 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-white flex items-center space-x-2">
              <Terminal className="w-4 h-4 text-cyan-400" />
              <span>Active Kernel Processes (PIDs)</span>
            </h2>
            <p className="text-xs text-slate-400 font-mono">Live thread queue & call stack inspection</p>
          </div>

          <button
            onClick={() => setActiveTab('processes')}
            className="text-xs font-mono text-cyan-400 hover:text-cyan-300 underline cursor-pointer"
          >
            Manage Threads &rarr;
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 bg-slate-900/60">
                <th className="py-2.5 px-3">PID</th>
                <th className="py-2.5 px-3">Agent Process</th>
                <th className="py-2.5 px-3">Priority</th>
                <th className="py-2.5 px-3">Status</th>
                <th className="py-2.5 px-3">Current Execution Step</th>
                <th className="py-2.5 px-3">RAM</th>
                <th className="py-2.5 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {processes.map((proc) => {
                const isRunning = proc.status === 'running';
                const isSuspended = proc.status === 'suspended';

                return (
                  <tr key={proc.id} className="hover:bg-slate-900/40 transition-colors">
                    <td className="py-3 px-3 text-cyan-400 font-semibold">PID-{proc.pid}</td>
                    <td className="py-3 px-3">
                      <div className="flex items-center space-x-2">
                        <span className="text-base">{proc.agentAvatar || '🤖'}</span>
                        <div>
                          <p className="font-semibold text-slate-200">{proc.processName}</p>
                          <p className="text-[10px] text-slate-400">{proc.agentName || 'Kernel Agent'}</p>
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-3">
                      <span className={`text-[10px] uppercase px-2 py-0.5 rounded border ${
                        proc.priority === 'high' ? 'bg-rose-950 text-rose-300 border-rose-800' :
                        proc.priority === 'medium' ? 'bg-amber-950 text-amber-300 border-amber-800' :
                        'bg-slate-900 text-slate-400 border-slate-800'
                      }`}>
                        {proc.priority}
                      </span>
                    </td>
                    <td className="py-3 px-3">
                      <div className="flex items-center space-x-1.5">
                        <span className={`w-2 h-2 rounded-full ${
                          isRunning ? 'bg-emerald-400 animate-pulse' :
                          isSuspended ? 'bg-amber-400' : 'bg-slate-500'
                        }`} />
                        <span className={`capitalize font-semibold ${
                          isRunning ? 'text-emerald-400' :
                          isSuspended ? 'text-amber-400' : 'text-slate-400'
                        }`}>
                          {proc.status}
                        </span>
                      </div>
                    </td>
                    <td className="py-3 px-3 text-slate-300 max-w-xs truncate">
                      {proc.currentStep || 'Processing...'}
                    </td>
                    <td className="py-3 px-3 text-slate-400">{proc.memoryUsedMb} MB</td>
                    <td className="py-3 px-3 text-right">
                      <div className="flex items-center justify-end space-x-1">
                        {isRunning ? (
                          <button
                            onClick={() => onProcessAction(proc.id, 'suspend')}
                            className="p-1.5 rounded hover:bg-slate-800 text-amber-400 transition-colors cursor-pointer"
                            title="Suspend Process"
                          >
                            <Pause className="w-3.5 h-3.5" />
                          </button>
                        ) : isSuspended ? (
                          <button
                            onClick={() => onProcessAction(proc.id, 'resume')}
                            className="p-1.5 rounded hover:bg-slate-800 text-emerald-400 transition-colors cursor-pointer"
                            title="Resume Process"
                          >
                            <Play className="w-3.5 h-3.5" />
                          </button>
                        ) : null}

                        <button
                          onClick={() => onProcessAction(proc.id, 'kill')}
                          className="p-1.5 rounded hover:bg-slate-800 text-rose-400 transition-colors cursor-pointer"
                          title="Terminate PID"
                        >
                          <XSquare className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}

              {processes.length === 0 && (
                <tr>
                  <td colSpan={7} className="py-6 text-center text-slate-500">
                    No active processes in kernel thread queue. Click "Spawn Agent Process" to run a thread.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Live System Log Stream */}
      <div className="glass-panel p-5 rounded-2xl border border-slate-800">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-bold text-slate-200 flex items-center space-x-2 font-mono">
            <Terminal className="w-4 h-4 text-emerald-400" />
            <span>AIOS Kernel Real-Time System Log Ticker</span>
          </h3>
          <button
            onClick={() => setActiveTab('logs')}
            className="text-xs font-mono text-slate-400 hover:text-slate-200 underline cursor-pointer"
          >
            Full Audit Logs &rarr;
          </button>
        </div>

        <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 font-mono text-xs space-y-1.5 max-h-40 overflow-y-auto">
          {logs.slice(0, 6).map((log) => (
            <div key={log.id} className="flex items-start space-x-2 text-slate-300">
              <span className="text-slate-600 shrink-0">
                {new Date(log.timestamp).toLocaleTimeString()}
              </span>
              <span className={`uppercase font-bold shrink-0 ${
                log.level === 'error' ? 'text-rose-400' :
                log.level === 'warn' ? 'text-amber-400' :
                log.level === 'security' ? 'text-purple-400' : 'text-cyan-400'
              }`}>
                [{log.level}]
              </span>
              <span className="text-slate-400 shrink-0">[{log.category}]</span>
              <span className="text-slate-200 truncate">{log.message}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Spawn Process Modal */}
      {spawnModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="glass-panel p-6 rounded-2xl border border-slate-800 w-full max-w-md space-y-4">
            <h3 className="text-base font-bold text-white flex items-center space-x-2">
              <PlusCircle className="w-5 h-5 text-cyan-400" />
              <span>Spawn Background Agent Thread</span>
            </h3>
            <p className="text-xs text-slate-400">Select an installed AIOS agent to start a new execution thread in the OS scheduler.</p>

            <form onSubmit={handleSpawnSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-mono text-slate-300 mb-1">Target Agent</label>
                <select
                  value={selectedAgentForSpawn}
                  onChange={(e) => setSelectedAgentForSpawn(Number(e.target.value))}
                  required
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-200 font-mono focus:border-cyan-500 focus:outline-none"
                >
                  <option value="">-- Select Installed Agent --</option>
                  {agents.map((a) => (
                    <option key={a.id} value={a.id}>
                      {a.avatar} {a.name} ({a.model})
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex items-center justify-end space-x-2 pt-2">
                <button
                  type="button"
                  onClick={() => setSpawnModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-900 text-slate-400 hover:text-slate-200 text-xs font-mono cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-mono font-bold shadow-lg shadow-cyan-600/20 cursor-pointer"
                >
                  Spawn Process PID
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
