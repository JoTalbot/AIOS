import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { agentProcesses, agents, systemLogs } from '@/db/schema';
import { seedDatabase } from '@/db/seed';
import { desc, eq } from 'drizzle-orm';

export async function GET() {
  try {
    await seedDatabase();
    const processes = await db
      .select({
        id: agentProcesses.id,
        pid: agentProcesses.pid,
        agentId: agentProcesses.agentId,
        agentName: agents.name,
        agentAvatar: agents.avatar,
        processName: agentProcesses.processName,
        status: agentProcesses.status,
        priority: agentProcesses.priority,
        memoryUsedMb: agentProcesses.memoryUsedMb,
        tokensUsed: agentProcesses.tokensUsed,
        currentStep: agentProcesses.currentStep,
        callStack: agentProcesses.callStack,
        cpuUsagePct: agentProcesses.cpuUsagePct,
        progressPct: agentProcesses.progressPct,
        errorMessage: agentProcesses.errorMessage,
        startedAt: agentProcesses.startedAt,
        endedAt: agentProcesses.endedAt,
      })
      .from(agentProcesses)
      .leftJoin(agents, eq(agentProcesses.agentId, agents.id))
      .orderBy(desc(agentProcesses.startedAt));

    return NextResponse.json({ success: true, data: processes });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error?.message || 'Failed to fetch processes' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { agentId, processName, priority } = body;

    if (!agentId) {
      return NextResponse.json({ success: false, error: 'agentId is required' }, { status: 400 });
    }

    const [targetAgent] = await db.select().from(agents).where(eq(agents.id, agentId)).limit(1);
    if (!targetAgent) {
      return NextResponse.json({ success: false, error: 'Agent not found' }, { status: 404 });
    }

    const nextPid = 1000 + Math.floor(Math.random() * 9000);

    const [newProc] = await db.insert(agentProcesses).values({
      pid: nextPid,
      agentId,
      processName: processName || `${targetAgent.name} Routine`,
      status: 'running',
      priority: priority || targetAgent.priority || 'medium',
      memoryUsedMb: Math.floor(Math.random() * 200) + 64,
      tokensUsed: 0,
      currentStep: 'Initializing execution context',
      callStack: [`${targetAgent.slug}_main()`, 'setup_memory_buffer()', 'allocate_gpu_cache()'],
      cpuUsagePct: parseFloat((Math.random() * 25 + 5).toFixed(1)),
      progressPct: 5,
    }).returning();

    // Log event
    await db.insert(systemLogs).values({
      level: 'info',
      category: 'scheduler',
      message: `Spawned process PID-${nextPid} for agent '${targetAgent.name}'`,
      agentId,
      processId: newProc.id,
    });

    return NextResponse.json({ success: true, data: newProc });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error?.message || 'Failed to spawn process' }, { status: 500 });
  }
}
