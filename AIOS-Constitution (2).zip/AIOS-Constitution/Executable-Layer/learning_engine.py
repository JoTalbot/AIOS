"""
AIOS Learning Engine Layer v2.1.1

Processes system experience and learning signals.
"""


class LearningEngine:
    def __init__(self):
        self.experiences = []

    def learn(self, experience: dict):
        self.experiences.append(experience)
        return experience

    def history(self):
        return self.experiences
