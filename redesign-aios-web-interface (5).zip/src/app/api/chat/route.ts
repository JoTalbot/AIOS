import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { chatMessages, conversations, agents, tools, agentMemories, systemLogs } from '@/db/schema';
import { eq } from 'drizzle-orm';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { conversationId, content, agentId: overrideAgentId } = body;

    if (!conversationId || !content || !content.trim()) {
      return NextResponse.json({ success: false, error: 'conversationId and content are required' }, { status: 400 });
    }

    // 1. Get conversation details
    const [conv] = await db.select().from(conversations).where(eq(conversations.id, conversationId)).limit(1);
    if (!conv) {
      return NextResponse.json({ success: false, error: 'Conversation not found' }, { status: 404 });
    }

    const activeAgentId = overrideAgentId || conv.agentId;
    let targetAgent = null;
    if (activeAgentId) {
      [targetAgent] = await db.select().from(agents).where(eq(agents.id, activeAgentId)).limit(1);
    }
    if (!targetAgent) {
      // Fallback to Kernel Master
      const [km] = await db.select().from(agents).where(eq(agents.slug, 'kernel-master')).limit(1);
      targetAgent = km;
    }

    // 2. Insert User Message
    const userTokens = Math.ceil(content.length / 4);
    const [userMsg] = await db.insert(chatMessages).values({
      conversationId,
      role: 'user',
      content: content.trim(),
      tokensUsed: userTokens,
    }).returning();

    // 3. Analyze content to decide tool calls
    const lowerContent = content.toLowerCase();
    let triggeredTool: any = null;
    let toolArgs: any = null;
    let toolResult: any = null;
    let requiresApproval = false;

    if (lowerContent.includes('shell') || lowerContent.includes('bash') || lowerContent.includes('command') || lowerContent.includes('terminal') || lowerContent.includes('exec')) {
      const [tool] = await db.select().from(tools).where(eq(tools.slug, 'execute_shell')).limit(1);
      if (tool) {
        triggeredTool = tool;
        toolArgs = { command: 'ls -la /var/log/aios && uptime', workdir: '/var/log/aios' };
        requiresApproval = true; // High risk shell execution triggers human-in-the-loop approval
        toolResult = { stdout: 'system load average: 0.12, 0.08, 0.05\n4 active pids running in sandbox', exitCode: 0 };
      }
    } else if (lowerContent.includes('search') || lowerContent.includes('google') || lowerContent.includes('news') || lowerContent.includes('find') || lowerContent.includes('web')) {
      const [tool] = await db.select().from(tools).where(eq(tools.slug, 'web_search_mcp')).limit(1);
      if (tool) {
        triggeredTool = tool;
        toolArgs = { query: content, maxResults: 3 };
        toolResult = [
          { title: 'AIOS Kernel OS v2.4 Release Notes', snippet: 'Introduced Model Context Protocol (MCP) server daemon & priority CPU/GPU scheduler.' },
          { title: 'AIOS AgentHub Ecosystem', snippet: 'Over 50+ pre-trained agent modules for coding, security auditing, and automation pipelines.' }
        ];
      }
    } else if (lowerContent.includes('sql') || lowerContent.includes('database') || lowerContent.includes('table') || lowerContent.includes('query') || lowerContent.includes('select')) {
      const [tool] = await db.select().from(tools).where(eq(tools.slug, 'sql_query_engine')).limit(1);
      if (tool) {
        triggeredTool = tool;
        toolArgs = { query: 'SELECT name, status, priority, memory_limit_mb FROM agents;' };
        toolResult = { rows: 6, status: 'Query executed in 4.2ms' };
      }
    } else if (lowerContent.includes('python') || lowerContent.includes('script') || lowerContent.includes('code') || lowerContent.includes('calculate')) {
      const [tool] = await db.select().from(tools).where(eq(tools.slug, 'python_interpreter')).limit(1);
      if (tool) {
        triggeredTool = tool;
        toolArgs = { code: 'import numpy as np\nx = np.linspace(0, 10, 100)\nprint("Computed matrix size:", x.shape)' };
        toolResult = { output: 'Computed matrix size: (100,)', executionTime: '12ms' };
      }
    } else if (lowerContent.includes('file') || lowerContent.includes('read') || lowerContent.includes('write') || lowerContent.includes('folder')) {
      const [tool] = await db.select().from(tools).where(eq(tools.slug, 'read_write_file')).limit(1);
      if (tool) {
        triggeredTool = tool;
        toolArgs = { action: 'list', path: 'src/app/' };
        toolResult = { files: ['page.tsx', 'globals.css', 'layout.tsx', 'api/'] };
      }
    }

    // Insert tool call message if triggered
    let toolCallMsg = null;
    if (triggeredTool) {
      [toolCallMsg] = await db.insert(chatMessages).values({
        conversationId,
        agentId: targetAgent ? targetAgent.id : null,
        role: 'tool_call',
        content: `Agent invoked tool: **${triggeredTool.name}** (${triggeredTool.slug})`,
        toolName: triggeredTool.slug,
        toolArgs,
        executionTimeMs: Math.floor(Math.random() * 150) + 50,
        requiresApproval,
        approvalStatus: requiresApproval ? 'pending' : 'approved',
      }).returning();

      if (!requiresApproval) {
        await db.insert(chatMessages).values({
          conversationId,
          agentId: targetAgent ? targetAgent.id : null,
          role: 'tool_result',
          content: typeof toolResult === 'string' ? toolResult : JSON.stringify(toolResult, null, 2),
          toolName: triggeredTool.slug,
          toolResult,
          executionTimeMs: Math.floor(Math.random() * 80) + 20,
        });
      }
    }

    // 4. Synthesize AI Agent Response text
    let agentResponseText = '';
    const agentName = targetAgent ? targetAgent.name : 'AIOS Kernel Agent';
    const agentModel = targetAgent ? targetAgent.model : 'gpt-4o';
    const agentProvider = targetAgent ? targetAgent.provider.toUpperCase() : 'OPENAI';

    if (requiresApproval) {
      agentResponseText = `⚠️ **Action Requires Human Confirmation**

Agent **${agentName}** requests permission to execute a high-risk tool action:
- **Tool:** \`${triggeredTool?.name}\` (\`${triggeredTool?.slug}\`)
- **Parameters:**
\`\`\`json
${JSON.stringify(toolArgs, null, 2)}
\`\`\`

Please approve or reject this tool invocation above to let the process resume in the AIOS kernel.`;
    } else if (triggeredTool) {
      agentResponseText = `I have executed the requested operation using **${triggeredTool.name}** via the AIOS Kernel API.

### 📋 Operation Results
\`\`\`json
${JSON.stringify(toolResult, null, 2)}
\`\`\`

### 💡 Agent Summary
The system has processed your request for *"_${content}_"*. The operation completed with status **SUCCESS**. 
- **Model:** \`${agentModel}\` (${agentProvider})
- **Execution Time:** ~140ms
- **Memory Buffer:** Healthy (42 MB allocated)`;
    } else {
      // Detailed intelligence response based on user input
      agentResponseText = `Greetings! I am **${agentName}**, running on the AIOS kernel using **${agentModel}** (\`${agentProvider}\`).

In response to your query regarding:
> *"${content}"*

Here is the structured kernel analysis and breakdown:

### ⚙️ Executive Summary & Key Insights
1. **Context Resolution:** Processed prompt tokens and retrieved relevant episodic memories from long-term Vector Store.
2. **Resource Allocation:** Allocated thread memory block and prioritized execution in the AIOS FIFO scheduler.
3. **Execution Plan:** Validated system security policies and confirmed no privileged authorization is required for standard operations.

### 💻 Code / Technical Blueprint
\`\`\`typescript
// AIOS Agent Execution Subroutine
interface AgentTaskContext {
  pid: number;
  agentSlug: string;
  tokensUsed: number;
  mcpToolActive: boolean;
}

export async function processKernelEvent(ctx: AgentTaskContext) {
  console.log(\`[AIOS Kernel] Thread PID-\${ctx.pid} executing \${ctx.agentSlug}\`);
  return { status: "COMPLETED", timestamp: Date.now() };
}
\`\`\`

### 🚀 Next Steps
You can ask me to:
- Run **shell commands** or inspect file systems.
- Execute **SQL queries** or analyze dataset statistics.
- Perform **web search crawls** via MCP protocols.
- Chain multi-agent **workflow pipelines**.`;
    }

    const agentTokens = Math.ceil(agentResponseText.length / 4) + 120;

    // 5. Insert Agent Response Message
    const [agentMsg] = await db.insert(chatMessages).values({
      conversationId,
      agentId: targetAgent ? targetAgent.id : null,
      role: 'agent',
      content: agentResponseText,
      tokensUsed: agentTokens,
    }).returning();

    // 6. Update Conversation & Agent stats
    const totalTokensAdded = userTokens + agentTokens;
    await db.update(conversations)
      .set({
        tokenCount: (conv.tokenCount || 0) + totalTokensAdded,
        updatedAt: new Date(),
      })
      .where(eq(conversations.id, conversationId));

    if (targetAgent) {
      await db.update(agents)
        .set({
          totalExecutions: (targetAgent.totalExecutions || 0) + 1,
          totalTokens: (targetAgent.totalTokens || 0) + totalTokensAdded,
        })
        .where(eq(agents.id, targetAgent.id));
    }

    // 7. System Log
    await db.insert(systemLogs).values({
      level: 'info',
      category: 'agent_exec',
      message: `Agent '${agentName}' processed message in conversation #${conversationId} (${totalTokensAdded} tokens used)`,
      agentId: targetAgent ? targetAgent.id : null,
    });

    return NextResponse.json({
      success: true,
      data: {
        userMessage: userMsg,
        toolCallMessage: toolCallMsg,
        agentMessage: agentMsg,
      }
    });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error?.message || 'Failed to process chat message' }, { status: 500 });
  }
}
