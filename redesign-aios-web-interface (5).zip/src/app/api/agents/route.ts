import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { agents } from '@/db/schema';
import { seedDatabase } from '@/db/seed';
import { desc, eq, like, or } from 'drizzle-orm';

export async function GET(request: NextRequest) {
  try {
    await seedDatabase();
    const searchParams = request.nextUrl.searchParams;
    const category = searchParams.get('category');
    const search = searchParams.get('search');

    let query = db.select().from(agents);

    let allAgents = await db.select().from(agents).orderBy(desc(agents.createdAt));

    if (category && category !== 'all') {
      allAgents = allAgents.filter(a => a.category.toLowerCase() === category.toLowerCase());
    }

    if (search) {
      const searchLower = search.toLowerCase();
      allAgents = allAgents.filter(a =>
        a.name.toLowerCase().includes(searchLower) ||
        a.description.toLowerCase().includes(searchLower) ||
        a.slug.toLowerCase().includes(searchLower)
      );
    }

    return NextResponse.json({ success: true, data: allAgents });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error?.message || 'Failed to fetch agents' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { name, description, category, avatar, systemPrompt, model, provider, temperature, maxTokens, priority, memoryLimitMb, tools } = body;

    if (!name || !description || !systemPrompt) {
      return NextResponse.json({ success: false, error: 'Name, description, and system prompt are required.' }, { status: 400 });
    }

    const slug = body.slug || name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)+/g, '') + '-' + Date.now().toString().slice(-4);

    const [newAgent] = await db.insert(agents).values({
      name,
      slug,
      description,
      category: category || 'general',
      avatar: avatar || '🤖',
      systemPrompt,
      model: model || 'gpt-4o',
      provider: provider || 'openai',
      temperature: typeof temperature === 'number' ? temperature : 0.7,
      maxTokens: maxTokens || 4096,
      status: 'idle',
      priority: priority || 'medium',
      memoryLimitMb: memoryLimitMb || 512,
      tools: Array.isArray(tools) ? tools : [],
    }).returning();

    return NextResponse.json({ success: true, data: newAgent });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error?.message || 'Failed to create agent' }, { status: 500 });
  }
}
