import { NextResponse } from 'next/server';
import { db } from '@/db';
import { agents, agentProcesses, chatMessages, tools, llmProviders } from '@/db/schema';
import { seedDatabase } from '@/db/seed';

export async function GET() {
  try {
    await seedDatabase();

    const allAgents = await db.select().from(agents);
    const allProcs = await db.select().from(agentProcesses);
    const allTools = await db.select().from(tools);
    const allProviders = await db.select().from(llmProviders);

    const totalExecutions = allAgents.reduce((acc, a) => acc + (a.totalExecutions || 0), 0);
    const totalTokens = allAgents.reduce((acc, a) => acc + (a.totalTokens || 0), 0);
    const activeProcessesCount = allProcs.filter(p => p.status === 'running').length;
    const memoryUsedTotalMb = allProcs.reduce((acc, p) => acc + (p.memoryUsedMb || 0), 0);
    const activeToolsCount = allTools.filter(t => t.isEnabled).length;

    // Time-series mock data for charts
    const now = new Date();
    const tokenTimeSeries = Array.from({ length: 12 }).map((_, i) => {
      const timeLabel = new Date(now.getTime() - (11 - i) * 5 * 60 * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      return {
        time: timeLabel,
        tokensPerSec: Math.floor(1200 + Math.sin(i) * 500 + Math.random() * 300),
        cpuPercent: parseFloat((15 + Math.cos(i) * 8 + Math.random() * 5).toFixed(1)),
        memoryMb: 450 + i * 25 + Math.floor(Math.random() * 20),
        activeThreads: Math.floor(2 + (i % 4) + Math.random()),
      };
    });

    const categoryBreakdown = [
      { name: 'Coding & Dev', count: allAgents.filter(a => a.category === 'coding').length, tokens: 1250000 },
      { name: 'Research & Web', count: allAgents.filter(a => a.category === 'research').length, tokens: 670000 },
      { name: 'Kernel System', count: allAgents.filter(a => a.category === 'system').length, tokens: 489200 },
      { name: 'Automation', count: allAgents.filter(a => a.category === 'automation').length, tokens: 780000 },
      { name: 'Security Audit', count: allAgents.filter(a => a.category === 'security').length, tokens: 410000 },
    ];

    return NextResponse.json({
      success: true,
      data: {
        summary: {
          totalAgents: allAgents.length,
          activeProcesses: activeProcessesCount,
          totalExecutions,
          totalTokens,
          memoryUsedTotalMb,
          activeTools: activeToolsCount,
          totalProviders: allProviders.length,
        },
        tokenTimeSeries,
        categoryBreakdown,
        providers: allProviders,
      }
    });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error?.message || 'Failed to fetch system metrics' }, { status: 500 });
  }
}
