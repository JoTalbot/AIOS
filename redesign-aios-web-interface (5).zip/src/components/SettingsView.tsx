'use client';

import React, { useState } from 'react';
import {
  Settings,
  Zap,
  Server,
  Database,
  CheckCircle2,
  RefreshCw,
  Sliders,
  ShieldCheck,
  Globe
} from 'lucide-react';

interface SettingsViewProps {
  providers: any[];
  onUpdateProvider: (provData: any) => void;
  onResetSeed: () => void;
  loading: boolean;
}

export default function SettingsView({
  providers,
  onUpdateProvider,
  onResetSeed,
  loading,
}: SettingsViewProps) {
  const [seedSuccess, setSeedSuccess] = useState(false);

  const handleSetDefault = (providerId: number) => {
    onUpdateProvider({
      id: providerId,
      isDefault: true,
      status: 'connected',
    });
  };

  const handleTriggerSeed = async () => {
    setSeedSuccess(false);
    await onResetSeed();
    setSeedSuccess(true);
    setTimeout(() => setSeedSuccess(false), 3000);
  };

  return (
    <div className="p-4 lg:p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight flex items-center space-x-2">
            <Settings className="w-5 h-5 text-cyan-400" />
            <span>LLM Gateway Router & AIOS System Configuration</span>
          </h1>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Configure dynamic LLM providers, local Ollama daemons, API fallbacks, and kernel seed state.
          </p>
        </div>

        <button
          onClick={handleTriggerSeed}
          disabled={loading}
          className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-mono font-semibold flex items-center space-x-2 transition-all cursor-pointer shrink-0"
        >
          <Database className="w-4 h-4 text-cyan-400" />
          <span>Reset / Re-Seed Database</span>
        </button>
      </div>

      {seedSuccess && (
        <div className="p-3 rounded-xl bg-emerald-950/80 border border-emerald-700 text-emerald-300 text-xs font-mono flex items-center space-x-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>Database successfully reset and seeded with AIOS default agents, MCP tools, and processes!</span>
        </div>
      )}

      {/* LLM Providers Routing Table */}
      <div className="glass-panel p-5 rounded-2xl border border-slate-800 space-y-4">
        <h2 className="text-sm font-bold text-white flex items-center space-x-2 font-mono">
          <Server className="w-4 h-4 text-cyan-400" />
          <span>LLM Model Provider Gateway Status</span>
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {providers.map((p) => {
            const isDefault = p.isDefault;
            const isLocal = p.isLocal;

            return (
              <div
                key={p.id}
                className={`glass-panel p-4 rounded-xl border space-y-3 transition-all ${
                  isDefault ? 'border-cyan-600 bg-cyan-950/20' : 'border-slate-800 bg-slate-900/60'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Globe className="w-4 h-4 text-cyan-400" />
                    <h3 className="font-bold text-sm text-white">{p.name}</h3>
                  </div>

                  {isDefault && (
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-cyan-950 text-cyan-300 border border-cyan-700">
                      DEFAULT GATEWAY
                    </span>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-2 text-[10px] font-mono bg-slate-950 p-2.5 rounded-lg border border-slate-800">
                  <div>
                    <span className="text-slate-500 block">Latency</span>
                    <span className="text-emerald-400 font-semibold">{p.latencyMs}ms</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Type</span>
                    <span className="text-indigo-300 font-semibold">{isLocal ? 'Local Daemon' : 'Cloud API'}</span>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-1">
                  <span className="text-[10px] font-mono text-slate-400">
                    Tokens: <strong className="text-slate-200">{((p.totalTokensUsed || 0) / 1000).toFixed(0)}k</strong>
                  </span>

                  {!isDefault && (
                    <button
                      onClick={() => handleSetDefault(p.id)}
                      className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-cyan-600 text-slate-300 hover:text-white text-[10px] font-mono font-semibold transition-colors cursor-pointer"
                    >
                      Set Default
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
