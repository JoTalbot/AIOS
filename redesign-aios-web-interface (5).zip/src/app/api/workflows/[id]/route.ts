import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { workflows } from '@/db/schema';
import { eq } from 'drizzle-orm';

export async function PUT(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const wfId = parseInt(id, 10);
    if (isNaN(wfId)) {
      return NextResponse.json({ success: false, error: 'Invalid workflow ID' }, { status: 400 });
    }

    const body = await request.json();
    const [updated] = await db.update(workflows)
      .set(body)
      .where(eq(workflows.id, wfId))
      .returning();

    return NextResponse.json({ success: true, data: updated });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error?.message || 'Failed to update workflow' }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const wfId = parseInt(id, 10);
    if (isNaN(wfId)) {
      return NextResponse.json({ success: false, error: 'Invalid workflow ID' }, { status: 400 });
    }

    await db.delete(workflows).where(eq(workflows.id, wfId));
    return NextResponse.json({ success: true, message: 'Workflow deleted' });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error?.message || 'Failed to delete workflow' }, { status: 500 });
  }
}
