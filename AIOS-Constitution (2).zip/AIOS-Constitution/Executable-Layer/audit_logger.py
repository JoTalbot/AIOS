"""
AIOS Audit Logger v2.1.1

Stores constitutional decisions and execution events.
"""

import json
from datetime import datetime, timezone


class AuditLogger:
    def __init__(self, file_path="audit_log.jsonl"):
        self.file_path = file_path

    def record(self, event: dict):
        event["timestamp"] = datetime.now(timezone.utc).isoformat()

        with open(self.file_path, "a", encoding="utf-8") as log:
            log.write(json.dumps(event, ensure_ascii=False) + "\n")

        return event
