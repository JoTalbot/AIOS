# AIOS

Self-evolving distributed operating system for application intelligence,
automated testing, API generation, skill evolution and collective learning.
Powered by the Octopus Runtime.

## Components

- **Constitution and policies** — rule loading and runtime decision pipeline.
- **Orchestrator** — sequential task execution with constitutional evaluation.
- **SQLite persistence** — audit events, approvals, memory, knowledge graph and
evolution records.
- **MCP gateway** — JSON-RPC 2.0 tool/resource/prompt interface.
- **REST API** — Starlette application exposing runtime subsystems.

## Quick start (development)

```bash
python -m pip install -r requirements.txt
python -m pytest -q
python demo.py
```

## Docker (recommended)

```bash
docker-compose up -d --build
curl http://localhost:8000/health
curl http://localhost:8000/metrics
```

## Monitoring

```bash
python monitor.py --url http://localhost:8000 --interval 30
```

## Web Dashboard (v4.0)

```bash
python run_dashboard.py
# Open http://127.0.0.1:8080
```

## v4.1 Features (Alpha)

- **Federation** — multi-node coordination
- **ML Planner Scorer** — intelligent plan optimization
- **Multi-Agent Orchestration** — dynamic teams
- **Constitution Evolver** — self-evolving rules
- **Web Dashboard** — real-time monitoring
- **Capability Marketplace** — publish & discover capabilities
- **Python SDK** — official client library
- **Kubernetes** — deployment manifests

**Current version:** 9.0.0-alpha.21 (925 tests passing)

Run a local REST service (requires authentication by default):

```bash
export AIOS_API_KEYS='{"local-development-key":{"subject":"developer","roles":["admin"]}}'
python run_rest_api.py --host 127.0.0.1 --port 8000 --db ./aios.sqlite
curl -H 'Authorization: Bearer local-development-key' http://127.0.0.1:8000/api/v1/stats
```

For the standalone MCP HTTP endpoint:

```bash
export AIOS_API_KEYS='{"local-development-key":{"subject":"developer","roles":["admin"]}}'
python run_mcp_server.py --host 127.0.0.1 --port 8471 --db ./aios.sqlite
```

`GET /health` is public. Every other HTTP endpoint fails closed with `503` if
no API keys are configured and responds with `401` without a valid bearer key.

## Testing

```bash
python -m pytest -q
```

The suite covers persistence, constitutional policy, orchestration, MCP,
REST, evolution state transitions and API security regressions.

## Security

Read [SECURITY.md](SECURITY.md) before deploying. In particular, use TLS, a
secret manager, a persistent database and a reverse proxy; do not bind a
production service directly to a public interface.
