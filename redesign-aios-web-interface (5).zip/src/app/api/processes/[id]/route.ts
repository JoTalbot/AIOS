import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { agentProcesses, systemLogs } from '@/db/schema';
import { eq } from 'drizzle-orm';

export async function PUT(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const procId = parseInt(id, 10);
    if (isNaN(procId)) {
      return NextResponse.json({ success: false, error: 'Invalid process ID' }, { status: 400 });
    }

    const body = await request.json();
    const { action, status, currentStep, progressPct } = body;

    let updatedStatus = status;
    let endedAt = null;

    if (action === 'kill' || action === 'terminate') {
      updatedStatus = 'terminated';
      endedAt = new Date();
    } else if (action === 'suspend') {
      updatedStatus = 'suspended';
    } else if (action === 'resume') {
      updatedStatus = 'running';
    }

    const updateData: any = {};
    if (updatedStatus) updateData.status = updatedStatus;
    if (endedAt) updateData.endedAt = endedAt;
    if (currentStep) updateData.currentStep = currentStep;
    if (typeof progressPct === 'number') updateData.progressPct = progressPct;

    const [proc] = await db.update(agentProcesses)
      .set(updateData)
      .where(eq(agentProcesses.id, procId))
      .returning();

    if (!proc) {
      return NextResponse.json({ success: false, error: 'Process not found' }, { status: 404 });
    }

    // Add log entry
    await db.insert(systemLogs).values({
      level: updatedStatus === 'terminated' ? 'warn' : 'info',
      category: 'scheduler',
      message: `Process PID-${proc.pid} state updated to '${proc.status}'`,
      agentId: proc.agentId,
      processId: proc.id,
    });

    return NextResponse.json({ success: true, data: proc });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error?.message || 'Failed to update process' }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const procId = parseInt(id, 10);
    if (isNaN(procId)) {
      return NextResponse.json({ success: false, error: 'Invalid process ID' }, { status: 400 });
    }

    await db.delete(agentProcesses).where(eq(agentProcesses.id, procId));
    return NextResponse.json({ success: true, message: 'Process removed' });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error?.message || 'Failed to delete process' }, { status: 500 });
  }
}
