'use client';

import React, { useState, useEffect } from 'react';
import Header from '@/components/Header';
import Sidebar from '@/components/Sidebar';
import DashboardView from '@/components/DashboardView';
import AgentHubView from '@/components/AgentHubView';
import AgentChatView from '@/components/AgentChatView';
import ProcessManagerView from '@/components/ProcessManagerView';
import ToolRegistryView from '@/components/ToolRegistryView';
import MemoryInspectorView from '@/components/MemoryInspectorView';
import WorkflowStudioView from '@/components/WorkflowStudioView';
import AuditLogsView from '@/components/AuditLogsView';
import SettingsView from '@/components/SettingsView';

export default function AIOSPage() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [loading, setLoading] = useState(false);
  const [loadingChatMessage, setLoadingChatMessage] = useState(false);

  // System States
  const [metrics, setMetrics] = useState<any>(null);
  const [agents, setAgents] = useState<any[]>([]);
  const [processes, setProcesses] = useState<any[]>([]);
  const [conversations, setConversations] = useState<any[]>([]);
  const [tools, setTools] = useState<any[]>([]);
  const [memories, setMemories] = useState<any[]>([]);
  const [workflows, setWorkflows] = useState<any[]>([]);
  const [logs, setLogs] = useState<any[]>([]);
  const [providers, setProviders] = useState<any[]>([]);

  const [activeConvId, setActiveConvId] = useState<number | null>(null);

  // Master Sync
  const fetchAllData = async () => {
    setLoading(true);
    try {
      const [
        metricsRes,
        agentsRes,
        procsRes,
        convsRes,
        toolsRes,
        memsRes,
        wfsRes,
        logsRes,
        provsRes
      ] = await Promise.all([
        fetch('/api/metrics').then(r => r.json()),
        fetch('/api/agents').then(r => r.json()),
        fetch('/api/processes').then(r => r.json()),
        fetch('/api/conversations').then(r => r.json()),
        fetch('/api/tools').then(r => r.json()),
        fetch('/api/memories').then(r => r.json()),
        fetch('/api/workflows').then(r => r.json()),
        fetch('/api/logs').then(r => r.json()),
        fetch('/api/providers').then(r => r.json()),
      ]);

      if (metricsRes.success) setMetrics(metricsRes.data);
      if (agentsRes.success) setAgents(agentsRes.data);
      if (procsRes.success) setProcesses(procsRes.data);
      if (convsRes.success) {
        setConversations(convsRes.data);
        if (convsRes.data.length > 0 && !activeConvId) {
          setActiveConvId(convsRes.data[0].id);
        }
      }
      if (toolsRes.success) setTools(toolsRes.data);
      if (memsRes.success) setMemories(memsRes.data);
      if (wfsRes.success) setWorkflows(wfsRes.data);
      if (logsRes.success) setLogs(logsRes.data);
      if (provsRes.success) setProviders(provsRes.data);
    } catch (error) {
      console.error('Failed to sync AIOS kernel data:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAllData();
  }, []);

  // Process Actions (Kill, Suspend, Resume)
  const handleProcessAction = async (procId: number, action: string) => {
    try {
      await fetch(`/api/processes/${procId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action })
      });
      fetchAllData();
    } catch (err) {
      console.error(err);
    }
  };

  // Spawn Process
  const handleSpawnProcess = async (agentId: number) => {
    try {
      await fetch('/api/processes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ agentId })
      });
      fetchAllData();
      setActiveTab('processes');
    } catch (err) {
      console.error(err);
    }
  };

  // Agent Creation
  const handleCreateAgent = async (agentData: any) => {
    try {
      await fetch('/api/agents', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(agentData)
      });
      fetchAllData();
    } catch (err) {
      console.error(err);
    }
  };

  const handleDeleteAgent = async (agentId: number) => {
    try {
      await fetch(`/api/agents/${agentId}`, { method: 'DELETE' });
      fetchAllData();
    } catch (err) {
      console.error(err);
    }
  };

  // Chat Actions
  const handleLaunchChat = async (agentId: number) => {
    try {
      const targetAgent = agents.find(a => a.id === agentId);
      const res = await fetch('/api/conversations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: `Task Thread with ${targetAgent?.name || 'Agent'}`,
          agentId,
          mode: 'single_agent'
        })
      });
      const data = await res.json();
      if (data.success && data.data) {
        await fetchAllData();
        setActiveConvId(data.data.id);
        setActiveTab('chat');
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleCreateConversation = async (title?: string, agentId?: number) => {
    try {
      const res = await fetch('/api/conversations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title: title || 'New AIOS Chat Session', agentId })
      });
      const data = await res.json();
      if (data.success && data.data) {
        await fetchAllData();
        setActiveConvId(data.data.id);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleDeleteConversation = async (convId: number) => {
    try {
      await fetch(`/api/conversations/${convId}`, { method: 'DELETE' });
      const updatedConvs = conversations.filter(c => c.id !== convId);
      setConversations(updatedConvs);
      if (activeConvId === convId) {
        setActiveConvId(updatedConvs.length > 0 ? updatedConvs[0].id : null);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleSendMessage = async (convId: number, content: string, agentId?: number) => {
    setLoadingChatMessage(true);
    try {
      await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ conversationId: convId, content, agentId })
      });
      await fetchAllData();
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingChatMessage(false);
    }
  };

  const handleApproveTool = async (msgId: number, approve: boolean) => {
    try {
      await fetch('/api/chat/approve', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messageId: msgId, approve })
      });
      fetchAllData();
    } catch (err) {
      console.error(err);
    }
  };

  // Tool Actions
  const handleToggleTool = async (toolId: number, isEnabled: boolean) => {
    try {
      await fetch(`/api/tools/${toolId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isEnabled })
      });
      fetchAllData();
    } catch (err) {
      console.error(err);
    }
  };

  const handleAddTool = async (toolData: any) => {
    try {
      await fetch('/api/tools', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(toolData)
      });
      fetchAllData();
    } catch (err) {
      console.error(err);
    }
  };

  const handleDeleteTool = async (toolId: number) => {
    try {
      await fetch(`/api/tools/${toolId}`, { method: 'DELETE' });
      fetchAllData();
    } catch (err) {
      console.error(err);
    }
  };

  // Memory Actions
  const handleAddMemory = async (memData: any) => {
    try {
      await fetch('/api/memories', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(memData)
      });
      fetchAllData();
    } catch (err) {
      console.error(err);
    }
  };

  const handleDeleteMemory = async (memId: number) => {
    try {
      await fetch(`/api/memories/${memId}`, { method: 'DELETE' });
      fetchAllData();
    } catch (err) {
      console.error(err);
    }
  };

  // Workflow Actions
  const handleTriggerWorkflow = async (wfId: number) => {
    try {
      await fetch('/api/workflows', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'trigger', id: wfId })
      });
      fetchAllData();
    } catch (err) {
      console.error(err);
    }
  };

  const handleCreateWorkflow = async (wfData: any) => {
    try {
      await fetch('/api/workflows', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(wfData)
      });
      fetchAllData();
    } catch (err) {
      console.error(err);
    }
  };

  const handleDeleteWorkflow = async (wfId: number) => {
    try {
      await fetch(`/api/workflows/${wfId}`, { method: 'DELETE' });
      fetchAllData();
    } catch (err) {
      console.error(err);
    }
  };

  // Provider Updates & Seed Reset
  const handleUpdateProvider = async (provData: any) => {
    try {
      await fetch('/api/providers', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(provData)
      });
      fetchAllData();
    } catch (err) {
      console.error(err);
    }
  };

  const handleResetSeed = async () => {
    try {
      await fetch('/api/seed', { method: 'POST' });
      await fetchAllData();
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="min-h-screen bg-[#070a12] text-slate-100 flex flex-col font-sans selection:bg-cyan-500 selection:text-white">
      {/* Top Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        metrics={metrics}
        onRefresh={fetchAllData}
        loading={loading}
      />

      <div className="flex-1 flex overflow-hidden">
        {/* Navigation Dock / Sidebar */}
        <Sidebar
          activeTab={activeTab}
          setActiveTab={setActiveTab}
        />

        {/* Main Content Workspace */}
        <main className="flex-1 overflow-y-auto min-w-0">
          {activeTab === 'dashboard' && (
            <DashboardView
              metrics={metrics}
              processes={processes}
              logs={logs}
              agents={agents}
              setActiveTab={setActiveTab}
              onRefresh={fetchAllData}
              onProcessAction={handleProcessAction}
              onSpawnProcess={handleSpawnProcess}
            />
          )}

          {activeTab === 'agents' && (
            <AgentHubView
              agents={agents}
              tools={tools}
              onCreateAgent={handleCreateAgent}
              onDeleteAgent={handleDeleteAgent}
              onLaunchChat={handleLaunchChat}
              onSpawnProcess={handleSpawnProcess}
            />
          )}

          {activeTab === 'chat' && (
            <AgentChatView
              conversations={conversations}
              agents={agents}
              activeConvId={activeConvId}
              onSelectConversation={setActiveConvId}
              onCreateConversation={handleCreateConversation}
              onDeleteConversation={handleDeleteConversation}
              onSendMessage={handleSendMessage}
              onApproveTool={handleApproveTool}
              loadingMessage={loadingChatMessage}
            />
          )}

          {activeTab === 'processes' && (
            <ProcessManagerView
              processes={processes}
              agents={agents}
              onProcessAction={handleProcessAction}
              onSpawnProcess={handleSpawnProcess}
              onRefresh={fetchAllData}
            />
          )}

          {activeTab === 'tools' && (
            <ToolRegistryView
              tools={tools}
              onToggleTool={handleToggleTool}
              onAddTool={handleAddTool}
              onDeleteTool={handleDeleteTool}
            />
          )}

          {activeTab === 'memory' && (
            <MemoryInspectorView
              memories={memories}
              agents={agents}
              onAddMemory={handleAddMemory}
              onDeleteMemory={handleDeleteMemory}
            />
          )}

          {activeTab === 'workflows' && (
            <WorkflowStudioView
              workflows={workflows}
              onTriggerWorkflow={handleTriggerWorkflow}
              onCreateWorkflow={handleCreateWorkflow}
              onDeleteWorkflow={handleDeleteWorkflow}
            />
          )}

          {activeTab === 'logs' && (
            <AuditLogsView logs={logs} />
          )}

          {activeTab === 'settings' && (
            <SettingsView
              providers={providers}
              onUpdateProvider={handleUpdateProvider}
              onResetSeed={handleResetSeed}
              loading={loading}
            />
          )}
        </main>
      </div>
    </div>
  );
}
