"""AIOS Deployment & Integration Layer v3.0.0

Continuous Constitutional Deployment manager (`DeploymentManager`).
Verifies constitutional readiness, zero unresolved critical alerts, and test suite pass rates before producing production container manifests.
"""

from __future__ import annotations

import yaml
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from .constitution_engine import ConstitutionEngine
    from .evolution_manager import EvolutionManager
    from .monitoring import SystemMonitor
    from .test_engine import TestEngine


@dataclass
class DeploymentReadinessReport:
    ready: bool
    timestamp: str
    checks: dict[str, Any]
    reasons: list[str]

    def to_dict(self) -> dict[str, Any]:
        return {
            "ready": self.ready,
            "timestamp": self.timestamp,
            "checks": self.checks,
            "reasons": self.reasons,
        }


class DeploymentManager:
    """Continuous Constitutional Deployment Controller."""

    def __init__(
        self,
        constitution_engine: Optional["ConstitutionEngine"] = None,
        evolution_manager: Optional["EvolutionManager"] = None,
        system_monitor: Optional["SystemMonitor"] = None,
        test_engine: Optional["TestEngine"] = None,
    ):
        self.constitution_engine = constitution_engine
        self.evolution_manager = evolution_manager
        self.system_monitor = system_monitor
        self.test_engine = test_engine

    def verify_production_readiness(self, proposal_id: Optional[str] = None) -> DeploymentReadinessReport:
        """Run complete pre-deployment verification pipeline."""
        reasons = []
        checks = {
            "constitution_healthy": True,
            "zero_critical_alerts": True,
            "evolution_approved": True,
            "tests_passed": True,
        }

        # 1. Check alerts
        if self.system_monitor:
            health = self.system_monitor.check_health()
            if health["status"] == "CRITICAL":
                checks["zero_critical_alerts"] = False
                reasons.append("SystemMonitor reports active CRITICAL alerts.")

        # 2. Check proposal readiness if proposal_id provided
        if self.evolution_manager and proposal_id:
            prop = self.evolution_manager.get_proposal(proposal_id)
            if not prop:
                checks["evolution_approved"] = False
                reasons.append(f"Evolution proposal '{proposal_id}' not found.")
            elif prop.get("stage") not in ("approval", "deployment"):
                checks["evolution_approved"] = False
                reasons.append(f"Proposal is in stage '{prop.get('stage')}', must be 'approval' or 'deployment'.")

        # 3. Check tests
        if self.test_engine:
            try:
                report = self.test_engine.run_all()
                if report.failed > 0 or report.errors > 0:
                    checks["tests_passed"] = False
                    reasons.append(f"Test suite has {report.failed} failures and {report.errors} errors.")
            except Exception as e:
                checks["tests_passed"] = False
                reasons.append(f"Test execution failed during check: {e}")

        ready = all(checks.values())
        return DeploymentReadinessReport(
            ready=ready,
            timestamp=datetime.now(timezone.utc).isoformat(),
            checks=checks,
            reasons=reasons,
        )

    def generate_docker_compose(self, version: str = "3.1.0", port: int = 8000) -> str:
        """Generate production docker-compose.yml configuration."""
        compose = {
            "version": "3.8",
            "services": {
                "aios-core": {
                    "image": f"aios/core:{version}",
                    "container_name": "aios_core_production",
                    "restart": "always",
                    "environment": [
                        "AIOS_LOG_LEVEL=INFO",
                        "AIOS_DB_PATH=/data/aios.db",
                        "AIOS_CONSTITUTION_DIR=/app/docs/constitution",
                        "AIOS_POLICIES_DIR=/app/policies",
                    ],
                    "ports": [f"{port}:8000"],
                    "volumes": [
                        "aios_data:/data",
                        "./docs/constitution:/app/docs/constitution:ro",
                    ],
                    "healthcheck": {
                        "test": ["CMD", "curl", "-f", f"http://localhost:{port}/health"],
                        "interval": "30s",
                        "timeout": "10s",
                        "retries": 3,
                    },
                }
            },
            "volumes": {
                "aios_data": {"driver": "local"},
            },
        }
        return yaml.dump(compose, sort_keys=False)

    def generate_k8s_manifest(self, namespace: str = "aios-system", replicas: int = 2) -> str:
        """Generate production Kubernetes Deployment & Service manifests."""
        deployment = {
            "apiVersion": "apps/v1",
            "kind": "Deployment",
            "metadata": {
                "name": "aios-core-deployment",
                "namespace": namespace,
                "labels": {"app": "aios-core"},
            },
            "spec": {
                "replicas": replicas,
                "selector": {"matchLabels": {"app": "aios-core"}},
                "template": {
                    "metadata": {"labels": {"app": "aios-core"}},
                    "spec": {
                        "containers": [
                            {
                                "name": "aios-core",
                                "image": "aios/core:3.1.0",
                                "ports": [{"containerPort": 8000}],
                                "env": [
                                    {"name": "AIOS_LOG_LEVEL", "value": "INFO"},
                                    {"name": "AIOS_DB_PATH", "value": "/data/aios.db"},
                                ],
                                "livenessProbe": {
                                    "httpGet": {"path": "/health", "port": 8000},
                                    "initialDelaySeconds": 15,
                                    "periodSeconds": 20,
                                },
                            }
                        ]
                    },
                },
            },
        }
        service = {
            "apiVersion": "v1",
            "kind": "Service",
            "metadata": {
                "name": "aios-core-service",
                "namespace": namespace,
            },
            "spec": {
                "type": "ClusterIP",
                "selector": {"app": "aios-core"},
                "ports": [{"port": 80, "targetPort": 8000, "protocol": "TCP"}],
            },
        }
        return yaml.dump(deployment, sort_keys=False) + "---\n" + yaml.dump(service, sort_keys=False)
