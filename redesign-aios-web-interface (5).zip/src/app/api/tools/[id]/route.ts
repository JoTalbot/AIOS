import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { tools } from '@/db/schema';
import { eq } from 'drizzle-orm';

export async function PUT(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const toolId = parseInt(id, 10);
    if (isNaN(toolId)) {
      return NextResponse.json({ success: false, error: 'Invalid tool ID' }, { status: 400 });
    }

    const body = await request.json();
    const [updated] = await db.update(tools)
      .set(body)
      .where(eq(tools.id, toolId))
      .returning();

    if (!updated) {
      return NextResponse.json({ success: false, error: 'Tool not found' }, { status: 404 });
    }

    return NextResponse.json({ success: true, data: updated });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error?.message || 'Failed to update tool' }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const toolId = parseInt(id, 10);
    if (isNaN(toolId)) {
      return NextResponse.json({ success: false, error: 'Invalid tool ID' }, { status: 400 });
    }

    await db.delete(tools).where(eq(tools.id, toolId));
    return NextResponse.json({ success: true, message: 'Tool removed' });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error?.message || 'Failed to delete tool' }, { status: 500 });
  }
}
