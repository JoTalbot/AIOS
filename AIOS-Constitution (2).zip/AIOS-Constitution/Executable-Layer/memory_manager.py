"""
AIOS Memory Manager Layer v2.1.1

Manages AIOS memory lifecycle and retrieval.
"""


class MemoryManager:
    def __init__(self):
        self.memory = []

    def store(self, item: dict):
        self.memory.append(item)
        return item

    def search(self, query):
        return [item for item in self.memory if query in str(item)]
