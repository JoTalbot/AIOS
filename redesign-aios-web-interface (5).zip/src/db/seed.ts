import { db } from './index';
import { agents, tools, agentProcesses, conversations, chatMessages, agentMemories, workflows, llmProviders, systemLogs } from './schema';
import { eq } from 'drizzle-orm';

export async function seedDatabase() {
  try {
    const existingAgents = await db.select().from(agents).limit(1);
    if (existingAgents.length > 0) {
      return; // Already seeded
    }

    console.log('Seeding AIOS Database...');

    // Seed Providers
    await db.insert(llmProviders).values([
      { name: 'OpenAI AIOS Gateway', providerKey: 'openai', isDefault: true, isLocal: false, status: 'connected', latencyMs: 190, totalTokensUsed: 142500, totalCostUsd: 0.42 },
      { name: 'Anthropic Claude Engine', providerKey: 'anthropic', isDefault: false, isLocal: false, status: 'connected', latencyMs: 220, totalTokensUsed: 89000, totalCostUsd: 0.28 },
      { name: 'DeepSeek Reasoner API', providerKey: 'deepseek', isDefault: false, isLocal: false, status: 'connected', latencyMs: 140, totalTokensUsed: 310000, totalCostUsd: 0.15 },
      { name: 'Ollama Local Daemon', providerKey: 'ollama', isDefault: false, isLocal: true, status: 'connected', latencyMs: 45, totalTokensUsed: 520000, totalCostUsd: 0.00 },
      { name: 'Groq LPU Accelerator', providerKey: 'groq', isDefault: false, isLocal: false, status: 'connected', latencyMs: 65, totalTokensUsed: 180000, totalCostUsd: 0.08 },
      { name: 'Google Gemini Pro Gateway', providerKey: 'google', isDefault: false, isLocal: false, status: 'connected', latencyMs: 210, totalTokensUsed: 64000, totalCostUsd: 0.09 },
    ]);

    // Seed Agents
    const createdAgents = await db.insert(agents).values([
      {
        name: 'Kernel Master Agent',
        slug: 'kernel-master',
        description: 'Core AIOS operating system manager for scheduling, memory management, and agent orchestration.',
        category: 'system',
        avatar: '⚡',
        systemPrompt: 'You are the AIOS Kernel Manager. You coordinate agent processes, allocate LLM context windows, and manage system resources.',
        model: 'gpt-4o',
        provider: 'openai',
        status: 'active',
        priority: 'high',
        memoryLimitMb: 2048,
        tools: ['execute_shell', 'read_write_file', 'memory_lookup', 'sql_query_engine'],
        totalExecutions: 342,
        totalTokens: 489200,
        avgLatencyMs: 180,
      },
      {
        name: 'Code Architect & Engineer',
        slug: 'code-architect',
        description: 'Expert software development assistant for Next.js, Rust, Python, TypeScript, refactoring, and code analysis.',
        category: 'coding',
        avatar: '💻',
        systemPrompt: 'You are an expert full-stack engineer and software architect. Write clean, efficient, bug-free production code with full TypeScript types.',
        model: 'claude-3.5-sonnet',
        provider: 'anthropic',
        status: 'active',
        priority: 'high',
        memoryLimitMb: 1024,
        tools: ['read_write_file', 'python_interpreter', 'execute_shell'],
        totalExecutions: 890,
        totalTokens: 1250000,
        avgLatencyMs: 240,
      },
      {
        name: 'Autonomous Web Research Agent',
        slug: 'web-researcher',
        description: 'Deep web search, information extraction, link scraping, and real-time news & facts synthesis.',
        category: 'research',
        avatar: '🌐',
        systemPrompt: 'You are an autonomous web researcher. Browse web sources, synthesize complex multi-domain facts, and output concise structured summaries.',
        model: 'deepseek-r1',
        provider: 'deepseek',
        status: 'active',
        priority: 'medium',
        memoryLimitMb: 512,
        tools: ['web_search_mcp', 'mcp_browser_use', 'http_api_fetch'],
        totalExecutions: 412,
        totalTokens: 670000,
        avgLatencyMs: 310,
      },
      {
        name: 'Data Analyst & Viz Agent',
        slug: 'data-analyst',
        description: 'Statistical processing, CSV/JSON analytical pipelines, SQL query execution, and data visualization generation.',
        category: 'analytics',
        avatar: '📊',
        systemPrompt: 'You are a Senior Data Analyst. Analyze complex datasets, run SQL queries, calculate metrics, and provide data-driven insights.',
        model: 'gpt-4o',
        provider: 'openai',
        status: 'idle',
        priority: 'medium',
        memoryLimitMb: 768,
        tools: ['sql_query_engine', 'python_interpreter', 'read_write_file'],
        totalExecutions: 198,
        totalTokens: 320000,
        avgLatencyMs: 220,
      },
      {
        name: 'Workflow Pipeline Automator',
        slug: 'workflow-automator',
        description: 'Orchestrates step-by-step multi-agent pipelines, webhook triggers, and automated task execution chains.',
        category: 'automation',
        avatar: '⚙️',
        systemPrompt: 'You are the AIOS Automation Engine. Construct multi-step agent workflows, handle triggers, and verify step completions.',
        model: 'llama-3.3-70b',
        provider: 'groq',
        status: 'active',
        priority: 'high',
        memoryLimitMb: 512,
        tools: ['http_api_fetch', 'memory_lookup', 'execute_shell'],
        totalExecutions: 520,
        totalTokens: 780000,
        avgLatencyMs: 95,
      },
      {
        name: 'Security Sentinel & Audit',
        slug: 'security-sentinel',
        description: 'Monitors tool call execution risks, audits system call logs, verifies permissions, and scans code for security vulnerabilities.',
        category: 'security',
        avatar: '🛡️',
        systemPrompt: 'You are the AIOS Security Audit Sentinel. Inspect incoming actions, flag dangerous tool execution requests, and enforce safety policies.',
        model: 'gpt-4o-mini',
        provider: 'openai',
        status: 'active',
        priority: 'high',
        memoryLimitMb: 512,
        tools: ['execute_shell', 'memory_lookup'],
        totalExecutions: 1240,
        totalTokens: 410000,
        avgLatencyMs: 110,
      }
    ]).returning();

    // Seed Tools
    await db.insert(tools).values([
      {
        name: 'Shell Exec',
        slug: 'execute_shell',
        description: 'Execute sandboxed terminal commands and system shell scripts in isolated Linux container.',
        category: 'shell',
        isMcp: false,
        riskLevel: 'dangerous',
        isEnabled: true,
        totalCalls: 340,
        avgLatencyMs: 180,
        parametersSchema: { command: { type: 'string', description: 'Bash command to run' }, workdir: { type: 'string', description: 'Target folder' } }
      },
      {
        name: 'Virtual File System',
        slug: 'read_write_file',
        description: 'Read, write, edit, and list workspace files in the AIOS persistent virtual disk.',
        category: 'file_system',
        isMcp: false,
        riskLevel: 'moderate',
        isEnabled: true,
        totalCalls: 890,
        avgLatencyMs: 40,
        parametersSchema: { action: { type: 'string', enum: ['read', 'write', 'list'] }, path: { type: 'string' }, content: { type: 'string' } }
      },
      {
        name: 'MCP Web Search Engine',
        slug: 'web_search_mcp',
        description: 'Model Context Protocol server integration for live web searching and web page fetching.',
        category: 'web_browsing',
        isMcp: true,
        mcpServerUrl: 'http://localhost:8001/mcp/websearch',
        riskLevel: 'safe',
        isEnabled: true,
        totalCalls: 1250,
        avgLatencyMs: 290,
        parametersSchema: { query: { type: 'string' }, maxResults: { type: 'number', default: 5 } }
      },
      {
        name: 'Postgres SQL Engine',
        slug: 'sql_query_engine',
        description: 'Direct SQL query runner connected to AIOS PostgreSQL relational database.',
        category: 'database',
        isMcp: false,
        riskLevel: 'moderate',
        isEnabled: true,
        totalCalls: 410,
        avgLatencyMs: 65,
        parametersSchema: { query: { type: 'string', description: 'PostgreSQL SELECT/INSERT query' } }
      },
      {
        name: 'Python Sandbox Interpreter',
        slug: 'python_interpreter',
        description: 'Executes Python 3 scripts with NumPy, Pandas, Matplotlib, and scikit-learn in sandbox.',
        category: 'code_interpreter',
        isMcp: false,
        riskLevel: 'moderate',
        isEnabled: true,
        totalCalls: 530,
        avgLatencyMs: 450,
        parametersSchema: { code: { type: 'string', description: 'Python code block' } }
      },
      {
        name: 'Kernel Vector Memory Lookup',
        slug: 'memory_lookup',
        description: 'Access long-term semantic context store and retrieval memory for agents.',
        category: 'system',
        isMcp: false,
        riskLevel: 'safe',
        isEnabled: true,
        totalCalls: 2100,
        avgLatencyMs: 15,
        parametersSchema: { query: { type: 'string' }, agentSlug: { type: 'string' }, limit: { type: 'number' } }
      },
      {
        name: 'HTTP API Gateway Client',
        slug: 'http_api_fetch',
        description: 'Send custom REST / JSON HTTP API requests to external web services.',
        category: 'api_mcp',
        isMcp: true,
        mcpServerUrl: 'http://localhost:8002/mcp/http',
        riskLevel: 'safe',
        isEnabled: true,
        totalCalls: 620,
        avgLatencyMs: 140,
        parametersSchema: { url: { type: 'string' }, method: { type: 'string' }, headers: { type: 'object' }, body: { type: 'object' } }
      },
      {
        name: 'MCP Headless Browser',
        slug: 'mcp_browser_use',
        description: 'Headless Chrome browser automation tool for filling forms, clicking elements, taking screenshots.',
        category: 'web_browsing',
        isMcp: true,
        mcpServerUrl: 'http://localhost:8003/mcp/browser',
        riskLevel: 'moderate',
        isEnabled: true,
        totalCalls: 180,
        avgLatencyMs: 820,
        parametersSchema: { url: { type: 'string' }, actions: { type: 'array' } }
      }
    ]);

    // Seed Active Processes
    if (createdAgents.length > 0) {
      await db.insert(agentProcesses).values([
        {
          pid: 1024,
          agentId: createdAgents[0].id, // Kernel Master
          processName: 'AIOS Core System Daemon',
          status: 'running',
          priority: 'high',
          memoryUsedMb: 184,
          tokensUsed: 42100,
          currentStep: 'Monitoring event bus & context queue',
          callStack: ['kernel_main()', 'scheduler_loop()', 'poll_events()'],
          cpuUsagePct: 8.4,
          progressPct: 100,
        },
        {
          pid: 1042,
          agentId: createdAgents[1].id, // Code Architect
          processName: 'Refactor AST Analyzer Task',
          status: 'running',
          priority: 'high',
          memoryUsedMb: 310,
          tokensUsed: 89400,
          currentStep: 'Generating Next.js Server Components',
          callStack: ['agent_execute()', 'ast_transform()', 'emit_ts()'],
          cpuUsagePct: 24.1,
          progressPct: 68,
        },
        {
          pid: 1058,
          agentId: createdAgents[2].id, // Web Researcher
          processName: 'MCP Crawling Worker #3',
          status: 'waiting',
          priority: 'medium',
          memoryUsedMb: 128,
          tokensUsed: 21500,
          currentStep: 'Awaiting HTTP web response payload',
          callStack: ['mcp_request()', 'await_stream()'],
          cpuUsagePct: 1.2,
          progressPct: 45,
        },
        {
          pid: 1089,
          agentId: createdAgents[4].id, // Workflow Automator
          processName: 'Cron Scheduled DB Cleanup',
          status: 'ready',
          priority: 'low',
          memoryUsedMb: 92,
          tokensUsed: 6200,
          currentStep: 'Queued in FIFO scheduler',
          callStack: ['workflow_enqueue()'],
          cpuUsagePct: 0.0,
          progressPct: 0,
        }
      ]);

      // Seed Conversations & Messages
      const defaultConv = await db.insert(conversations).values([
        {
          title: 'AIOS Kernel OS Architecture & Status',
          agentId: createdAgents[0].id,
          mode: 'single_agent',
          pinned: true,
          tokenCount: 1420,
        },
        {
          title: 'Autonomous Code Refactoring & Security Audit',
          agentId: createdAgents[1].id,
          mode: 'multi_agent_team',
          pinned: false,
          tokenCount: 2890,
        }
      ]).returning();

      if (defaultConv.length > 0) {
        await db.insert(chatMessages).values([
          {
            conversationId: defaultConv[0].id,
            agentId: createdAgents[0].id,
            role: 'system',
            content: 'AIOS Kernel v2.4.0 online. All subsystems (LLM Gateway, Vector Memory, MCP Tool Registry, Context Switcher) operational.',
          },
          {
            conversationId: defaultConv[0].id,
            role: 'user',
            content: 'Check system process health, active LLM memory footprint, and tool execution statistics.',
          },
          {
            conversationId: defaultConv[0].id,
            agentId: createdAgents[0].id,
            role: 'agent',
            content: 'Initiating AIOS Kernel system diagnostic check across all process threads...',
          },
          {
            conversationId: defaultConv[0].id,
            agentId: createdAgents[0].id,
            role: 'tool_call',
            content: 'Executing system check via execute_shell',
            toolName: 'execute_shell',
            toolArgs: { command: 'aios-ctl status --verbose' },
            executionTimeMs: 120,
            requiresApproval: false,
            approvalStatus: 'approved',
          },
          {
            conversationId: defaultConv[0].id,
            agentId: createdAgents[0].id,
            role: 'tool_result',
            content: 'Tool Output: 4 active process threads, GPU context cache 84% hit rate, 0 queue congestion, total token velocity: 1,840 tok/s.',
            toolName: 'execute_shell',
            executionTimeMs: 120,
          },
          {
            conversationId: defaultConv[0].id,
            agentId: createdAgents[0].id,
            role: 'agent',
            content: `### 🛡️ AIOS Kernel Health Diagnostic Summary

- **Active Agents:** 6 registered, 4 running in kernel scheduler
- **LLM Gateway:** OpenAI (Default), Anthropic, DeepSeek, Groq, Ollama connected
- **Memory Footprint:** 714 MB total allocated across processes
- **Token Throughput:** ~1,840 tokens/sec stream capacity
- **MCP Tool Registry:** 8 tools active with 0 pending approvals

All AIOS sub-routines are operating at peak throughput. How can I assist you with agent process management or automated task pipelines today?`,
            tokensUsed: 280,
          }
        ]);
      }

      // Seed Agent Memories
      await db.insert(agentMemories).values([
        {
          agentId: createdAgents[0].id,
          memoryType: 'semantic_kv',
          key: 'system_max_context_limit',
          value: '128000 tokens for GPT-4o, 200000 tokens for Claude 3.5 Sonnet',
          relevanceScore: 0.98,
          accessCount: 42,
        },
        {
          agentId: createdAgents[1].id,
          memoryType: 'long_term',
          key: 'code_style_guidelines',
          value: 'Always enforce TypeScript strict mode, clean Tailwind CSS v4 styling, server actions, and component modularity.',
          relevanceScore: 0.95,
          accessCount: 18,
        },
        {
          agentId: createdAgents[2].id,
          memoryType: 'episodic',
          key: 'last_web_crawl_cache',
          value: 'Scraped AIOS GitHub release notes v2.4.0 - added MCP protocol server layer and multi-thread context switcher.',
          relevanceScore: 0.88,
          accessCount: 9,
        }
      ]);

      // Seed Workflows
      await db.insert(workflows).values([
        {
          name: 'Nightly Code & Security Audit Pipeline',
          description: 'Automatically pulls repository changes, runs Security Sentinel scanner, and builds TypeScript project.',
          triggerType: 'cron',
          status: 'active',
          runCount: 14,
          lastRunAt: new Date(),
          steps: [
            { stepNumber: 1, title: 'Fetch Latest Code', agentSlug: 'code-architect', action: 'Execute Git Pull & AST scan', toolSlug: 'read_write_file' },
            { stepNumber: 2, title: 'Vulnerability Analysis', agentSlug: 'security-sentinel', action: 'Audit tool call permissions & inputs', toolSlug: 'execute_shell' },
            { stepNumber: 3, title: 'Generate Health Report', agentSlug: 'kernel-master', action: 'Synthesize log output into summary report' }
          ]
        },
        {
          name: 'Autonomous Web Intelligence Briefing',
          description: 'Crawl target domain topics daily, extract key AI ecosystem developments, and write report.',
          triggerType: 'manual',
          status: 'active',
          runCount: 8,
          steps: [
            { stepNumber: 1, title: 'Multi-Source Search', agentSlug: 'web-researcher', action: 'Search web for AI agent frameworks', toolSlug: 'web_search_mcp' },
            { stepNumber: 2, title: 'Data Filtering & CSV Output', agentSlug: 'data-analyst', action: 'Process scraped results & rank by impact', toolSlug: 'python_interpreter' }
          ]
        }
      ]);

      // Seed System Logs
      await db.insert(systemLogs).values([
        { level: 'info', category: 'scheduler', message: 'AIOS Kernel context scheduler booted with priority queue scheduling strategy.' },
        { level: 'info', category: 'mcp_tool', message: 'Loaded 8 MCP & Native tools into security runtime sandbox.' },
        { level: 'info', category: 'agent_exec', message: 'Kernel Master PID-1024 initialized memory buffer (2048 MB limit).' },
        { level: 'warn', category: 'security', message: 'Shell Exec tool requested by PID-1042 required safety verification check.' },
        { level: 'info', category: 'memory_gc', message: 'Kernel Memory Garbage Collection freed 142 MB expired context tokens.' }
      ]);
    }

    console.log('AIOS Database successfully seeded!');
  } catch (error) {
    console.error('Failed to seed AIOS database:', error);
  }
}
