import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { systemLogs } from '@/db/schema';
import { seedDatabase } from '@/db/seed';
import { desc, eq } from 'drizzle-orm';

export async function GET(request: NextRequest) {
  try {
    await seedDatabase();
    const searchParams = request.nextUrl.searchParams;
    const level = searchParams.get('level');
    const category = searchParams.get('category');

    let logs = await db.select().from(systemLogs).orderBy(desc(systemLogs.timestamp)).limit(100);

    if (level && level !== 'all') {
      logs = logs.filter(l => l.level === level);
    }

    if (category && category !== 'all') {
      logs = logs.filter(l => l.category === category);
    }

    return NextResponse.json({ success: true, data: logs });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error?.message || 'Failed to fetch logs' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { level, category, message, agentId, processId, details } = body;

    const [newLog] = await db.insert(systemLogs).values({
      level: level || 'info',
      category: category || 'system',
      message,
      agentId: agentId || null,
      processId: processId || null,
      details: details || null,
    }).returning();

    return NextResponse.json({ success: true, data: newLog });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error?.message || 'Failed to create log' }, { status: 500 });
  }
}
