"""
AIOS Runtime Policy Layer v2.1.1

Runtime enforcement layer for agent execution decisions.
"""

from constitution_engine import ConstitutionEngine


class RuntimePolicy:
    def __init__(self):
        self.engine = ConstitutionEngine()

    def request_execution(self, agent_action: dict) -> dict:
        decision = self.engine.evaluate(agent_action)

        return {
            "allowed": decision["decision"] == "ALLOW",
            "decision": decision["decision"],
            "constitution": decision["constitution_version"],
            "details": decision["details"],
        }


if __name__ == "__main__":
    runtime = RuntimePolicy()
    print(runtime.request_execution({
        "goal": "health_check",
        "scope": "node_local",
        "risk": "low",
        "reversible": True,
        "audit_log": True
    }))
