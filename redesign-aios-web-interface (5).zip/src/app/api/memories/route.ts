import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { agentMemories, agents } from '@/db/schema';
import { seedDatabase } from '@/db/seed';
import { desc, eq } from 'drizzle-orm';

export async function GET(request: NextRequest) {
  try {
    await seedDatabase();
    const searchParams = request.nextUrl.searchParams;
    const agentId = searchParams.get('agentId');
    const type = searchParams.get('type');

    let memories = await db
      .select({
        id: agentMemories.id,
        agentId: agentMemories.agentId,
        agentName: agents.name,
        agentAvatar: agents.avatar,
        memoryType: agentMemories.memoryType,
        key: agentMemories.key,
        value: agentMemories.value,
        relevanceScore: agentMemories.relevanceScore,
        accessCount: agentMemories.accessCount,
        lastAccessedAt: agentMemories.lastAccessedAt,
        createdAt: agentMemories.createdAt,
      })
      .from(agentMemories)
      .leftJoin(agents, eq(agentMemories.agentId, agents.id))
      .orderBy(desc(agentMemories.relevanceScore), desc(agentMemories.lastAccessedAt));

    if (agentId && agentId !== 'all') {
      const parsed = parseInt(agentId, 10);
      if (!isNaN(parsed)) {
        memories = memories.filter(m => m.agentId === parsed);
      }
    }

    if (type && type !== 'all') {
      memories = memories.filter(m => m.memoryType === type);
    }

    return NextResponse.json({ success: true, data: memories });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error?.message || 'Failed to fetch memories' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { agentId, memoryType, key, value, relevanceScore } = body;

    if (!key || !value) {
      return NextResponse.json({ success: false, error: 'Key and value are required' }, { status: 400 });
    }

    const [newMem] = await db.insert(agentMemories).values({
      agentId: agentId || null,
      memoryType: memoryType || 'short_term',
      key,
      value,
      relevanceScore: typeof relevanceScore === 'number' ? relevanceScore : 0.9,
      accessCount: 1,
    }).returning();

    return NextResponse.json({ success: true, data: newMem });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error?.message || 'Failed to store memory' }, { status: 500 });
  }
}
