'use client';

import React, { useState } from 'react';
import {
  Wrench,
  ShieldCheck,
  ShieldAlert,
  ShieldX,
  Plus,
  Server,
  Code2,
  CheckCircle2,
  ExternalLink,
  Trash2
} from 'lucide-react';

interface ToolRegistryViewProps {
  tools: any[];
  onToggleTool: (toolId: number, isEnabled: boolean) => void;
  onAddTool: (toolData: any) => void;
  onDeleteTool: (toolId: number) => void;
}

export default function ToolRegistryView({
  tools,
  onToggleTool,
  onAddTool,
  onDeleteTool,
}: ToolRegistryViewProps) {
  const [modalOpen, setModalOpen] = useState(false);
  const [filterCategory, setFilterCategory] = useState('all');

  const [formData, setFormData] = useState({
    name: '',
    description: '',
    category: 'shell',
    isMcp: true,
    mcpServerUrl: 'http://localhost:8000/mcp',
    riskLevel: 'safe',
  });

  const filteredTools = tools.filter((t) => {
    if (filterCategory === 'all') return true;
    return t.category === filterCategory;
  });

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAddTool(formData);
    setModalOpen(false);
    setFormData({
      name: '',
      description: '',
      category: 'shell',
      isMcp: true,
      mcpServerUrl: 'http://localhost:8000/mcp',
      riskLevel: 'safe',
    });
  };

  return (
    <div className="p-4 lg:p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight flex items-center space-x-2">
            <Wrench className="w-5 h-5 text-cyan-400" />
            <span>MCP Tool & Capability Registry</span>
          </h1>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Model Context Protocol (MCP) server endpoints and native sandbox capabilities.
          </p>
        </div>

        <button
          onClick={() => setModalOpen(true)}
          className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold flex items-center space-x-2 shadow-lg shadow-cyan-600/20 transition-all cursor-pointer shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Register MCP Server</span>
        </button>
      </div>

      {/* Category Pills */}
      <div className="flex items-center space-x-2 border-b border-slate-800/80 pb-3">
        {['all', 'shell', 'file_system', 'web_browsing', 'database', 'code_interpreter', 'api_mcp', 'system'].map((cat) => (
          <button
            key={cat}
            onClick={() => setFilterCategory(cat)}
            className={`px-3 py-1.5 rounded-xl text-xs font-mono capitalize transition-all cursor-pointer border ${
              filterCategory === cat
                ? 'bg-cyan-950 text-cyan-300 border-cyan-700 font-bold'
                : 'bg-slate-900/60 text-slate-400 border-slate-800 hover:text-slate-200'
            }`}
          >
            {cat.replace('_', ' ')}
          </button>
        ))}
      </div>

      {/* Tools Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredTools.map((tool) => {
          const isDangerous = tool.riskLevel === 'dangerous';
          const isModerate = tool.riskLevel === 'moderate';

          return (
            <div
              key={tool.id}
              className="glass-panel p-5 rounded-2xl border border-slate-800 hover:border-cyan-800/60 transition-all flex flex-col justify-between space-y-4"
            >
              <div className="space-y-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center space-x-2.5">
                    <div className="w-10 h-10 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center text-cyan-400 font-mono font-bold">
                      <Wrench className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="font-bold text-sm text-white">{tool.name}</h3>
                      <p className="text-[10px] font-mono text-cyan-400">{tool.slug}</p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => onDeleteTool(tool.id)}
                      className="text-slate-600 hover:text-rose-400 transition-colors p-1 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>

                    {/* Enable Toggle Switch */}
                    <button
                      onClick={() => onToggleTool(tool.id, !tool.isEnabled)}
                      className={`relative w-10 h-5 rounded-full transition-colors cursor-pointer ${
                        tool.isEnabled ? 'bg-cyan-600' : 'bg-slate-800'
                      }`}
                    >
                      <span className={`absolute top-0.5 left-0.5 w-4 h-4 rounded-full bg-white transition-transform ${
                        tool.isEnabled ? 'translate-x-5' : 'translate-x-0'
                      }`} />
                    </button>
                  </div>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed">
                  {tool.description}
                </p>
              </div>

              <div className="space-y-3 border-t border-slate-800/80 pt-3">
                <div className="flex items-center justify-between text-[11px] font-mono">
                  <div className="flex items-center space-x-1">
                    {tool.isMcp ? (
                      <span className="px-2 py-0.5 rounded bg-purple-950 text-purple-300 border border-purple-800 flex items-center space-x-1">
                        <Server className="w-2.5 h-2.5" />
                        <span>MCP Server</span>
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded bg-slate-900 text-slate-400 border border-slate-800">
                        Native Capability
                      </span>
                    )}
                  </div>

                  <span className={`px-2 py-0.5 rounded border flex items-center space-x-1 ${
                    isDangerous ? 'bg-rose-950 text-rose-300 border-rose-800' :
                    isModerate ? 'bg-amber-950 text-amber-300 border-amber-800' :
                    'bg-emerald-950 text-emerald-300 border-emerald-800'
                  }`}>
                    {isDangerous ? <ShieldX className="w-2.5 h-2.5" /> :
                     isModerate ? <ShieldAlert className="w-2.5 h-2.5" /> :
                     <ShieldCheck className="w-2.5 h-2.5" />}
                    <span className="capitalize">{tool.riskLevel} Risk</span>
                  </span>
                </div>

                {tool.mcpServerUrl && (
                  <div className="bg-slate-950 p-2 rounded-xl border border-slate-800 text-[10px] font-mono text-slate-400 truncate flex items-center justify-between">
                    <span className="truncate">{tool.mcpServerUrl}</span>
                    <ExternalLink className="w-3 h-3 text-slate-500 shrink-0 ml-1" />
                  </div>
                )}

                <div className="flex items-center justify-between text-[10px] font-mono text-slate-400">
                  <span>Total Calls: <strong className="text-slate-200">{tool.totalCalls || 0}</strong></span>
                  <span>Avg Latency: <strong className="text-cyan-400">{tool.avgLatencyMs || 120}ms</strong></span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Register MCP Server Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="glass-panel p-6 rounded-2xl border border-slate-800 w-full max-w-md space-y-4">
            <h2 className="text-base font-bold text-white flex items-center space-x-2">
              <Server className="w-5 h-5 text-purple-400" />
              <span>Register Model Context Protocol (MCP) Server</span>
            </h2>

            <form onSubmit={handleFormSubmit} className="space-y-3 font-mono text-xs">
              <div>
                <label className="block text-slate-300 mb-1">Tool Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. MCP GitHub Integration"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 focus:border-cyan-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Description *</label>
                <input
                  type="text"
                  required
                  placeholder="Capabilities provided..."
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 focus:border-cyan-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1">MCP Endpoint URL</label>
                <input
                  type="text"
                  value={formData.mcpServerUrl}
                  onChange={(e) => setFormData({ ...formData, mcpServerUrl: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 focus:border-cyan-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 mb-1">Category</label>
                  <select
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 focus:border-cyan-500 focus:outline-none"
                  >
                    <option value="shell">Shell Execution</option>
                    <option value="file_system">File System</option>
                    <option value="web_browsing">Web Browsing</option>
                    <option value="database">Database</option>
                    <option value="code_interpreter">Code Interpreter</option>
                    <option value="api_mcp">API Gateway</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 mb-1">Risk Policy</label>
                  <select
                    value={formData.riskLevel}
                    onChange={(e) => setFormData({ ...formData, riskLevel: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 focus:border-cyan-500 focus:outline-none"
                  >
                    <option value="safe">Safe (Auto-Approve)</option>
                    <option value="moderate">Moderate</option>
                    <option value="dangerous">Dangerous (Human Confirmation Required)</option>
                  </select>
                </div>
              </div>

              <div className="flex items-center justify-end space-x-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-900 text-slate-400 hover:text-slate-200 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold shadow-lg cursor-pointer"
                >
                  Register Tool
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
