import { pgTable, serial, text, integer, timestamp, boolean, json, doublePrecision } from 'drizzle-orm/pg-core';

export const agents = pgTable('agents', {
  id: serial('id').primaryKey(),
  name: text('name').notNull(),
  slug: text('slug').notNull().unique(),
  description: text('description').notNull(),
  category: text('category').notNull().default('general'), // coding, research, analytics, automation, creative, security, system
  avatar: text('avatar').notNull().default('🤖'),
  systemPrompt: text('system_prompt').notNull(),
  model: text('model').notNull().default('gpt-4o'),
  provider: text('provider').notNull().default('openai'),
  temperature: doublePrecision('temperature').notNull().default(0.7),
  maxTokens: integer('max_tokens').notNull().default(4096),
  status: text('status').notNull().default('idle'), // active, idle, paused, suspended, error
  priority: text('priority').notNull().default('medium'), // high, medium, low
  memoryLimitMb: integer('memory_limit_mb').notNull().default(512),
  tools: json('tools').$type<string[]>().default([]),
  totalExecutions: integer('total_executions').notNull().default(0),
  totalTokens: integer('total_tokens').notNull().default(0),
  avgLatencyMs: integer('avg_latency_ms').notNull().default(350),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

export const agentProcesses = pgTable('agent_processes', {
  id: serial('id').primaryKey(),
  pid: integer('pid').notNull(),
  agentId: integer('agent_id').references(() => agents.id),
  processName: text('process_name').notNull(),
  status: text('status').notNull().default('running'), // running, ready, waiting, suspended, terminated, failed
  priority: text('priority').notNull().default('medium'), // high, medium, low
  memoryUsedMb: integer('memory_used_mb').notNull().default(64),
  tokensUsed: integer('tokens_used').notNull().default(0),
  currentStep: text('current_step').default('Initializing thread'),
  callStack: json('call_stack').$type<string[]>().default([]),
  cpuUsagePct: doublePrecision('cpu_usage_pct').notNull().default(12.5),
  progressPct: integer('progress_pct').notNull().default(0),
  errorMessage: text('error_message'),
  startedAt: timestamp('started_at').defaultNow().notNull(),
  endedAt: timestamp('ended_at'),
});

export const conversations = pgTable('conversations', {
  id: serial('id').primaryKey(),
  title: text('title').notNull(),
  agentId: integer('agent_id').references(() => agents.id),
  mode: text('mode').notNull().default('single_agent'), // single_agent, multi_agent_team, system_shell
  pinned: boolean('pinned').notNull().default(false),
  tokenCount: integer('token_count').notNull().default(0),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

export const chatMessages = pgTable('chat_messages', {
  id: serial('id').primaryKey(),
  conversationId: integer('conversation_id').references(() => conversations.id, { onDelete: 'cascade' }).notNull(),
  agentId: integer('agent_id').references(() => agents.id),
  role: text('role').notNull(), // user, agent, system, tool_call, tool_result
  content: text('content').notNull(),
  toolName: text('tool_name'),
  toolArgs: json('tool_args'),
  toolResult: json('tool_result'),
  executionTimeMs: integer('execution_time_ms'),
  tokensUsed: integer('tokens_used').default(0),
  requiresApproval: boolean('requires_approval').default(false),
  approvalStatus: text('approval_status').default('none'), // none, pending, approved, rejected
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const agentMemories = pgTable('agent_memories', {
  id: serial('id').primaryKey(),
  agentId: integer('agent_id').references(() => agents.id, { onDelete: 'cascade' }),
  memoryType: text('memory_type').notNull().default('short_term'), // short_term, long_term, episodic, semantic_kv
  key: text('key').notNull(),
  value: text('value').notNull(),
  relevanceScore: doublePrecision('relevance_score').notNull().default(0.9),
  accessCount: integer('access_count').notNull().default(1),
  lastAccessedAt: timestamp('last_accessed_at').defaultNow().notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const tools = pgTable('tools', {
  id: serial('id').primaryKey(),
  name: text('name').notNull(),
  slug: text('slug').notNull().unique(),
  description: text('description').notNull(),
  category: text('category').notNull().default('system'), // file_system, web_browsing, shell, code_interpreter, api_mcp, database, security
  isMcp: boolean('is_mcp').notNull().default(false),
  mcpServerUrl: text('mcp_server_url'),
  parametersSchema: json('parameters_schema'),
  riskLevel: text('risk_level').notNull().default('safe'), // safe, moderate, dangerous
  isEnabled: boolean('is_enabled').notNull().default(true),
  totalCalls: integer('total_calls').notNull().default(0),
  avgLatencyMs: integer('avg_latency_ms').notNull().default(120),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const systemLogs = pgTable('system_logs', {
  id: serial('id').primaryKey(),
  level: text('level').notNull().default('info'), // info, warn, error, security, kernel
  category: text('category').notNull().default('system'), // scheduler, agent_exec, mcp_tool, memory_gc, auth
  message: text('message').notNull(),
  agentId: integer('agent_id'),
  processId: integer('process_id'),
  details: json('details'),
  timestamp: timestamp('timestamp').defaultNow().notNull(),
});

export const workflows = pgTable('workflows', {
  id: serial('id').primaryKey(),
  name: text('name').notNull(),
  description: text('description').notNull(),
  triggerType: text('trigger_type').notNull().default('manual'), // manual, cron, event
  steps: json('steps').$type<Array<{
    stepNumber: number;
    title: string;
    agentSlug: string;
    action: string;
    toolSlug?: string;
    params?: any;
  }>>().notNull(),
  status: text('status').notNull().default('active'), // active, draft, paused
  lastRunAt: timestamp('last_run_at'),
  runCount: integer('run_count').notNull().default(0),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const llmProviders = pgTable('llm_providers', {
  id: serial('id').primaryKey(),
  name: text('name').notNull(),
  providerKey: text('provider_key').notNull().unique(), // openai, anthropic, ollama, groq, deepseek, google
  apiBaseUrl: text('api_base_url'),
  apiKeyEnvVar: text('api_key_env_var'),
  isDefault: boolean('is_default').notNull().default(false),
  isLocal: boolean('is_local').notNull().default(false),
  status: text('status').notNull().default('connected'), // connected, disconnected, rate_limited
  latencyMs: integer('latency_ms').notNull().default(180),
  totalTokensUsed: integer('total_tokens_used').notNull().default(0),
  totalCostUsd: doublePrecision('total_cost_usd').notNull().default(0.0),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});
