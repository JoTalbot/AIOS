import { useState } from "react";
import { Share2, Database, Cpu, Bot, ListChecks, Scale } from "lucide-react";
import { Card, PanelHeader, Badge } from "../components/ui/primitives";
import { KG } from "../data/mockData";
import type { KgNode } from "../types";

const POS: Record<string, { x: number; y: number }> = {
  orchestrator: { x: 300, y: 210 },
  warden: { x: 300, y: 70 },
  scout: { x: 140, y: 120 },
  echo: { x: 140, y: 320 },
  "task-publish": { x: 460, y: 300 },
  "task-scan": { x: 60, y: 220 },
  "rule-art14": { x: 450, y: 110 },
  "rule-art9": { x: 300, y: 365 },
  "mem-listings": { x: 95, y: 350 },
  "model-ban": { x: 470, y: 210 },
};

const TYPE_META: Record<KgNode["type"], { color: string; icon: any; label: string }> = {
  agent: { color: "#818cf8", icon: Bot, label: "Agent" },
  rule: { color: "#fb7185", icon: Scale, label: "Rule" },
  task: { color: "#22d3ee", icon: ListChecks, label: "Task" },
  memory: { color: "#fbbf24", icon: Database, label: "Memory" },
  model: { color: "#a78bfa", icon: Cpu, label: "Model" },
};

export function KnowledgeGraph() {
  const [hover, setHover] = useState<string | null>(null);

  const neighbors = new Set<string>();
  if (hover) {
    neighbors.add(hover);
    KG.edges.forEach((e) => {
      if (e.source === hover) neighbors.add(e.target);
      if (e.target === hover) neighbors.add(e.source);
    });
  }

  const relatedEdges = hover ? KG.edges.filter((e) => e.source === hover || e.target === hover) : [];

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
        {(Object.keys(TYPE_META) as KgNode["type"][]).map((t) => {
          const count = KG.nodes.filter((n) => n.type === t).length;
          const m = TYPE_META[t];
          return (
            <Card key={t} className="flex items-center gap-3 p-3.5">
              <div className="grid h-9 w-9 place-items-center rounded-lg" style={{ background: `${m.color}1a`, color: m.color }}>
                <m.icon className="h-4 w-4" />
              </div>
              <div>
                <div className="text-lg font-extrabold tabular text-white">{count}</div>
                <div className="text-[10px] uppercase tracking-wide text-slate-500">{m.label}</div>
              </div>
            </Card>
          );
        })}
      </div>

      <div className="grid grid-cols-1 gap-5 xl:grid-cols-4">
        <Card className="xl:col-span-3">
          <PanelHeader
            icon={<Share2 className="h-[18px] w-[18px]" />}
            title="Federated Knowledge Graph"
            subtitle="Hover a node to trace relations"
            action={<Badge tone="indigo">{KG.edges.length} relations</Badge>}
          />
          <div className="overflow-hidden rounded-xl border border-white/[0.05] bg-[radial-gradient(circle_at_50%_40%,rgba(99,102,241,0.08),transparent_60%)]">
            <svg viewBox="0 0 540 420" className="w-full" style={{ aspectRatio: "540 / 420" }}>
              {/* edges */}
              {KG.edges.map((e, i) => {
                const a = POS[e.source];
                const b = POS[e.target];
                const dim = hover && !relatedEdges.includes(e);
                return (
                  <g key={i} opacity={dim ? 0.08 : hover ? 1 : 0.4}>
                    <line x1={a.x} y1={a.y} x2={b.x} y2={b.y} stroke={relatedEdges.includes(e) ? "#818cf8" : "#64748b"} strokeWidth={relatedEdges.includes(e) ? 1.6 : 1} />
                  </g>
                );
              })}
              {/* nodes */}
              {KG.nodes.map((n) => {
                const p = POS[n.id];
                const meta = TYPE_META[n.type];
                const dim = hover && !neighbors.has(n.id);
                const r = n.id === "orchestrator" ? 26 : 19;
                return (
                  <g
                    key={n.id}
                    transform={`translate(${p.x} ${p.y})`}
                    onMouseEnter={() => setHover(n.id)}
                    onMouseLeave={() => setHover(null)}
                    style={{ cursor: "pointer", opacity: dim ? 0.25 : 1, transition: "opacity .2s" }}
                  >
                    {n.id === "orchestrator" && <circle r={r + 8} fill="none" stroke={meta.color} strokeWidth="1" opacity="0.3" className="spin-slow" strokeDasharray="4 6" />}
                    <circle r={r} fill={`${meta.color}22`} stroke={meta.color} strokeWidth="2" />
                    <circle r={r - 7} fill={meta.color} opacity={hover === n.id ? 1 : 0.85} />
                    <text y={r + 13} textAnchor="middle" className="fill-slate-300" style={{ fontSize: 11, fontWeight: 600 }}>
                      {n.label}
                    </text>
                  </g>
                );
              })}
            </svg>
          </div>
        </Card>

        <Card>
          <PanelHeader icon={<Database className="h-[18px] w-[18px]" />} title="Node Inspector" subtitle={hover ? "selected" : "pick a node"} />
          {hover ? (
            (() => {
              const node = KG.nodes.find((n) => n.id === hover)!;
              const meta = TYPE_META[node.type];
              const out = KG.edges.filter((e) => e.source === hover);
              const inE = KG.edges.filter((e) => e.target === hover);
              return (
                <div>
                  <div className="rounded-xl border border-white/[0.06] p-4" style={{ background: `${meta.color}10` }}>
                    <div className="flex items-center gap-2">
                      <span className="h-3 w-3 rounded-full" style={{ background: meta.color }} />
                      <Badge tone="slate">{meta.label}</Badge>
                    </div>
                    <div className="mt-2 text-base font-bold text-white">{node.label}</div>
                    <div className="font-mono text-[10px] text-slate-500">{node.id}</div>
                  </div>
                  <div className="mt-4 space-y-3">
                    <RelGroup title="Outgoing" edges={out} nodes={KG.nodes} />
                    <RelGroup title="Incoming" edges={inE} nodes={KG.nodes} />
                    {out.length === 0 && inE.length === 0 && <p className="text-xs text-slate-500">Isolated node.</p>}
                  </div>
                </div>
              );
            })()
          ) : (
            <div className="grid h-48 place-items-center text-center text-sm text-slate-500">
              <div>
                <Share2 className="mx-auto mb-2 h-8 w-8 text-slate-700" />
                Hover any node to inspect its<br />relationships in the federation.
              </div>
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}

function RelGroup({ title, edges, nodes }: { title: string; edges: any[]; nodes: KgNode[] }) {
  if (!edges.length) return null;
  return (
    <div>
      <div className="mb-1.5 text-[10px] font-semibold uppercase tracking-wide text-slate-500">{title}</div>
      <div className="space-y-1.5">
        {edges.map((e, i) => {
          const otherId = title === "Outgoing" ? e.target : e.source;
          const other = nodes.find((n) => n.id === otherId);
          return (
            <div key={i} className="flex items-center justify-between rounded-lg bg-white/[0.02] px-2.5 py-1.5 text-xs">
              <span className="truncate font-medium text-slate-300">{other?.label}</span>
              <span className="ml-2 shrink-0 rounded bg-white/[0.06] px-1.5 py-0.5 text-[10px] text-slate-400">{e.relation}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
