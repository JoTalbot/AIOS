import { useEffect, useRef, useState } from "react";
import type {
  SystemStats,
  Series,
  ServiceInfo,
  OlxSummary,
  AuditEvent,
  AgentProfile,
  AndroidDevice,
  SafetyData,
  Subscription,
  HealthStatus,
} from "../types";
import {
  PLATFORMS,
  AGENTS,
  DEVICES,
  SERVICES,
  OLX_SUMMARY,
  SAFETY,
  SUBSCRIPTIONS,
  makeSeries,
  makeAuditEvent,
  seedAuditFeed,
} from "./mockData";

interface Snapshot {
  stats: SystemStats;
  series: Series;
  services: ServiceInfo[];
  olx: OlxSummary;
  audit: AuditEvent[];
  agents: AgentProfile[];
  devices: AndroidDevice[];
  safety: SafetyData;
  subscriptions: Subscription[];
}

function clamp(v: number, min: number, max: number) {
  return Math.max(min, Math.min(max, v));
}

function jitter(v: number, amp: number, min = 0, max = 100) {
  return clamp(v + (Math.random() - 0.5) * amp, min, max);
}

function shift(arr: number[], next: number) {
  const out = arr.slice(1);
  out.push(next);
  return out;
}

function initial(): Snapshot {
  return {
    stats: {
      version: "10.15.0",
      runtime: "Octopus v4.2",
      uptime_seconds: 6 * 86400 + 14 * 3600 + 26 * 60,
      total_tasks: 52683,
      completed_tasks: 52618,
      failed_tasks: 65,
      active_agents: AGENTS.filter((a) => a.status !== "idle").length,
      memory_nodes: 184240,
      registered_capabilities: 169,
      constitutional_articles: 67,
      compliance_ratio: 1.0,
      safety_score: SAFETY.safety_score,
      api_routes: 169,
      tests_passed: 1255,
      platforms: 9,
      tasks_per_min: 42,
      p95_latency_ms: 128,
    },
    series: {
      tasks: makeSeries(2, 24, 45, 30),
      compliance: makeSeries(6, 24, 99.4, 1.2),
      latency: makeSeries(10, 24, 130, 40),
      throughput: makeSeries(14, 24, 40, 26),
    },
    services: SERVICES.map((s) => ({ ...s })),
    olx: { ...OLX_SUMMARY },
    audit: seedAuditFeed(14),
    agents: AGENTS.map((a) => ({ ...a })),
    devices: DEVICES.map((d) => ({ ...d })),
    safety: {
      ...SAFETY,
      metrics: { ...SAFETY.metrics },
      thresholds: { ...SAFETY.thresholds },
      incidents: SAFETY.incidents.map((i) => ({ ...i })),
    },
    subscriptions: SUBSCRIPTIONS.map((s) => ({ ...s })),
  };
}

export interface UseLiveData extends Snapshot {
  health: HealthStatus;
  wsConnected: boolean;
  tick: number;
}

export function useLiveData(intervalMs = 2200): UseLiveData {
  const [snap, setSnap] = useState<Snapshot>(initial);
  const [tick, setTick] = useState(0);
  const [wsConnected, setWsConnected] = useState(false);
  const counter = useRef(0);

  // Simulate websocket handshake
  useEffect(() => {
    const t = setTimeout(() => setWsConnected(true), 900);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    const id = setInterval(() => {
      counter.current += 1;
      setTick((t) => t + 1);

      setSnap((prev) => {
        const newTasks = Math.floor(Math.random() * 4) + 1;
        const newFailed = Math.random() < 0.08 ? 1 : 0;
        const tpm = Math.round(jitter(prev.stats.tasks_per_min, 6, 24, 64));
        const latency = Math.round(jitter(prev.stats.p95_latency_ms, 22, 95, 240));
        const compliance = clamp(prev.stats.compliance_ratio + (Math.random() - 0.5) * 0.0012, 0.992, 1);
        const safety = clamp(prev.stats.safety_score + (Math.random() - 0.5) * 0.004, 0.94, 0.998);

        const lastTask = prev.series.tasks[prev.series.tasks.length - 1];
        const lastThroughput = prev.series.throughput[prev.series.throughput.length - 1];

        const services = prev.services.map((s) =>
          s.active
            ? { ...s, cpu: Math.round(jitter(s.cpu, 6, 1, 60)), mem: Math.round(jitter(s.mem, 14, 40, 700)) }
            : s
        );

        const devices = prev.devices.map((d) => {
          if (d.status === "offline") return d;
          const battery = d.status === "busy" ? clamp(d.battery - (Math.random() < 0.3 ? 1 : 0), 5, 100) : d.battery;
          return { ...d, battery };
        });

        const olx = {
          ...prev.olx,
          new_24h: Math.round(jitter(prev.olx.new_24h, 18, 2800, 4200)),
          ads_total: prev.olx.ads_total + (Math.random() < 0.4 ? 1 : 0),
          price_avg: Math.round(jitter(prev.olx.price_avg, 220, 44000, 53000)),
        };

        // Occasionally push a fresh audit event
        let audit = prev.audit;
        if (Math.random() < 0.55) {
          audit = [makeAuditEvent(), ...prev.audit].slice(0, 40);
        }

        const subscriptions = prev.subscriptions.map((s) =>
          s.active && Math.random() < 0.15 ? { ...s, matches: s.matches + (Math.random() < 0.6 ? 1 : 0) } : s
        );

        const safetyData: SafetyData = {
          ...prev.safety,
          metrics: Object.fromEntries(
            Object.entries(prev.safety.metrics).map(([k, v]) => [k, Number(jitter(v, 0.01, 0, 1).toFixed(3))])
          ),
        };

        const stats: SystemStats = {
          ...prev.stats,
          uptime_seconds: prev.stats.uptime_seconds + Math.round(intervalMs / 1000),
          total_tasks: prev.stats.total_tasks + newTasks,
          completed_tasks: prev.stats.completed_tasks + newTasks - newFailed,
          failed_tasks: prev.stats.failed_tasks + newFailed,
          memory_nodes: prev.stats.memory_nodes + Math.floor(Math.random() * 9),
          tasks_per_min: tpm,
          p95_latency_ms: latency,
          compliance_ratio: Number(compliance.toFixed(4)),
          safety_score: Number(safety.toFixed(4)),
        };

        return {
          stats,
          series: {
            tasks: shift(prev.series.tasks, Math.max(1, lastTask + Math.round((Math.random() - 0.4) * 10))),
            compliance: shift(prev.series.compliance, Number((compliance * 100).toFixed(2))),
            latency: shift(prev.series.latency, latency),
            throughput: shift(prev.series.throughput, Math.max(1, lastThroughput + Math.round((Math.random() - 0.5) * 8))),
          },
          services,
          olx,
          audit,
          agents: prev.agents,
          devices,
          safety: safetyData,
          subscriptions,
        };
      });
    }, intervalMs);

    return () => clearInterval(id);
  }, [intervalMs]);

  const health: HealthStatus = snap.stats.safety_score > 0.96 ? "ok" : snap.stats.safety_score > 0.9 ? "degraded" : "error";

  return { ...snap, health, wsConnected, tick };
}

export { PLATFORMS };
