import { useState } from "react";
import {
  KeyRound,
  Webhook,
  DatabaseBackup,
  Plus,
  RotateCw,
  Ban,
  CheckCircle2,
  ShieldCheck,
  Copy,
  Play,
  Pause,
} from "lucide-react";
import { Card, PanelHeader, Badge, Segmented, Dot, IconButton } from "../components/ui/primitives";
import { API_KEYS, WEBHOOKS, BACKUPS } from "../data/mockData";
import { cn } from "../utils/cn";
import type { ApiKey, Webhook as WH, Backup } from "../types";

type Tab = "keys" | "webhooks" | "backups";

export function Admin() {
  const [tab, setTab] = useState<Tab>("keys");
  const [keys, setKeys] = useState<ApiKey[]>(API_KEYS);
  const [hooks, setHooks] = useState<WH[]>(WEBHOOKS);
  const [backs, setBacks] = useState<Backup[]>(BACKUPS);
  const [flash, setFlash] = useState<string | null>(null);

  const notify = (m: string) => {
    setFlash(m);
    setTimeout(() => setFlash(null), 2200);
  };

  const genKey = () => {
    const id = `k${Date.now()}`;
    const rnd = Math.random().toString(36).slice(2, 6);
    setKeys((p) => [
      { id, subject: `svc-${rnd}`, prefix: `aios_live_${rnd}`, roles: ["viewer"], created: new Date().toISOString().slice(0, 10), ttl_days: 90, status: "active", uses: 0 },
      ...p,
    ]);
    notify(`New API key aios_live_${rnd}… generated`);
  };
  const rotate = (id: string) => {
    const rnd = Math.random().toString(36).slice(2, 6);
    setKeys((p) => p.map((k) => (k.id === id ? { ...k, prefix: `aios_live_${rnd}`, created: new Date().toISOString().slice(0, 10), uses: 0 } : k)));
    notify("Key rotated · previous key revoked");
  };
  const revoke = (id: string) => {
    setKeys((p) => p.map((k) => (k.id === id ? { ...k, status: "revoked" } : k)));
    notify("Key revoked");
  };

  const toggleHook = (id: string) => setHooks((p) => p.map((h) => (h.id === id ? { ...h, status: h.status === "active" ? "paused" : "active" } : h)));

  const createBackup = () => {
    setBacks((p) => [
      { id: `b${Date.now()}`, label: "manual", created: new Date().toISOString().replace("T", " ").slice(0, 16), size_mb: 248, verified: false, kind: "manual" },
      ...p,
    ]);
    notify("Backup snapshot queued");
  };
  const verify = (id: string) => {
    setBacks((p) => p.map((b) => (b.id === id ? { ...b, verified: true } : b)));
    notify("Checksum verified · OK");
  };

  return (
    <div className="space-y-5">
      <Card>
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <PanelHeader icon={<ShieldCheck className="h-[18px] w-[18px]" />} title="Administration" subtitle="Secrets, integrations & data protection" className="mb-0" />
          <Segmented
            value={tab}
            onChange={setTab}
            options={[
              { value: "keys", label: "API Keys" },
              { value: "webhooks", label: "Webhooks" },
              { value: "backups", label: "Backups" },
            ]}
          />
        </div>
      </Card>

      {flash && (
        <div className="animate-fade-in flex items-center gap-2 rounded-xl border border-emerald-400/20 bg-emerald-500/10 px-4 py-2.5 text-sm text-emerald-300">
          <CheckCircle2 className="h-4 w-4" /> {flash}
        </div>
      )}

      {/* API KEYS */}
      {tab === "keys" && (
        <Card>
          <PanelHeader
            icon={<KeyRound className="h-[18px] w-[18px]" />}
            title="API Keys"
            subtitle="Bearer-token auth · per-key data isolation · TTL"
            action={
              <button onClick={genKey} className="inline-flex items-center gap-1.5 rounded-lg bg-indigo-500/90 px-3 py-1.5 text-xs font-semibold text-white hover:bg-indigo-500">
                <Plus className="h-3.5 w-3.5" /> Generate
              </button>
            }
          />
          <div className="space-y-2">
            {keys.map((k) => (
              <div key={k.id} className="grid grid-cols-1 gap-3 rounded-xl bg-white/[0.02] p-3.5 ring-1 ring-inset ring-white/[0.04] sm:grid-cols-12 sm:items-center">
                <div className="sm:col-span-4">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-semibold text-slate-100">{k.subject}</span>
                    {k.status === "active" ? <Badge tone="emerald"><Dot tone="emerald" pulse /> active</Badge> : <Badge tone={k.status === "revoked" ? "rose" : "slate"}>{k.status}</Badge>}
                  </div>
                  <div className="mt-1 inline-flex items-center gap-1 font-mono text-[11px] text-slate-400">
                    {k.prefix}…
                    <Copy className="h-3 w-3 cursor-pointer text-slate-600 hover:text-slate-300" />
                  </div>
                </div>
                <div className="flex flex-wrap items-center gap-1.5 sm:col-span-4">
                  {k.roles.map((r) => (
                    <Badge key={r} tone="indigo">{r}</Badge>
                  ))}
                </div>
                <div className="flex items-center gap-4 text-[11px] text-slate-500 sm:col-span-2">
                  <span>Created {k.created}</span>
                  <span>TTL {k.ttl_days}d</span>
                </div>
                <div className="flex items-center justify-end gap-2 sm:col-span-2">
                  <span className="tabular text-xs text-slate-400">{k.uses.toLocaleString()} uses</span>
                  <IconButton onClick={() => rotate(k.id)} disabled={k.status !== "active"} title="Rotate" className="!h-7 !w-7"><RotateCw className="h-3.5 w-3.5" /></IconButton>
                  <IconButton tone="rose" onClick={() => revoke(k.id)} disabled={k.status !== "active"} title="Revoke" className="!h-7 !w-7"><Ban className="h-3.5 w-3.5" /></IconButton>
                </div>
              </div>
            ))}
          </div>
        </Card>
      )}

      {/* WEBHOOKS */}
      {tab === "webhooks" && (
        <Card>
          <PanelHeader icon={<Webhook className="h-[18px] w-[18px]" />} title="Webhooks" subtitle="Slack · Teams · custom HTTP · guaranteed delivery" />
          <div className="space-y-2">
            {hooks.map((h) => (
              <div key={h.id} className="grid grid-cols-1 gap-3 rounded-xl bg-white/[0.02] p-3.5 ring-1 ring-inset ring-white/[0.04] sm:grid-cols-12 sm:items-center">
                <div className="sm:col-span-4">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-semibold text-slate-100">{h.name}</span>
                    <Badge tone={h.status === "active" ? "emerald" : "slate"}>{h.status}</Badge>
                  </div>
                  <div className="mt-0.5 truncate font-mono text-[10px] text-slate-500">{h.url}</div>
                </div>
                <div className="flex flex-wrap items-center gap-1.5 sm:col-span-4">
                  {h.events.map((ev) => (
                    <Badge key={ev} tone="cyan">{ev}</Badge>
                  ))}
                </div>
                <div className="flex items-center gap-3 text-[11px] sm:col-span-2">
                  <span className="text-emerald-400">{h.delivered.toLocaleString()} ok</span>
                  <span className="text-rose-400">{h.failed} fail</span>
                </div>
                <div className="flex items-center justify-end sm:col-span-2">
                  <button
                    onClick={() => toggleHook(h.id)}
                    className={cn("inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-[11px] font-medium", h.status === "active" ? "bg-amber-500/15 text-amber-300" : "bg-emerald-500/15 text-emerald-300")}
                  >
                    {h.status === "active" ? <><Pause className="h-3 w-3" /> Pause</> : <><Play className="h-3 w-3" /> Resume</>}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </Card>
      )}

      {/* BACKUPS */}
      {tab === "backups" && (
        <Card>
          <PanelHeader
            icon={<DatabaseBackup className="h-[18px] w-[18px]" />}
            title="Backups"
            subtitle="Compressed · checksum-verified · restorable"
            action={
              <button onClick={createBackup} className="inline-flex items-center gap-1.5 rounded-lg bg-indigo-500/90 px-3 py-1.5 text-xs font-semibold text-white hover:bg-indigo-500">
                <Plus className="h-3.5 w-3.5" /> Snapshot
              </button>
            }
          />
          <div className="space-y-2">
            {backs.map((b) => (
              <div key={b.id} className="grid grid-cols-1 gap-3 rounded-xl bg-white/[0.02] p-3.5 ring-1 ring-inset ring-white/[0.04] sm:grid-cols-12 sm:items-center">
                <div className="flex items-center gap-3 sm:col-span-5">
                  <div className="grid h-9 w-9 place-items-center rounded-lg bg-white/[0.04] text-slate-300">
                    <DatabaseBackup className="h-4 w-4" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2 text-sm font-semibold text-slate-100">
                      {b.label}
                      <Badge tone={b.kind === "auto" ? "indigo" : "slate"}>{b.kind}</Badge>
                    </div>
                    <div className="text-[11px] text-slate-500">{b.created} · {b.size_mb} MB</div>
                  </div>
                </div>
                <div className="sm:col-span-4">
                  {b.verified ? (
                    <Badge tone="emerald"><CheckCircle2 className="h-3 w-3" /> Verified · checksum OK</Badge>
                  ) : (
                    <Badge tone="amber">Pending verification</Badge>
                  )}
                </div>
                <div className="flex items-center justify-end gap-2 sm:col-span-3">
                  {!b.verified && <IconButton tone="emerald" onClick={() => verify(b.id)} title="Verify" className="!h-7 !w-7"><CheckCircle2 className="h-3.5 w-3.5" /></IconButton>}
                  <button className="rounded-lg bg-white/[0.04] px-2.5 py-1.5 text-[11px] font-medium text-slate-300 ring-1 ring-inset ring-white/10 hover:bg-white/[0.08]">Restore</button>
                </div>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}
