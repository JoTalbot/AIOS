import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { workflows, systemLogs } from '@/db/schema';
import { seedDatabase } from '@/db/seed';
import { desc, eq } from 'drizzle-orm';

export async function GET() {
  try {
    await seedDatabase();
    const allWorkflows = await db.select().from(workflows).orderBy(desc(workflows.createdAt));
    return NextResponse.json({ success: true, data: allWorkflows });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error?.message || 'Failed to fetch workflows' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { name, description, triggerType, steps, action } = body;

    // Handle trigger workflow execution action
    if (action === 'trigger' && body.id) {
      const [wf] = await db.select().from(workflows).where(eq(workflows.id, body.id)).limit(1);
      if (!wf) {
        return NextResponse.json({ success: false, error: 'Workflow not found' }, { status: 404 });
      }

      const updated = await db.update(workflows)
        .set({
          lastRunAt: new Date(),
          runCount: (wf.runCount || 0) + 1,
        })
        .where(eq(workflows.id, wf.id))
        .returning();

      await db.insert(systemLogs).values({
        level: 'info',
        category: 'scheduler',
        message: `Workflow '${wf.name}' executed manually (${wf.steps?.length || 0} steps completed)`,
      });

      return NextResponse.json({
        success: true,
        message: `Workflow '${wf.name}' executed successfully!`,
        data: updated[0],
      });
    }

    if (!name || !description || !Array.isArray(steps)) {
      return NextResponse.json({ success: false, error: 'Name, description, and steps array are required' }, { status: 400 });
    }

    const [newWf] = await db.insert(workflows).values({
      name,
      description,
      triggerType: triggerType || 'manual',
      steps,
      status: 'active',
      runCount: 0,
    }).returning();

    return NextResponse.json({ success: true, data: newWf });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error?.message || 'Failed to process workflow' }, { status: 500 });
  }
}
