import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { chatMessages, systemLogs } from '@/db/schema';
import { eq } from 'drizzle-orm';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { messageId, approve } = body;

    if (!messageId) {
      return NextResponse.json({ success: false, error: 'messageId is required' }, { status: 400 });
    }

    const [msg] = await db.select().from(chatMessages).where(eq(chatMessages.id, messageId)).limit(1);
    if (!msg) {
      return NextResponse.json({ success: false, error: 'Message not found' }, { status: 404 });
    }

    const newStatus = approve ? 'approved' : 'rejected';

    const [updatedMsg] = await db.update(chatMessages)
      .set({
        approvalStatus: newStatus,
      })
      .where(eq(chatMessages.id, messageId))
      .returning();

    // If approved, insert tool_result message
    if (approve) {
      const toolArgsObj = msg.toolArgs as Record<string, any> | null;
      const cmdStr = toolArgsObj?.command || 'action';
      const toolOutput = {
        stdout: `Executing command '${cmdStr}': \n[SUCCESS] Operation executed cleanly in AIOS root context.\nExit code: 0`,
        timestamp: new Date().toISOString()
      };

      await db.insert(chatMessages).values({
        conversationId: msg.conversationId,
        agentId: msg.agentId,
        role: 'tool_result',
        content: JSON.stringify(toolOutput, null, 2),
        toolName: msg.toolName,
        toolResult: toolOutput,
        executionTimeMs: 140,
      });

      // Also add confirmation agent response
      await db.insert(chatMessages).values({
        conversationId: msg.conversationId,
        agentId: msg.agentId,
        role: 'agent',
        content: `✅ **Action Approved & Executed**\n\nTool \`${msg.toolName}\` was approved by operator and executed successfully.\n\`\`\`text\n${toolOutput.stdout}\n\`\`\``,
        tokensUsed: 120,
      });
    } else {
      await db.insert(chatMessages).values({
        conversationId: msg.conversationId,
        agentId: msg.agentId,
        role: 'agent',
        content: `🚫 **Action Rejected by User**\n\nThe operation for \`${msg.toolName}\` was canceled. No system files or environment state were altered.`,
        tokensUsed: 80,
      });
    }

    // Add log entry
    await db.insert(systemLogs).values({
      level: approve ? 'info' : 'warn',
      category: 'security',
      message: `Human-in-the-loop ${newStatus} tool action '${msg.toolName}' for message #${messageId}`,
      agentId: msg.agentId,
    });

    return NextResponse.json({ success: true, data: updatedMsg });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error?.message || 'Failed to update approval status' }, { status: 500 });
  }
}
