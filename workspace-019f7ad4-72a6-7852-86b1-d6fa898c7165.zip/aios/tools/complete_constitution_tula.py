#!/usr/bin/env python3
"""AIOS Tula Constitutional Scanner & Auditor v3.0.0

Comprehensive verification and audit tool (`tula`) for AIOS constitutional compliance.
Scans docs/constitution/, verifies numbering and section completeness,
auto-fixes naming anomalies, generates templates, and exports compliance matrices.
"""

import argparse
import os
import re
import sys
from pathlib import Path
from typing import Any, Optional

# Roman numeral conversion check
_ROMAN_MAP = {
    1: 'I', 4: 'IV', 5: 'V', 9: 'IX', 10: 'X', 40: 'XL', 50: 'L',
    90: 'XC', 100: 'C', 400: 'CD', 500: 'D', 900: 'CM', 1000: 'M'
}

def to_roman(num: int) -> str:
    result = ""
    for val, numeral in sorted(_ROMAN_MAP.items(), reverse=True):
        while num >= val:
            result += numeral
            num -= val
    return result

def from_roman(roman: str) -> int:
    roman_vals = {'I': 1, 'V': 5, 'X': 10, 'L': 50, 'C': 100, 'D': 500, 'M': 1000}
    val = 0
    prev = 0
    for char in reversed(roman.upper()):
        curr = roman_vals.get(char, 0)
        if curr < prev:
            val -= curr
        else:
            val += curr
            prev = curr
    return val


class TulaAuditor:
    """Tula constitutional compliance verification engine."""

    def __init__(self, constitution_dir: str):
        self.constitution_dir = constitution_dir
        self.scan_results: list[dict[str, Any]] = []
        self.anomalies_found: list[str] = []

    def _check_sections(self, content: str) -> list[str]:
        """Verify presence of core constitutional elements flexibly across formatting styles."""
        missing = []
        # Check Status
        if not re.search(r'(?i)(##?\s*\*?\*?status|\bstatus:)', content):
            missing.append("Status")
        # Check Level
        if not re.search(r'(?i)(##?\s*\*?\*?level|\blevel:)', content):
            missing.append("Level")
        # Check Scope
        if not re.search(r'(?i)(##?\s*\*?\*?scope|\bscope:)', content):
            missing.append("Scope")
        # Check Principle or Law definitions
        if not re.search(r'(?i)(##?\s*principle|\bprinciple|\blaw[s]?\b|##?\s*\d+\.\s+)', content):
            missing.append("Laws/Principles")
        return missing

    def scan(self) -> dict[str, Any]:
        """Scan docs/constitution directory and validate all files."""
        self.scan_results = []
        self.anomalies_found = []

        if not os.path.isdir(self.constitution_dir):
            raise FileNotFoundError(f"Constitution directory not found: {self.constitution_dir}")

        files = sorted(os.listdir(self.constitution_dir))
        articles = []

        for fname in files:
            fpath = os.path.join(self.constitution_dir, fname)
            if not os.path.isfile(fpath):
                continue

            # Check for name anomalies
            if fname.startswith("RTICLE-") or fname.startswith("# ARTICLE-") or not fname.endswith(".md"):
                if fname not in ("INDEX.md", "COMPLIANCE_MATRIX.md"):
                    self.anomalies_found.append(fname)

            # Match standard ARTICLE-<ROMAN>-<TITLE>.md
            match = re.match(r"^ARTICLE-([IVXLCDM]+)-(.+)\.md$", fname)
            if not match:
                continue

            roman_id = match.group(1)
            num_id = from_roman(roman_id)
            title = match.group(2)

            with open(fpath, "r", encoding="utf-8") as f:
                content = f.read()

            missing_sections = self._check_sections(content)
            is_valid = len(missing_sections) == 0

            articles.append({
                "filename": fname,
                "roman_id": roman_id,
                "num_id": num_id,
                "title": title,
                "is_valid": is_valid,
                "missing_sections": missing_sections,
            })

        articles.sort(key=lambda x: x["num_id"])

        # Check numbering sequence (1 to max)
        missing_numbers = []
        if articles:
            max_num = max(a["num_id"] for a in articles)
            present_nums = {a["num_id"] for a in articles}
            for i in range(1, max_num + 1):
                if i not in present_nums:
                    missing_numbers.append(i)

        return {
            "total_files_checked": len(files),
            "valid_articles_found": len(articles),
            "fully_compliant_articles": sum(1 for a in articles if a["is_valid"]),
            "anomalies_found": self.anomalies_found,
            "missing_numbers": missing_numbers,
            "articles": articles,
        }

    def fix_names(self) -> list[str]:
        """Automatically rename misnamed files like RTICLE-... or # ARTICLE-..."""
        fixed = []
        if not os.path.isdir(self.constitution_dir):
            return fixed

        for fname in os.listdir(self.constitution_dir):
            fpath = os.path.join(self.constitution_dir, fname)
            if not os.path.isfile(fpath):
                continue

            new_name = None
            if fname.startswith("RTICLE-"):
                new_name = "ARTICLE-" + fname[7:]
            elif fname.startswith("# ARTICLE-"):
                new_name = fname.replace("# ARTICLE-", "ARTICLE-")

            if new_name and new_name != fname:
                new_path = os.path.join(self.constitution_dir, new_name)
                os.rename(fpath, new_path)
                fixed.append(f"{fname} -> {new_name}")

        return fixed

    def generate_template(self, article_id: str, title: str) -> str:
        """Generate standard markdown template for an article."""
        roman = to_roman(int(article_id)) if article_id.isdigit() else article_id.upper()
        clean_title = title.upper().replace(" ", "-")
        content = f"""# ARTICLE {roman} — {title.upper()}

## Status
ACTIVE

## Level
SYSTEM / CONSTITUTIONAL

## Scope
Applies to all AIOS autonomous agents, runtime execution paths, and subsystems.

## Principle
The system shall enforce {title.lower()} protections across all operational workflows.

## Laws
1. MUST uphold explicit {title.lower()} verifications prior to state transitions.
2. MUST NOT bypass {title.lower()} guardrails under any optimization objective.

## Final Rule
Any action violating {title.lower()} mandates is immediately denied and logged to immutable audit records.

---
END OF ARTICLE {roman}
"""
        return content

    def write_template(self, article_id: str, title: str) -> str:
        """Generate template and write it to constitution_dir."""
        roman = to_roman(int(article_id)) if article_id.isdigit() else article_id.upper()
        clean_title = title.upper().replace(" ", "-")
        filename = f"ARTICLE-{roman}-{clean_title}.md"
        path = os.path.join(self.constitution_dir, filename)
        content = self.generate_template(article_id, title)
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)
        return path

    def generate_report_markdown(self, scan_data: dict[str, Any]) -> str:
        """Generate markdown audit report."""
        lines = [
            "# AIOS Constitutional Audit Report (Tula v3.0.0)",
            f"\n- **Total files checked:** {scan_data['total_files_checked']}",
            f"- **Valid articles found:** {scan_data['valid_articles_found']}",
            f"- **Fully compliant:** {scan_data['fully_compliant_articles']}",
            f"- **Anomalies:** {len(scan_data['anomalies_found'])}",
            "\n## Anomalies Found",
        ]
        if scan_data["anomalies_found"]:
            for a in scan_data["anomalies_found"]:
                lines.append(f"- `{a}`")
        else:
            lines.append("None detected. All filenames clean.")

        lines.append("\n## Missing Roman Sequence Numbers")
        if scan_data["missing_numbers"]:
            lines.append(f"Missing numerals: {', '.join(map(str, scan_data['missing_numbers']))}")
        else:
            lines.append("Complete Roman numeral sequence intact.")

        return "\n".join(lines) + "\n"

    def export_compliance_matrix(self, output_path: str) -> str:
        """Export mapping of constitutional articles to code implementation modules."""
        scan_data = self.scan()
        lines = [
            "# AIOS Constitutional Compliance Matrix v3.0.0",
            "\nMaps formal constitutional articles (`docs/constitution/`) to execution logic (`aios_core/`).\n",
            "| Article ID | Title | Core Module Mapping | Status |",
            "|---|---|---|---|",
        ]

        module_map = {
            "I": "`aios_core/privacy_guard.py`, `aios_core/config.py`",
            "II": "`aios_core/memory_manager.py`",
            "III": "`aios_core/reasoning_engine.py`",
            "V": "`aios_core/constitution_engine.py`",
            "VIII": "`aios_core/orchestrator.py`",
            "IX": "`aios_core/audit_logger.py`",
            "XXXVI": "`aios_core/evolution_manager.py`, `aios_core/model_evolution_v3.py`",
        }

        for a in scan_data["articles"]:
            rid = a["roman_id"]
            title = a["title"]
            mod = module_map.get(rid, "`aios_core/runtime_policy.py`")
            status = "✅ Verified" if a["is_valid"] else "⚠️ Partial Sections"
            lines.append(f"| ARTICLE-{rid} | {title} | {mod} | {status} |")

        content = "\n".join(lines) + "\n"
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(content)
        return output_path


def main():
    parser = argparse.ArgumentParser(description="AIOS Tula Constitutional Scanner & Auditor v3.0.0")
    parser.add_argument("--scan", type=str, default="docs/constitution", help="Directory to scan")
    parser.add_argument("--report", type=str, help="Output markdown report path")
    parser.add_argument("--fix-names", action="store_true", help="Fix misnamed article files")
    parser.add_argument("--generate-template", nargs=2, metavar=("ID", "TITLE"), help="Generate article template")
    parser.add_argument("--export-matrix", type=str, help="Export compliance matrix to path")

    args = parser.parse_args()
    auditor = TulaAuditor(args.scan)

    if args.fix_names:
        fixed = auditor.fix_names()
        print(f"Fixed {len(fixed)} file anomalies:")
        for f in fixed:
            print(f"  {f}")

    if args.generate_template:
        path = auditor.write_template(args.generate_template[0], args.generate_template[1])
        print(f"Generated template at: {path}")

    scan_data = auditor.scan()
    print(f"Tula Scan Complete: {scan_data['valid_articles_found']} articles checked, {scan_data['fully_compliant_articles']} fully compliant.")

    if args.report:
        report_md = auditor.generate_report_markdown(scan_data)
        with open(args.report, "w", encoding="utf-8") as f:
            f.write(report_md)
        print(f"Report written to: {args.report}")

    if args.export_matrix:
        auditor.export_compliance_matrix(args.export_matrix)
        print(f"Compliance matrix written to: {args.export_matrix}")


if __name__ == "__main__":
    main()
