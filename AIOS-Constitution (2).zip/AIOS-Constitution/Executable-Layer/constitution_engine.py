"""
AIOS Constitution Engine v2.1.1

Main execution layer connecting constitutional rules and validator.
"""

from constitution_validator import validate_action, Decision


class ConstitutionEngine:
    def __init__(self):
        self.version = "2.1.1"

    def evaluate(self, action: dict) -> dict:
        result = validate_action(action)

        return {
            "constitution_version": self.version,
            "decision": result.get("decision"),
            "details": result,
        }

    def execute_policy(self, action: dict):
        result = self.evaluate(action)

        if result["decision"] == Decision.ALLOW.value:
            return "EXECUTE"

        if result["decision"] == Decision.REVIEW.value:
            return "WAIT_FOR_APPROVAL"

        return "BLOCK"


if __name__ == "__main__":
    engine = ConstitutionEngine()
    print(engine.evaluate({
        "goal": "test",
        "scope": "local",
        "risk": "low",
        "reversible": True,
        "audit_log": True
    }))
