"""
AIOS Constitution Validator v2.1.1

Validates agent actions against constitutional rules.
"""

from enum import Enum


class Decision(Enum):
    ALLOW = "ALLOW"
    REVIEW = "REVIEW"
    DENY = "DENY"


IMMUTABLE_ACTIONS = {
    "modify_core_constitution",
    "disable_validator",
}


def validate_action(action: dict) -> dict:
    required = ["goal", "scope", "risk", "reversible", "audit_log"]

    missing = [field for field in required if field not in action]
    if missing:
        return {
            "decision": Decision.DENY.value,
            "reason": "missing_required_fields",
            "missing": missing,
        }

    if action.get("type") in IMMUTABLE_ACTIONS:
        return {
            "decision": Decision.DENY.value,
            "reason": "constitutional_core_protected",
        }

    if action.get("risk") == "high" and not action.get("approval"):
        return {
            "decision": Decision.REVIEW.value,
            "reason": "high_risk_requires_approval",
        }

    return {
        "decision": Decision.ALLOW.value,
        "rules_checked": [
            "limited_autonomy",
            "minimal_force",
            "audit_required",
        ],
    }
