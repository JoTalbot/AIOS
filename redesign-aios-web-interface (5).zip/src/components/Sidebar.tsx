'use client';

import React from 'react';
import {
  LayoutDashboard,
  Bot,
  MessageSquareCode,
  Cpu,
  Wrench,
  Brain,
  GitFork,
  ShieldAlert,
  Settings,
  ChevronRight
} from 'lucide-react';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  unresolvedCount?: number;
}

export default function Sidebar({ activeTab, setActiveTab, unresolvedCount = 0 }: SidebarProps) {
  const navItems = [
    { id: 'dashboard', label: 'Kernel Monitor', icon: LayoutDashboard, badge: null, desc: 'OS Telemetry & PIDs' },
    { id: 'agents', label: 'AgentHub', icon: Bot, badge: '6 Ready', desc: 'Marketplace & Studio' },
    { id: 'chat', label: 'AgentChat', icon: MessageSquareCode, badge: null, desc: 'Interactive Workspace' },
    { id: 'processes', label: 'Processes', icon: Cpu, badge: '4 Running', desc: 'Scheduler & Threads' },
    { id: 'tools', label: 'MCP Tools', icon: Wrench, badge: '8 MCP', desc: 'Capabilities Registry' },
    { id: 'memory', label: 'Memory Bank', icon: Brain, badge: null, desc: 'Vector Store & KV' },
    { id: 'workflows', label: 'Workflows', icon: GitFork, badge: '2 Auto', desc: 'Pipeline Studio' },
    { id: 'logs', label: 'Audit Logs', icon: ShieldAlert, badge: unresolvedCount > 0 ? `${unresolvedCount} Alerts` : null, badgeColor: 'bg-amber-950 text-amber-400 border-amber-800' },
    { id: 'settings', label: 'LLM Gateway', icon: Settings, badge: null, desc: 'Providers & Config' },
  ];

  return (
    <aside className="w-16 lg:w-64 border-r border-slate-800/80 bg-slate-950/90 flex flex-col justify-between shrink-0 select-none z-20">
      {/* Upper Navigation Links */}
      <div className="py-4 px-2 lg:px-3 space-y-1">
        <div className="hidden lg:block px-3 py-1 text-[10px] uppercase tracking-wider font-semibold font-mono text-slate-500">
          Kernel Modules
        </div>

        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl transition-all cursor-pointer group ${
                isActive
                  ? 'bg-gradient-to-r from-cyan-950/80 via-slate-900 to-indigo-950/60 border border-cyan-700/50 text-white shadow-md shadow-cyan-950/40'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60 border border-transparent'
              }`}
            >
              <div className="flex items-center space-x-3">
                <div className={`p-1.5 rounded-lg transition-colors ${
                  isActive ? 'bg-cyan-500/20 text-cyan-400' : 'bg-slate-900 text-slate-400 group-hover:text-slate-200'
                }`}>
                  <Icon className="w-4 h-4" />
                </div>
                <div className="hidden lg:block text-left">
                  <p className={`text-xs font-medium leading-tight ${isActive ? 'text-white font-semibold' : 'text-slate-300'}`}>
                    {item.label}
                  </p>
                  <p className="text-[10px] text-slate-500 font-mono leading-tight">{item.desc}</p>
                </div>
              </div>

              {/* Badge or indicator */}
              <div className="hidden lg:flex items-center space-x-1">
                {item.badge && (
                  <span className={`text-[9px] font-mono font-medium px-1.5 py-0.5 rounded border ${
                    item.badgeColor || (isActive ? 'bg-cyan-900/80 text-cyan-300 border-cyan-700' : 'bg-slate-900 text-slate-400 border-slate-800')
                  }`}>
                    {item.badge}
                  </span>
                )}
                {isActive && <ChevronRight className="w-3.5 h-3.5 text-cyan-400" />}
              </div>
            </button>
          );
        })}
      </div>

      {/* Footer Kernel Hardware Status */}
      <div className="p-3 border-t border-slate-800/80 bg-slate-950/40 hidden lg:block">
        <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 space-y-2">
          <div className="flex items-center justify-between text-[11px] font-mono">
            <span className="text-slate-400">Context Scheduler</span>
            <span className="text-emerald-400 font-semibold flex items-center space-x-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              <span>ROUND-ROBIN</span>
            </span>
          </div>

          <div className="w-full bg-slate-950 rounded-full h-1.5 overflow-hidden border border-slate-800">
            <div className="bg-gradient-to-r from-cyan-500 to-indigo-500 h-full w-[38%]" />
          </div>

          <p className="text-[10px] text-slate-500 font-mono">38% GPU VRAM context utilized</p>
        </div>
      </div>
    </aside>
  );
}
