'use client';

import React, { useState, useEffect, useRef } from 'react';
import {
  MessageSquareCode,
  Plus,
  Send,
  Pin,
  Trash2,
  Terminal,
  ShieldAlert,
  CheckCircle2,
  XCircle,
  Copy,
  Check,
  Wrench,
  Bot,
  Zap,
  Sparkles,
  ChevronDown
} from 'lucide-react';

interface AgentChatViewProps {
  conversations: any[];
  agents: any[];
  activeConvId: number | null;
  onSelectConversation: (id: number) => void;
  onCreateConversation: (title?: string, agentId?: number) => void;
  onDeleteConversation: (id: number) => void;
  onSendMessage: (convId: number, content: string, agentId?: number) => void;
  onApproveTool: (msgId: number, approve: boolean) => void;
  loadingMessage: boolean;
}

export default function AgentChatView({
  conversations,
  agents,
  activeConvId,
  onSelectConversation,
  onCreateConversation,
  onDeleteConversation,
  onSendMessage,
  onApproveTool,
  loadingMessage,
}: AgentChatViewProps) {
  const [messages, setMessages] = useState<any[]>([]);
  const [inputContent, setInputContent] = useState('');
  const [selectedAgentId, setSelectedAgentId] = useState<number | ''>('');
  const [copiedId, setCopiedId] = useState<number | null>(null);
  const [fetchingConv, setFetchingConv] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Load active conversation messages
  useEffect(() => {
    if (!activeConvId) return;
    setFetchingConv(true);
    fetch(`/api/conversations/${activeConvId}`)
      .then((res) => res.json())
      .then((data) => {
        if (data.success && data.data) {
          setMessages(data.data.messages || []);
          if (data.data.agentId) {
            setSelectedAgentId(data.data.agentId);
          }
        }
      })
      .catch((err) => console.error(err))
      .finally(() => setFetchingConv(false));
  }, [activeConvId]);

  // Scroll to bottom when messages update
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loadingMessage]);

  const activeConv = conversations.find((c) => c.id === activeConvId);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputContent.trim() || !activeConvId) return;
    const text = inputContent.trim();
    setInputContent('');

    // Optimistic UI push
    const tempUserMsg = {
      id: Date.now(),
      conversationId: activeConvId,
      role: 'user',
      content: text,
      createdAt: new Date().toISOString(),
    };
    setMessages((prev) => [...prev, tempUserMsg]);

    onSendMessage(
      activeConvId,
      text,
      selectedAgentId ? Number(selectedAgentId) : undefined
    );
  };

  const copyCode = (text: string, id: number) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="h-[calc(100vh-4rem)] flex overflow-hidden">
      {/* Sidebar: Conversation Sessions */}
      <div className="w-72 border-r border-slate-800/80 bg-slate-950/80 flex flex-col shrink-0">
        <div className="p-3 border-b border-slate-800/80 flex items-center justify-between">
          <span className="text-xs font-mono font-bold text-slate-300 uppercase tracking-wider flex items-center space-x-1.5">
            <MessageSquareCode className="w-4 h-4 text-cyan-400" />
            <span>AIOS Sessions</span>
          </span>
          <button
            onClick={() => onCreateConversation('New AIOS Task Session')}
            className="p-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white transition-colors cursor-pointer"
            title="Create Session"
          >
            <Plus className="w-4 h-4" />
          </button>
        </div>

        {/* Sessions list */}
        <div className="flex-1 overflow-y-auto p-2 space-y-1">
          {conversations.map((c) => {
            const isSelected = c.id === activeConvId;
            return (
              <div
                key={c.id}
                onClick={() => onSelectConversation(c.id)}
                className={`p-2.5 rounded-xl transition-all cursor-pointer flex items-center justify-between group border ${
                  isSelected
                    ? 'bg-slate-900 border-cyan-700/60 text-white shadow-md'
                    : 'border-transparent hover:bg-slate-900/50 text-slate-400 hover:text-slate-200'
                }`}
              >
                <div className="flex items-center space-x-2.5 min-w-0">
                  <span className="text-base shrink-0">{c.agentAvatar || '🤖'}</span>
                  <div className="min-w-0">
                    <p className="text-xs font-medium truncate leading-snug">{c.title}</p>
                    <p className="text-[10px] font-mono text-slate-500 truncate">
                      {c.agentName || 'Kernel Master'} • {c.tokenCount || 0} tokens
                    </p>
                  </div>
                </div>

                <div className="flex items-center space-x-1 opacity-0 group-hover:opacity-100 transition-opacity shrink-0">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onDeleteConversation(c.id);
                    }}
                    className="p-1 hover:text-rose-400 text-slate-500 transition-colors cursor-pointer"
                    title="Delete Session"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Main AgentChat Window */}
      <div className="flex-1 flex flex-col bg-slate-950/40 relative min-w-0">
        {/* Chat Session Top Bar */}
        {activeConv ? (
          <div className="h-14 border-b border-slate-800/80 bg-slate-950/90 px-4 flex items-center justify-between shrink-0">
            <div className="flex items-center space-x-3 min-w-0">
              <span className="text-2xl">{activeConv.agentAvatar || '🤖'}</span>
              <div className="min-w-0">
                <h2 className="text-sm font-bold text-white truncate">{activeConv.title}</h2>
                <div className="flex items-center space-x-2 text-[10px] font-mono text-slate-400">
                  <span className="text-cyan-400 font-semibold">{activeConv.agentName || 'Kernel Master'}</span>
                  <span>•</span>
                  <span>{activeConv.agentModel || 'gpt-4o'}</span>
                </div>
              </div>
            </div>

            {/* Agent switch dropdown */}
            <div className="flex items-center space-x-2">
              <span className="text-xs font-mono text-slate-400 hidden sm:inline">Active Agent:</span>
              <select
                value={selectedAgentId}
                onChange={(e) => setSelectedAgentId(e.target.value ? Number(e.target.value) : '')}
                className="bg-slate-900 border border-slate-800 rounded-xl px-2.5 py-1.5 text-xs font-mono text-slate-200 focus:border-cyan-500 focus:outline-none"
              >
                <option value="">Default (Kernel Master)</option>
                {agents.map((a) => (
                  <option key={a.id} value={a.id}>
                    {a.avatar} {a.name} ({a.model})
                  </option>
                ))}
              </select>
            </div>
          </div>
        ) : (
          <div className="p-4 border-b border-slate-800 text-xs font-mono text-slate-500">
            Select or create a conversation thread to start.
          </div>
        )}

        {/* Message Thread Scroll Area */}
        <div className="flex-1 overflow-y-auto p-4 lg:p-6 space-y-4">
          {messages.map((msg) => {
            const isUser = msg.role === 'user';
            const isToolCall = msg.role === 'tool_call';
            const isToolResult = msg.role === 'tool_result';
            const isSystem = msg.role === 'system';

            if (isSystem) {
              return (
                <div key={msg.id} className="flex justify-center my-2">
                  <div className="text-[11px] font-mono text-cyan-400 bg-cyan-950/40 border border-cyan-800/60 px-3 py-1 rounded-full flex items-center space-x-1.5">
                    <Sparkles className="w-3 h-3 text-cyan-400" />
                    <span>{msg.content}</span>
                  </div>
                </div>
              );
            }

            if (isToolCall) {
              const isPending = msg.approvalStatus === 'pending';
              return (
                <div key={msg.id} className="my-3 max-w-2xl mx-auto">
                  <div className={`glass-panel p-4 rounded-2xl border ${
                    isPending ? 'border-amber-500/80 bg-amber-950/20' : 'border-slate-800 bg-slate-900/60'
                  }`}>
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2 text-xs font-mono font-semibold text-amber-300">
                        <Wrench className="w-4 h-4 text-amber-400" />
                        <span>Tool Invocation: {msg.toolName}</span>
                      </div>
                      <span className="text-[10px] font-mono text-slate-500">{msg.executionTimeMs}ms</span>
                    </div>

                    <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 font-mono text-xs text-slate-300 overflow-x-auto">
                      <pre>{JSON.stringify(msg.toolArgs, null, 2)}</pre>
                    </div>

                    {/* Human In The Loop Approval Action Bar */}
                    {isPending && (
                      <div className="mt-3 p-3 rounded-xl bg-amber-950/60 border border-amber-800/80 space-y-2">
                        <div className="flex items-center space-x-2 text-amber-200 text-xs font-semibold">
                          <ShieldAlert className="w-4 h-4 text-amber-400" />
                          <span>Human-In-The-Loop Privilege Confirmation Required</span>
                        </div>
                        <p className="text-[11px] text-amber-300/80 font-mono">
                          This action requires confirmation before executing in the AIOS kernel sandbox.
                        </p>
                        <div className="flex items-center space-x-2 pt-1">
                          <button
                            onClick={() => onApproveTool(msg.id, true)}
                            className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-mono text-xs font-bold flex items-center space-x-1 cursor-pointer"
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>Approve & Run</span>
                          </button>
                          <button
                            onClick={() => onApproveTool(msg.id, false)}
                            className="px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-mono text-xs font-bold flex items-center space-x-1 cursor-pointer"
                          >
                            <XCircle className="w-3.5 h-3.5" />
                            <span>Reject Action</span>
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              );
            }

            if (isToolResult) {
              return (
                <div key={msg.id} className="my-2 max-w-2xl mx-auto">
                  <div className="bg-slate-900/80 p-3 rounded-xl border border-emerald-800/60 font-mono text-xs text-slate-300 space-y-1">
                    <div className="flex items-center justify-between text-emerald-400 text-[11px]">
                      <span>Tool Execution Output ({msg.toolName})</span>
                      <span>Execution SUCCESS</span>
                    </div>
                    <pre className="bg-slate-950 p-2 rounded-lg text-slate-300 overflow-x-auto text-[11px]">
                      {msg.content}
                    </pre>
                  </div>
                </div>
              );
            }

            return (
              <div
                key={msg.id}
                className={`flex space-x-3 ${isUser ? 'justify-end' : 'justify-start'}`}
              >
                {!isUser && (
                  <div className="w-8 h-8 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center text-lg shrink-0 mt-0.5">
                    {msg.agentAvatar || '🤖'}
                  </div>
                )}

                <div className={`max-w-3xl rounded-2xl p-4 text-xs font-sans leading-relaxed space-y-2 border ${
                  isUser
                    ? 'bg-gradient-to-r from-cyan-600 to-indigo-600 text-white border-cyan-500/50 shadow-md'
                    : 'glass-panel bg-slate-900/90 text-slate-200 border-slate-800'
                }`}>
                  {!isUser && (
                    <div className="flex items-center justify-between border-b border-slate-800/80 pb-1.5 font-mono text-[10px] text-slate-400">
                      <span className="text-cyan-400 font-bold">{msg.agentName || 'Agent'}</span>
                      <button
                        onClick={() => copyCode(msg.content, msg.id)}
                        className="hover:text-slate-200 transition-colors flex items-center space-x-1 cursor-pointer"
                      >
                        {copiedId === msg.id ? (
                          <>
                            <Check className="w-3 h-3 text-emerald-400" />
                            <span className="text-emerald-400">Copied</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3 h-3" />
                            <span>Copy</span>
                          </>
                        )}
                      </button>
                    </div>
                  )}

                  <div className="whitespace-pre-wrap leading-relaxed">
                    {msg.content}
                  </div>

                  {msg.tokensUsed && (
                    <div className="text-[9px] font-mono text-right text-slate-400 opacity-75">
                      {msg.tokensUsed} tokens
                    </div>
                  )}
                </div>

                {isUser && (
                  <div className="w-8 h-8 rounded-xl bg-cyan-950 border border-cyan-700 flex items-center justify-center text-xs text-cyan-300 font-mono shrink-0 mt-0.5">
                    YOU
                  </div>
                )}
              </div>
            );
          })}

          {loadingMessage && (
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center text-lg animate-pulse">
                🤖
              </div>
              <div className="glass-panel p-3 rounded-2xl border border-slate-800 text-xs font-mono text-cyan-400 flex items-center space-x-2">
                <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
                <span>AIOS Kernel scheduling agent task execution...</span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Input Bar */}
        <div className="p-3 lg:p-4 border-t border-slate-800/80 bg-slate-950/90 shrink-0">
          {/* Quick Tool Shortcut Chips */}
          <div className="flex items-center space-x-2 mb-2 overflow-x-auto scrollbar-none font-mono text-[10px]">
            <span className="text-slate-500 shrink-0">Triggers:</span>
            <button
              onClick={() => setInputContent('Run shell command to check AIOS memory status')}
              className="px-2 py-0.5 rounded bg-slate-900 text-slate-300 border border-slate-800 hover:border-cyan-700 cursor-pointer shrink-0"
            >
              🐚 exec shell
            </button>
            <button
              onClick={() => setInputContent('Search web for latest AIOS release notes')}
              className="px-2 py-0.5 rounded bg-slate-900 text-slate-300 border border-slate-800 hover:border-cyan-700 cursor-pointer shrink-0"
            >
              🌐 web search
            </button>
            <button
              onClick={() => setInputContent('Execute SQL query on PostgreSQL agents table')}
              className="px-2 py-0.5 rounded bg-slate-900 text-slate-300 border border-slate-800 hover:border-cyan-700 cursor-pointer shrink-0"
            >
              📊 sql query
            </button>
            <button
              onClick={() => setInputContent('Run Python script to calculate tensor matrix')}
              className="px-2 py-0.5 rounded bg-slate-900 text-slate-300 border border-slate-800 hover:border-cyan-700 cursor-pointer shrink-0"
            >
              🐍 python sandbox
            </button>
          </div>

          <form onSubmit={handleSend} className="flex items-center space-x-2">
            <input
              type="text"
              value={inputContent}
              onChange={(e) => setInputContent(e.target.value)}
              placeholder="Send prompt or tool request to AIOS agent..."
              disabled={loadingMessage || !activeConvId}
              className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-4 py-3 text-xs text-slate-200 font-mono focus:border-cyan-500 focus:outline-none disabled:opacity-50"
            />
            <button
              type="submit"
              disabled={loadingMessage || !inputContent.trim() || !activeConvId}
              className="px-5 py-3 rounded-xl bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 disabled:opacity-50 text-white text-xs font-mono font-bold flex items-center space-x-1.5 transition-all shadow-lg cursor-pointer"
            >
              <span>Send</span>
              <Send className="w-3.5 h-3.5" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
