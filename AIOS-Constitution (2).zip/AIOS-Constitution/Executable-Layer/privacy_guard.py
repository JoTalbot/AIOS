"""
AIOS Privacy Guard Layer v2.1.1

Protects memory access according to data classification rules.
"""


class PrivacyGuard:
    def __init__(self):
        self.protected = ["PERSONAL"]

    def can_share(self, classification: str) -> bool:
        return classification not in self.protected

    def check_access(self, request: dict) -> dict:
        allowed = self.can_share(request.get("classification"))

        return {
            "allowed": allowed,
            "classification": request.get("classification"),
            "reason": "approved" if allowed else "personal_data_protected"
        }
