'use client';

import React, { useState } from 'react';
import {
  Cpu,
  Activity,
  Play,
  Pause,
  XSquare,
  PlusCircle,
  Terminal,
  Layers,
  Clock,
  ShieldCheck,
  RefreshCw
} from 'lucide-react';

interface ProcessManagerViewProps {
  processes: any[];
  agents: any[];
  onProcessAction: (procId: number, action: string) => void;
  onSpawnProcess: (agentId: number) => void;
  onRefresh: () => void;
}

export default function ProcessManagerView({
  processes,
  agents,
  onProcessAction,
  onSpawnProcess,
  onRefresh,
}: ProcessManagerViewProps) {
  const [filterStatus, setActiveFilter] = useState('all');
  const [selectedAgent, setSelectedAgent] = useState<number | ''>('');

  const filteredProcesses = processes.filter((p) => {
    if (filterStatus === 'all') return true;
    return p.status === filterStatus;
  });

  const handleSpawn = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedAgent) {
      onSpawnProcess(Number(selectedAgent));
      setSelectedAgent('');
    }
  };

  return (
    <div className="p-4 lg:p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight flex items-center space-x-2">
            <Cpu className="w-5 h-5 text-cyan-400" />
            <span>Kernel Scheduler & Process Thread Manager</span>
          </h1>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Inspect PID call stacks, thread RAM allocations, and execution step progress.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <form onSubmit={handleSpawn} className="flex items-center space-x-2">
            <select
              value={selectedAgent}
              onChange={(e) => setSelectedAgent(Number(e.target.value))}
              required
              className="bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs font-mono text-slate-200 focus:border-cyan-500 focus:outline-none"
            >
              <option value="">-- Spawn Agent PID --</option>
              {agents.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.avatar} {a.name}
                </option>
              ))}
            </select>

            <button
              type="submit"
              disabled={!selectedAgent}
              className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-white text-xs font-mono font-bold flex items-center space-x-1.5 transition-all shadow-lg cursor-pointer shrink-0"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Spawn</span>
            </button>
          </form>

          <button
            onClick={onRefresh}
            className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 transition-colors cursor-pointer"
            title="Refresh Threads"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center space-x-2 border-b border-slate-800/80 pb-3">
        {['all', 'running', 'waiting', 'suspended', 'terminated'].map((st) => (
          <button
            key={st}
            onClick={() => setActiveFilter(st)}
            className={`px-3 py-1.5 rounded-xl text-xs font-mono capitalize transition-all cursor-pointer border ${
              filterStatus === st
                ? 'bg-cyan-950 text-cyan-300 border-cyan-700 font-bold'
                : 'bg-slate-900/60 text-slate-400 border-slate-800 hover:text-slate-200'
            }`}
          >
            {st}
          </button>
        ))}
      </div>

      {/* Process Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {filteredProcesses.map((proc) => {
          const isRunning = proc.status === 'running';
          const isSuspended = proc.status === 'suspended';

          return (
            <div
              key={proc.id}
              className="glass-panel p-5 rounded-2xl border border-slate-800 space-y-4 hover:border-cyan-800/60 transition-all"
            >
              {/* Header: PID, Name, Priority, Actions */}
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <span className="text-3xl">{proc.agentAvatar || '🤖'}</span>
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="text-xs font-mono font-bold text-cyan-400">PID-{proc.pid}</span>
                      <span className={`text-[10px] font-mono px-2 py-0.5 rounded border uppercase ${
                        proc.priority === 'high' ? 'bg-rose-950 text-rose-300 border-rose-800' :
                        proc.priority === 'medium' ? 'bg-amber-950 text-amber-300 border-amber-800' :
                        'bg-slate-900 text-slate-400 border-slate-800'
                      }`}>
                        {proc.priority}
                      </span>
                    </div>
                    <h3 className="text-sm font-bold text-white mt-0.5">{proc.processName}</h3>
                  </div>
                </div>

                <div className="flex items-center space-x-1">
                  {isRunning ? (
                    <button
                      onClick={() => onProcessAction(proc.id, 'suspend')}
                      className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-amber-400 border border-slate-800 transition-colors cursor-pointer"
                      title="Suspend Thread"
                    >
                      <Pause className="w-4 h-4" />
                    </button>
                  ) : isSuspended ? (
                    <button
                      onClick={() => onProcessAction(proc.id, 'resume')}
                      className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-emerald-400 border border-slate-800 transition-colors cursor-pointer"
                      title="Resume Thread"
                    >
                      <Play className="w-4 h-4" />
                    </button>
                  ) : null}

                  <button
                    onClick={() => onProcessAction(proc.id, 'kill')}
                    className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-rose-400 border border-slate-800 transition-colors cursor-pointer"
                    title="Terminate PID"
                  >
                    <XSquare className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Step Progress & Status */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs font-mono">
                  <span className="text-slate-400">Current Step:</span>
                  <span className={`capitalize font-semibold ${
                    isRunning ? 'text-emerald-400' :
                    isSuspended ? 'text-amber-400' : 'text-slate-400'
                  }`}>
                    {proc.status}
                  </span>
                </div>

                <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 text-xs font-mono text-slate-300">
                  {proc.currentStep || 'Ready for context switch'}
                </div>
              </div>

              {/* Telemetry Stats */}
              <div className="grid grid-cols-3 gap-2 text-[11px] font-mono bg-slate-900/40 p-2.5 rounded-xl border border-slate-800">
                <div>
                  <span className="text-slate-500 block text-[9px]">RAM Usage</span>
                  <span className="text-indigo-300 font-semibold">{proc.memoryUsedMb} MB</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[9px]">CPU Core %</span>
                  <span className="text-cyan-300 font-semibold">{proc.cpuUsagePct}%</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[9px]">Tokens Spent</span>
                  <span className="text-amber-300 font-semibold">{proc.tokensUsed}</span>
                </div>
              </div>

              {/* Stack Trace */}
              {Array.isArray(proc.callStack) && proc.callStack.length > 0 && (
                <div>
                  <span className="text-[10px] font-mono text-slate-500 block mb-1">Call Stack Trace:</span>
                  <div className="bg-slate-950 p-2 rounded-xl border border-slate-800/80 font-mono text-[10px] text-slate-400 space-y-1">
                    {proc.callStack.map((stackLine: string, idx: number) => (
                      <div key={idx} className="flex items-center space-x-2">
                        <span className="text-slate-600">[{idx}]</span>
                        <span className="text-slate-300">{stackLine}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          );
        })}

        {filteredProcesses.length === 0 && (
          <div className="col-span-full py-12 text-center text-slate-500 font-mono space-y-2">
            <Layers className="w-10 h-10 mx-auto text-slate-600" />
            <p>No process threads match the active filter.</p>
          </div>
        )}
      </div>
    </div>
  );
}
