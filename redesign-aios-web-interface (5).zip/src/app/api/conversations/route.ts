import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { conversations, chatMessages, agents } from '@/db/schema';
import { seedDatabase } from '@/db/seed';
import { desc, eq } from 'drizzle-orm';

export async function GET() {
  try {
    await seedDatabase();
    const convs = await db
      .select({
        id: conversations.id,
        title: conversations.title,
        agentId: conversations.agentId,
        agentName: agents.name,
        agentAvatar: agents.avatar,
        agentSlug: agents.slug,
        mode: conversations.mode,
        pinned: conversations.pinned,
        tokenCount: conversations.tokenCount,
        createdAt: conversations.createdAt,
        updatedAt: conversations.updatedAt,
      })
      .from(conversations)
      .leftJoin(agents, eq(conversations.agentId, agents.id))
      .orderBy(desc(conversations.pinned), desc(conversations.updatedAt));

    return NextResponse.json({ success: true, data: convs });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error?.message || 'Failed to fetch conversations' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { title, agentId, mode } = body;

    const [conv] = await db.insert(conversations).values({
      title: title || 'New AIOS Chat Session',
      agentId: agentId || null,
      mode: mode || 'single_agent',
      pinned: false,
      tokenCount: 0,
    }).returning();

    // Insert welcome system message
    let welcomeText = 'AIOS Interactive Chat Session initialized.';
    if (agentId) {
      const [agent] = await db.select().from(agents).where(eq(agents.id, agentId)).limit(1);
      if (agent) {
        welcomeText = `Connected to **${agent.name}** (${agent.model} via ${agent.provider.toUpperCase()}). System prompt activated.`;
      }
    }

    await db.insert(chatMessages).values({
      conversationId: conv.id,
      agentId: agentId || null,
      role: 'system',
      content: welcomeText,
    });

    return NextResponse.json({ success: true, data: conv });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error?.message || 'Failed to create conversation' }, { status: 500 });
  }
}
