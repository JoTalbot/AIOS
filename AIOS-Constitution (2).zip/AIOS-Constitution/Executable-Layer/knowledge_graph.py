"""
AIOS Knowledge Graph Layer v2.1.1

Stores relations between rules, knowledge and system experience.
"""


class KnowledgeGraph:
    def __init__(self):
        self.nodes = []
        self.edges = []

    def add_node(self, node: dict):
        self.nodes.append(node)
        return node

    def add_relation(self, source: str, target: str, relation: str):
        edge = {
            "source": source,
            "target": target,
            "relation": relation
        }
        self.edges.append(edge)
        return edge

    def related(self, node_id: str):
        return [e for e in self.edges if e["source"] == node_id or e["target"] == node_id]
