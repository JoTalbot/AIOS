'use client';

import React from 'react';
import { Cpu, HardDrive, Zap, ShieldCheck, Activity, Terminal, RefreshCw } from 'lucide-react';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  metrics: any;
  onRefresh: () => void;
  loading: boolean;
}

export default function Header({ activeTab, setActiveTab, metrics, onRefresh, loading }: HeaderProps) {
  const summary = metrics?.summary || {
    activeProcesses: 4,
    memoryUsedTotalMb: 714,
    totalTokens: 3898200,
    activeTools: 8
  };

  return (
    <header className="h-16 border-b border-slate-800/80 bg-slate-950/80 backdrop-blur-md px-4 flex items-center justify-between sticky top-0 z-30">
      {/* Left: Branding & Current Section Title */}
      <div className="flex items-center space-x-3">
        <div 
          onClick={() => setActiveTab('dashboard')}
          className="flex items-center space-x-2.5 cursor-pointer group"
        >
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-500 via-indigo-600 to-purple-600 flex items-center justify-center text-white shadow-lg shadow-cyan-500/20 group-hover:scale-105 transition-transform">
            <Terminal className="w-5 h-5 text-white" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="font-bold text-base tracking-tight bg-gradient-to-r from-cyan-400 via-sky-200 to-indigo-300 bg-clip-text text-transparent">
                AIOS
              </span>
              <span className="text-[10px] uppercase tracking-wider font-semibold px-1.5 py-0.5 rounded bg-cyan-950/80 text-cyan-400 border border-cyan-800/60">
                v2.4 Kernel
              </span>
            </div>
            <p className="text-[11px] text-slate-400 font-mono -mt-0.5">AI Agent Operating System</p>
          </div>
        </div>

        <div className="h-5 w-[1px] bg-slate-800 mx-2 hidden sm:block" />

        {/* Current Tab Title Badge */}
        <div className="hidden sm:flex items-center space-x-2 text-xs font-mono text-slate-300 bg-slate-900/90 px-3 py-1 rounded-lg border border-slate-800">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-status-pulse" />
          <span className="capitalize font-semibold text-slate-200">{activeTab}</span>
        </div>
      </div>

      {/* Middle: Live System Resource Gauges */}
      <div className="hidden md:flex items-center space-x-6 text-xs font-mono">
        <div className="flex items-center space-x-2 text-slate-300 bg-slate-900/60 px-2.5 py-1 rounded-md border border-slate-800/80">
          <Activity className="w-3.5 h-3.5 text-cyan-400" />
          <span className="text-slate-400">PIDs:</span>
          <span className="text-cyan-300 font-semibold">{summary.activeProcesses} Active</span>
        </div>

        <div className="flex items-center space-x-2 text-slate-300 bg-slate-900/60 px-2.5 py-1 rounded-md border border-slate-800/80">
          <Cpu className="w-3.5 h-3.5 text-indigo-400" />
          <span className="text-slate-400">RAM:</span>
          <span className="text-indigo-300 font-semibold">{summary.memoryUsedTotalMb} MB</span>
        </div>

        <div className="flex items-center space-x-2 text-slate-300 bg-slate-900/60 px-2.5 py-1 rounded-md border border-slate-800/80">
          <Zap className="w-3.5 h-3.5 text-amber-400" />
          <span className="text-slate-400">Tokens:</span>
          <span className="text-amber-300 font-semibold">{(summary.totalTokens / 1000).toFixed(1)}k</span>
        </div>

        <div className="flex items-center space-x-2 text-slate-300 bg-slate-900/60 px-2.5 py-1 rounded-md border border-slate-800/80">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span className="text-slate-400">MCP Sandbox:</span>
          <span className="text-emerald-400 font-semibold">Enforced</span>
        </div>
      </div>

      {/* Right: Refresh & Action Buttons */}
      <div className="flex items-center space-x-2">
        <button
          onClick={onRefresh}
          disabled={loading}
          className="p-2 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-cyan-400 transition-colors cursor-pointer flex items-center justify-center text-xs space-x-1.5"
          title="Refresh AIOS System Telemetry"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-cyan-400' : ''}`} />
          <span className="hidden lg:inline text-[11px] font-mono">Sync Kernel</span>
        </button>

        <button
          onClick={() => setActiveTab('chat')}
          className="px-3 py-1.5 rounded-lg bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white font-medium text-xs shadow-md shadow-cyan-600/20 transition-all cursor-pointer flex items-center space-x-1.5"
        >
          <Terminal className="w-3.5 h-3.5" />
          <span>Launch Chat</span>
        </button>
      </div>
    </header>
  );
}
