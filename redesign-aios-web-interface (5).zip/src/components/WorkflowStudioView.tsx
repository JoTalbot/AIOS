'use client';

import React, { useState } from 'react';
import {
  GitFork,
  Play,
  Plus,
  CheckCircle2,
  Clock,
  ArrowRight,
  Sparkles,
  Layers,
  Trash2
} from 'lucide-react';

interface WorkflowStudioViewProps {
  workflows: any[];
  onTriggerWorkflow: (wfId: number) => void;
  onCreateWorkflow: (wfData: any) => void;
  onDeleteWorkflow: (wfId: number) => void;
}

export default function WorkflowStudioView({
  workflows,
  onTriggerWorkflow,
  onCreateWorkflow,
  onDeleteWorkflow,
}: WorkflowStudioViewProps) {
  const [runningWfId, setRunningWfId] = useState<number | null>(null);
  const [modalOpen, setModalOpen] = useState(false);

  const [formData, setFormData] = useState({
    name: '',
    description: '',
    triggerType: 'manual',
    stepsText: 'Code Architect -> Security Audit -> Report Generator'
  });

  const handleRun = async (wfId: number) => {
    setRunningWfId(wfId);
    await onTriggerWorkflow(wfId);
    setTimeout(() => setRunningWfId(null), 1500);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const rawSteps = formData.stepsText.split('->').map((s, idx) => ({
      stepNumber: idx + 1,
      title: s.trim(),
      agentSlug: 'code-architect',
      action: `Execute step: ${s.trim()}`
    }));

    onCreateWorkflow({
      name: formData.name,
      description: formData.description,
      triggerType: formData.triggerType,
      steps: rawSteps,
    });

    setModalOpen(false);
    setFormData({
      name: '',
      description: '',
      triggerType: 'manual',
      stepsText: 'Code Architect -> Security Audit -> Report Generator'
    });
  };

  return (
    <div className="p-4 lg:p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight flex items-center space-x-2">
            <GitFork className="w-5 h-5 text-cyan-400" />
            <span>Workflow & Pipeline Automation Studio</span>
          </h1>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Chain multi-agent steps, tool calls, and event triggers into autonomous background execution flows.
          </p>
        </div>

        <button
          onClick={() => setModalOpen(true)}
          className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold flex items-center space-x-2 shadow-lg shadow-cyan-600/20 transition-all cursor-pointer shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Create Workflow</span>
        </button>
      </div>

      {/* Workflows List */}
      <div className="space-y-6">
        {workflows.map((wf) => {
          const isRunning = runningWfId === wf.id;

          return (
            <div
              key={wf.id}
              className="glass-panel p-6 rounded-2xl border border-slate-800 space-y-4 hover:border-cyan-800/60 transition-all"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="space-y-1">
                  <div className="flex items-center space-x-3">
                    <h3 className="text-base font-bold text-white">{wf.name}</h3>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800 uppercase">
                      Trigger: {wf.triggerType}
                    </span>
                  </div>
                  <p className="text-xs text-slate-300">{wf.description}</p>
                </div>

                <div className="flex items-center space-x-3 shrink-0">
                  <button
                    onClick={() => handleRun(wf.id)}
                    disabled={isRunning}
                    className="px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 disabled:opacity-50 text-white text-xs font-mono font-bold flex items-center space-x-2 shadow-lg transition-all cursor-pointer"
                  >
                    <Play className={`w-3.5 h-3.5 ${isRunning ? 'animate-spin' : ''}`} />
                    <span>{isRunning ? 'Running Flow...' : 'Run Pipeline'}</span>
                  </button>

                  <button
                    onClick={() => onDeleteWorkflow(wf.id)}
                    className="text-slate-600 hover:text-rose-400 transition-colors p-2 cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Step Sequence Cards Flow */}
              <div className="pt-3 border-t border-slate-800/80">
                <span className="text-[10px] font-mono text-slate-400 block mb-3">Automated Execution Sequence:</span>

                <div className="flex flex-col md:flex-row items-stretch md:items-center gap-3 overflow-x-auto pb-2">
                  {Array.isArray(wf.steps) && wf.steps.map((step: any, idx: number) => (
                    <React.Fragment key={idx}>
                      <div className="glass-panel p-3.5 rounded-xl border border-slate-800 bg-slate-900/80 min-w-48 flex-1 space-y-1.5">
                        <div className="flex items-center justify-between font-mono text-[10px]">
                          <span className="text-cyan-400 font-bold">STEP #{step.stepNumber || idx + 1}</span>
                          <span className="text-slate-500">{step.agentSlug || 'agent'}</span>
                        </div>
                        <p className="text-xs font-semibold text-slate-200">{step.title}</p>
                        <p className="text-[11px] text-slate-400 font-mono leading-tight">{step.action}</p>
                      </div>

                      {idx < wf.steps.length - 1 && (
                        <ArrowRight className="w-5 h-5 text-slate-600 shrink-0 self-center hidden md:block" />
                      )}
                    </React.Fragment>
                  ))}
                </div>
              </div>

              {/* Stats Footer */}
              <div className="flex items-center space-x-4 text-[10px] font-mono text-slate-500 pt-2">
                <span>Total Execution Runs: <strong className="text-slate-300">{wf.runCount || 0}</strong></span>
                <span>•</span>
                <span>Last Triggered: <strong className="text-slate-300">{wf.lastRunAt ? new Date(wf.lastRunAt).toLocaleString() : 'Never'}</strong></span>
              </div>
            </div>
          );
        })}

        {workflows.length === 0 && (
          <div className="py-12 text-center text-slate-500 font-mono space-y-2">
            <GitFork className="w-10 h-10 mx-auto text-slate-600" />
            <p>No automated workflows configured.</p>
          </div>
        )}
      </div>

      {/* Modal: Create Workflow */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="glass-panel p-6 rounded-2xl border border-slate-800 w-full max-w-md space-y-4">
            <h2 className="text-base font-bold text-white flex items-center space-x-2">
              <GitFork className="w-5 h-5 text-cyan-400" />
              <span>Create Automated Workflow Pipeline</span>
            </h2>

            <form onSubmit={handleFormSubmit} className="space-y-3 font-mono text-xs">
              <div>
                <label className="block text-slate-300 mb-1">Workflow Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Daily Data & Code Audit Pipeline"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 focus:border-cyan-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Description *</label>
                <input
                  type="text"
                  required
                  placeholder="Purpose of pipeline..."
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 focus:border-cyan-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Trigger Mechanism</label>
                <select
                  value={formData.triggerType}
                  onChange={(e) => setFormData({ ...formData, triggerType: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 focus:border-cyan-500 focus:outline-none"
                >
                  <option value="manual">Manual Execution</option>
                  <option value="cron">Cron Schedule (Nightly)</option>
                  <option value="event">Event Bus Hook</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Step Sequence (Separated by '-&gt;') *</label>
                <textarea
                  rows={3}
                  required
                  placeholder="Code Architect -> Security Audit -> Report Generator"
                  value={formData.stepsText}
                  onChange={(e) => setFormData({ ...formData, stepsText: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 focus:border-cyan-500 focus:outline-none font-mono"
                />
              </div>

              <div className="flex items-center justify-end space-x-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-900 text-slate-400 hover:text-slate-200 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold shadow-lg cursor-pointer"
                >
                  Create Pipeline
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
