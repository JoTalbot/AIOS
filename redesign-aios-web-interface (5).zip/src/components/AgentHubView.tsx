'use client';

import React, { useState } from 'react';
import {
  Bot,
  Search,
  Plus,
  Terminal,
  Cpu,
  Zap,
  Sliders,
  Sparkles,
  Wrench,
  CheckCircle2,
  Settings2,
  Trash2
} from 'lucide-react';

interface AgentHubViewProps {
  agents: any[];
  tools: any[];
  onCreateAgent: (agentData: any) => void;
  onDeleteAgent: (agentId: number) => void;
  onLaunchChat: (agentId: number) => void;
  onSpawnProcess: (agentId: number) => void;
}

export default function AgentHubView({
  agents,
  tools,
  onCreateAgent,
  onDeleteAgent,
  onLaunchChat,
  onSpawnProcess,
}: AgentHubViewProps) {
  const [activeCategory, setActiveCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [modalOpen, setModalOpen] = useState(false);

  // New Agent Form State
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    category: 'coding',
    avatar: '🤖',
    systemPrompt: '',
    model: 'gpt-4o',
    provider: 'openai',
    temperature: 0.7,
    maxTokens: 4096,
    priority: 'medium',
    memoryLimitMb: 512,
    selectedTools: [] as string[],
  });

  const categories = [
    { id: 'all', label: 'All Agents' },
    { id: 'coding', label: 'Coding & Dev' },
    { id: 'research', label: 'Web Research' },
    { id: 'analytics', label: 'Data & SQL' },
    { id: 'automation', label: 'Automation' },
    { id: 'security', label: 'Security Audit' },
    { id: 'system', label: 'Kernel System' },
  ];

  const filteredAgents = agents.filter((agent) => {
    const matchesCategory = activeCategory === 'all' || agent.category.toLowerCase() === activeCategory.toLowerCase();
    const matchesSearch = searchQuery === '' ||
      agent.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      agent.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const toggleToolSelection = (toolSlug: string) => {
    setFormData(prev => {
      const exists = prev.selectedTools.includes(toolSlug);
      return {
        ...prev,
        selectedTools: exists
          ? prev.selectedTools.filter(t => t !== toolSlug)
          : [...prev.selectedTools, toolSlug]
      };
    });
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onCreateAgent({
      ...formData,
      tools: formData.selectedTools,
    });
    setModalOpen(false);
    setFormData({
      name: '',
      description: '',
      category: 'coding',
      avatar: '🤖',
      systemPrompt: '',
      model: 'gpt-4o',
      provider: 'openai',
      temperature: 0.7,
      maxTokens: 4096,
      priority: 'medium',
      memoryLimitMb: 512,
      selectedTools: [],
    });
  };

  return (
    <div className="p-4 lg:p-6 space-y-6 max-w-7xl mx-auto">
      {/* Top Header & Search / Add Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight flex items-center space-x-2">
            <Bot className="w-5 h-5 text-cyan-400" />
            <span>AIOS AgentHub & Agent Marketplace</span>
          </h1>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Configure system prompts, LLM gateway models, tool capabilities, and memory limits.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search agents or capabilities..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9 pr-4 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs font-mono text-slate-200 focus:border-cyan-500 focus:outline-none w-64"
            />
          </div>

          <button
            onClick={() => setModalOpen(true)}
            className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold flex items-center space-x-2 shadow-lg shadow-cyan-600/20 transition-all cursor-pointer shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>Create Agent</span>
          </button>
        </div>
      </div>

      {/* Category Pills Bar */}
      <div className="flex items-center space-x-2 overflow-x-auto pb-1 scrollbar-none">
        {categories.map((cat) => (
          <button
            key={cat.id}
            onClick={() => setActiveCategory(cat.id)}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-mono transition-all cursor-pointer shrink-0 border ${
              activeCategory === cat.id
                ? 'bg-cyan-950/80 text-cyan-300 border-cyan-700/80 shadow-md shadow-cyan-950/30 font-semibold'
                : 'bg-slate-900/60 text-slate-400 border-slate-800 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Agents Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredAgents.map((agent) => (
          <div
            key={agent.id}
            className="glass-panel p-5 rounded-2xl border border-slate-800 hover:border-cyan-800/60 transition-all flex flex-col justify-between group space-y-4"
          >
            {/* Top Row: Avatar, Title, Badges */}
            <div className="space-y-3">
              <div className="flex items-start justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-slate-800 to-slate-900 border border-slate-700 flex items-center justify-center text-2xl shadow-inner group-hover:scale-105 transition-transform">
                    {agent.avatar}
                  </div>
                  <div>
                    <h3 className="font-bold text-base text-white group-hover:text-cyan-300 transition-colors">
                      {agent.name}
                    </h3>
                    <div className="flex items-center space-x-2 mt-0.5">
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700 uppercase">
                        {agent.category}
                      </span>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950/80 text-cyan-300 border border-cyan-800">
                        {agent.model}
                      </span>
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => onDeleteAgent(agent.id)}
                  className="text-slate-600 hover:text-rose-400 transition-colors p-1 cursor-pointer"
                  title="Remove Agent"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>

              <p className="text-xs text-slate-300 line-clamp-2 leading-relaxed font-sans">
                {agent.description}
              </p>
            </div>

            {/* Agent Telemetry & Tool list */}
            <div className="space-y-3 border-t border-slate-800/80 pt-3">
              <div className="grid grid-cols-3 gap-2 text-[11px] font-mono bg-slate-900/50 p-2.5 rounded-xl border border-slate-800">
                <div>
                  <span className="text-slate-500 block text-[9px]">LLM Provider</span>
                  <span className="text-slate-200 font-semibold uppercase">{agent.provider}</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[9px]">RAM Limit</span>
                  <span className="text-indigo-300 font-semibold">{agent.memoryLimitMb} MB</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[9px]">Executions</span>
                  <span className="text-amber-300 font-semibold">{agent.totalExecutions || 0}</span>
                </div>
              </div>

              {/* Tools Badges */}
              <div>
                <span className="text-[10px] text-slate-400 font-mono block mb-1.5">Enabled Tools:</span>
                <div className="flex flex-wrap gap-1">
                  {Array.isArray(agent.tools) && agent.tools.length > 0 ? (
                    agent.tools.map((tSlug: string) => (
                      <span key={tSlug} className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-slate-900 text-slate-300 border border-slate-800 flex items-center space-x-1">
                        <Wrench className="w-2.5 h-2.5 text-cyan-400" />
                        <span>{tSlug}</span>
                      </span>
                    ))
                  ) : (
                    <span className="text-[10px] text-slate-500 font-mono">No tools assigned</span>
                  )}
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="grid grid-cols-2 gap-2 pt-2">
              <button
                onClick={() => onLaunchChat(agent.id)}
                className="py-2 px-3 rounded-xl bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white font-medium text-xs flex items-center justify-center space-x-1.5 shadow-md transition-all cursor-pointer"
              >
                <Terminal className="w-3.5 h-3.5" />
                <span>Launch Chat</span>
              </button>

              <button
                onClick={() => onSpawnProcess(agent.id)}
                className="py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-medium text-xs flex items-center justify-center space-x-1.5 transition-all cursor-pointer"
              >
                <Cpu className="w-3.5 h-3.5 text-emerald-400" />
                <span>Spawn PID</span>
              </button>
            </div>
          </div>
        ))}

        {filteredAgents.length === 0 && (
          <div className="col-span-full py-12 text-center text-slate-500 font-mono space-y-2">
            <Bot className="w-10 h-10 mx-auto text-slate-600" />
            <p>No agents match the filter query.</p>
          </div>
        )}
      </div>

      {/* Modal: Create Custom Agent */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="glass-panel p-6 rounded-2xl border border-slate-800 w-full max-w-2xl space-y-5 my-8">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-bold text-white flex items-center space-x-2">
                <Sparkles className="w-5 h-5 text-cyan-400" />
                <span>Configure & Register New AIOS Agent</span>
              </h2>
              <button
                onClick={() => setModalOpen(false)}
                className="text-slate-400 hover:text-slate-200 cursor-pointer font-mono text-sm"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleFormSubmit} className="space-y-4 font-mono text-xs">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-300 mb-1">Avatar Emoji</label>
                  <input
                    type="text"
                    value={formData.avatar}
                    onChange={(e) => setFormData({ ...formData, avatar: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 text-center text-lg focus:border-cyan-500 focus:outline-none"
                  />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-slate-300 mb-1">Agent Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g., Code Refactorer & Sentinel"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 focus:border-cyan-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Description *</label>
                <input
                  type="text"
                  required
                  placeholder="Short role description..."
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 focus:border-cyan-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-300 mb-1">Category</label>
                  <select
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 focus:border-cyan-500 focus:outline-none"
                  >
                    <option value="coding">Coding & Dev</option>
                    <option value="research">Web Research</option>
                    <option value="analytics">Data & SQL</option>
                    <option value="automation">Automation</option>
                    <option value="security">Security Audit</option>
                    <option value="system">Kernel System</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 mb-1">LLM Model</label>
                  <select
                    value={formData.model}
                    onChange={(e) => setFormData({ ...formData, model: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 focus:border-cyan-500 focus:outline-none"
                  >
                    <option value="gpt-4o">gpt-4o (OpenAI)</option>
                    <option value="claude-3.5-sonnet">claude-3.5-sonnet (Anthropic)</option>
                    <option value="deepseek-r1">deepseek-r1 (DeepSeek)</option>
                    <option value="llama-3.3-70b">llama-3.3-70b (Groq)</option>
                    <option value="qwen2.5-coder">qwen2.5-coder (Ollama Local)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 mb-1">RAM Limit (MB)</label>
                  <input
                    type="number"
                    value={formData.memoryLimitMb}
                    onChange={(e) => setFormData({ ...formData, memoryLimitMb: Number(e.target.value) })}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 focus:border-cyan-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 mb-1">System Prompt *</label>
                <textarea
                  rows={3}
                  required
                  placeholder="You are an autonomous AI agent..."
                  value={formData.systemPrompt}
                  onChange={(e) => setFormData({ ...formData, systemPrompt: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 focus:border-cyan-500 focus:outline-none font-mono"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-2">Allowed Capabilities & MCP Tools</label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {tools.map((t) => {
                    const selected = formData.selectedTools.includes(t.slug);
                    return (
                      <button
                        type="button"
                        key={t.id}
                        onClick={() => toggleToolSelection(t.slug)}
                        className={`p-2 rounded-xl text-left border flex items-center space-x-2 transition-all cursor-pointer ${
                          selected
                            ? 'bg-cyan-950 text-cyan-300 border-cyan-600'
                            : 'bg-slate-900 text-slate-400 border-slate-800 hover:border-slate-700'
                        }`}
                      >
                        <CheckCircle2 className={`w-3.5 h-3.5 shrink-0 ${selected ? 'text-cyan-400' : 'text-slate-600'}`} />
                        <span className="truncate">{t.name}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="flex items-center justify-end space-x-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-900 text-slate-400 hover:text-slate-200 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold shadow-lg shadow-cyan-600/20 cursor-pointer"
                >
                  Save Agent
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
