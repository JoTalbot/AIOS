import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { agents } from '@/db/schema';
import { eq } from 'drizzle-orm';

export async function GET(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const agentId = parseInt(id, 10);
    if (isNaN(agentId)) {
      return NextResponse.json({ success: false, error: 'Invalid agent ID' }, { status: 400 });
    }

    const [agent] = await db.select().from(agents).where(eq(agents.id, agentId)).limit(1);
    if (!agent) {
      return NextResponse.json({ success: false, error: 'Agent not found' }, { status: 404 });
    }

    return NextResponse.json({ success: true, data: agent });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error?.message || 'Error fetching agent' }, { status: 500 });
  }
}

export async function PUT(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const agentId = parseInt(id, 10);
    if (isNaN(agentId)) {
      return NextResponse.json({ success: false, error: 'Invalid agent ID' }, { status: 400 });
    }

    const body = await request.json();
    const updated = await db.update(agents)
      .set({
        ...body,
        updatedAt: new Date(),
      })
      .where(eq(agents.id, agentId))
      .returning();

    if (!updated || updated.length === 0) {
      return NextResponse.json({ success: false, error: 'Agent not found' }, { status: 404 });
    }

    return NextResponse.json({ success: true, data: updated[0] });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error?.message || 'Error updating agent' }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const agentId = parseInt(id, 10);
    if (isNaN(agentId)) {
      return NextResponse.json({ success: false, error: 'Invalid agent ID' }, { status: 400 });
    }

    await db.delete(agents).where(eq(agents.id, agentId));
    return NextResponse.json({ success: true, message: 'Agent deleted successfully' });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error?.message || 'Error deleting agent' }, { status: 500 });
  }
}
