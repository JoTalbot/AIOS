import { useEffect, useState } from "react";
import { ServerCog, Cpu, MemoryStick, Power, RotateCw, Play, Square, Activity, Clock } from "lucide-react";
import { Card, PanelHeader, Progress, IconButton, StatusPill } from "../components/ui/primitives";
import { SERVICES } from "../data/mockData";
import { cn } from "../utils/cn";
import type { ServiceInfo, ServiceState } from "../types";

function clamp(v: number, min: number, max: number) {
  return Math.max(min, Math.min(max, v));
}

export function Services() {
  const [services, setServices] = useState<ServiceInfo[]>(SERVICES.map((s) => ({ ...s })));
  const [busy, setBusy] = useState<Record<string, boolean>>({});

  useEffect(() => {
    const id = setInterval(() => {
      setServices((prev) =>
        prev.map((s) =>
          s.active
            ? { ...s, cpu: Math.round(clamp(s.cpu + (Math.random() - 0.5) * 8, 1, 60)), mem: Math.round(clamp(s.mem + (Math.random() - 0.5) * 18, 40, 700)) }
            : s
        )
      );
    }, 2500);
    return () => clearInterval(id);
  }, []);

  const update = (name: string, patch: Partial<ServiceInfo>) =>
    setServices((prev) => prev.map((s) => (s.name === name ? { ...s, ...patch } : s)));

  const act = (name: string, action: "start" | "stop" | "restart") => {
    setBusy((b) => ({ ...b, [name]: true }));
    if (action === "stop") {
      update(name, { active: false, state: "inactive", cpu: 0, mem: 0, since: new Date().toISOString() });
    } else if (action === "start") {
      update(name, { active: true, state: "activating", cpu: 14, mem: 80, since: new Date().toISOString() });
      setTimeout(() => update(name, { state: "active" }), 1200);
    } else {
      update(name, { state: "activating", active: false, cpu: 0, mem: 0 });
      setTimeout(() => update(name, { active: true, state: "active", cpu: 16, mem: 90, since: new Date().toISOString() }), 1300);
    }
    setTimeout(() => setBusy((b) => ({ ...b, [name]: false })), 1400);
  };

  const active = services.filter((s) => s.active).length;
  const totalCpu = services.reduce((a, s) => a + s.cpu, 0);
  const totalMem = services.reduce((a, s) => a + s.mem, 0);

  const stateTone: Record<ServiceState, any> = { active: "emerald", activating: "amber", failed: "rose", inactive: "slate" };

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {[
          { label: "Services", value: services.length, icon: ServerCog, tone: "indigo" },
          { label: "Active", value: `${active}/${services.length}`, icon: Activity, tone: "emerald" },
          { label: "Total CPU", value: `${totalCpu}%`, icon: Cpu, tone: "amber" },
          { label: "Memory", value: `${(totalMem / 1024).toFixed(1)} GB`, icon: MemoryStick, tone: "cyan" },
        ].map((s) => (
          <Card key={s.label} className="flex items-center gap-3 p-4">
            <div className={`grid h-10 w-10 place-items-center rounded-xl bg-${s.tone}-500/10 text-${s.tone}-300`}>
              <s.icon className="h-5 w-5" />
            </div>
            <div>
              <div className="text-xl font-extrabold tabular text-white">{s.value}</div>
              <div className="text-[11px] uppercase tracking-wide text-slate-500">{s.label}</div>
            </div>
          </Card>
        ))}
      </div>

      <Card>
        <PanelHeader
          icon={<ServerCog className="h-[18px] w-[18px]" />}
          title="System Services"
          subtitle="systemd units · start / stop / restart"
          action={
            <button
              onClick={() => services.forEach((s) => act(s.name, "restart"))}
              className="inline-flex items-center gap-1.5 rounded-lg bg-indigo-500/90 px-3 py-1.5 text-xs font-semibold text-white hover:bg-indigo-500"
            >
              <RotateCw className="h-3.5 w-3.5" /> Restart all
            </button>
          }
        />
        <div className="space-y-2">
          {/* Header row (desktop) */}
          <div className="hidden grid-cols-12 gap-3 px-4 text-[10px] font-semibold uppercase tracking-wide text-slate-500 md:grid">
            <div className="col-span-4">Service</div>
            <div className="col-span-1">Port</div>
            <div className="col-span-2">Status</div>
            <div className="col-span-2">CPU</div>
            <div className="col-span-1">Mem</div>
            <div className="col-span-2 text-right">Actions</div>
          </div>
          {services.map((s) => (
            <div key={s.name} className="grid grid-cols-2 items-center gap-3 rounded-xl bg-white/[0.02] p-3 ring-1 ring-inset ring-white/[0.04] md:grid-cols-12 md:px-4">
              <div className="col-span-2 md:col-span-4">
                <div className="flex items-center gap-2.5">
                  <div className={cn("grid h-8 w-8 place-items-center rounded-lg", s.active ? "bg-emerald-500/10 text-emerald-300" : "bg-slate-500/10 text-slate-400")}>
                    {busy[s.name] ? <RotateCw className="h-4 w-4 spin-slow" /> : <Power className="h-4 w-4" />}
                  </div>
                  <div className="min-w-0">
                    <div className="truncate text-sm font-semibold text-slate-100">{s.label}</div>
                    <div className="truncate font-mono text-[10px] text-slate-500">{s.name} · <span className="inline-flex items-center gap-0.5"><Clock className="h-2.5 w-2.5" />{s.since.substring(0, 10)}</span></div>
                  </div>
                </div>
              </div>
              <div className="col-span-1 hidden md:block">
                <span className="font-mono text-xs text-slate-400">{s.port ?? "—"}</span>
              </div>
              <div className="col-span-1 md:col-span-2">
                <StatusPill tone={stateTone[s.state]} label={s.state} pulse={s.state === "active"} />
              </div>
              <div className="col-span-1 hidden items-center gap-2 md:col-span-2 md:flex">
                <Progress value={s.cpu} tone={s.cpu > 40 ? "amber" : "indigo"} />
                <span className="w-8 shrink-0 text-right text-[11px] tabular text-slate-400">{s.cpu}%</span>
              </div>
              <div className="col-span-1 hidden md:block">
                <span className="tabular text-xs text-slate-400">{s.mem}MB</span>
              </div>
              <div className="col-span-1 flex items-center justify-end gap-1.5 md:col-span-2">
                <IconButton tone="rose" disabled={!s.active || busy[s.name]} onClick={() => act(s.name, "stop")} title="Stop" className="!h-7 !w-7"><Square className="h-3.5 w-3.5" /></IconButton>
                <IconButton tone="indigo" disabled={busy[s.name]} onClick={() => act(s.name, "restart")} title="Restart" className="!h-7 !w-7"><RotateCw className="h-3.5 w-3.5" /></IconButton>
                <IconButton tone="emerald" disabled={s.active || busy[s.name]} onClick={() => act(s.name, "start")} title="Start" className="!h-7 !w-7"><Play className="h-3.5 w-3.5" /></IconButton>
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
