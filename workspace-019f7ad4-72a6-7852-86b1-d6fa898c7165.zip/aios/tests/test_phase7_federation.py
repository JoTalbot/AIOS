"""Phase 7 — AIOS v4.0.0 Federation & Collective Intelligence Tests

Comprehensive tests covering:
1. `FederationNode` registration and strict constitutional hash verification (`verified_nodes_only`).
2. `FederationManager.synchronize_state` with policy conflict detection and audit logging.
3. Quarantining unverified remote instances.
4. Starlette REST API endpoints `/api/v1/federation/nodes`, `/api/v1/federation/sync`, `/api/v1/federation/stats`.
"""

import pytest
from pathlib import Path
from httpx import AsyncClient, ASGITransport

from aios_core.storage import Database
from aios_core.audit_logger import AuditLogger
from aios_core.constitution_engine import ConstitutionEngine
from aios_core.federation import FederationManager, NodeStatus, SyncReport


CONSTITUTION_DIR = str(Path(__file__).parent.parent / "docs" / "constitution")
POLICIES_DIR = str(Path(__file__).parent.parent / "policies")


# ============================================================
# 1. Federation Manager Core Tests
# ============================================================

class TestFederationManager:
    def test_init_and_stats(self):
        db = Database(":memory:")
        fed = FederationManager(db=db, local_node_id="test-master")
        stats = fed.stats()
        assert stats["version"] == "4.0.0"
        assert stats["total_nodes"] == 0

    def test_register_verified_node(self):
        db = Database(":memory:")
        audit = AuditLogger(db=db)
        const = ConstitutionEngine(CONSTITUTION_DIR, POLICIES_DIR)
        fed = FederationManager(db=db, audit_logger=audit, constitution_engine=const)

        local_hash = fed.compute_constitution_hash()
        node = fed.register_node(
            name="AIOS-Worker-1",
            endpoint="http://worker1.aios.internal:8000",
            public_key="ed25519_worker_1_pk",
            constitution_hash=local_hash,
        )
        assert node.verified is True
        assert node.status == NodeStatus.ONLINE
        assert fed.stats()["verified_nodes"] == 1

    def test_register_unverified_node_quarantined(self):
        fed = FederationManager()
        node = fed.register_node(
            name="Rogue-AIOS-Node",
            endpoint="http://rogue.aios.external:8000",
            public_key="ed25519_rogue_pk",
            constitution_hash="sha256:fake_altered_constitution",
        )
        assert node.verified is False
        assert node.status == NodeStatus.QUARANTINED

    def test_synchronize_clean_state(self):
        fed = FederationManager()
        node = fed.register_node(
            name="AIOS-Peer-Node",
            endpoint="http://peer.aios:8000",
            public_key="pk_peer",
            constitution_hash="sha256:c0n5t1t4t10n_v3",
        )
        report = fed.synchronize_state(
            node.id,
            remote_policies={"security_policy": "2.1.1", "federation_policy": "2.1.1"},
        )
        assert report.conflicts_detected == 0
        assert report.policies_synchronized == 2
        assert report.status == "synchronized"
        assert node.status == NodeStatus.ONLINE

    def test_synchronize_policy_conflict_detected(self):
        fed = FederationManager()
        node = fed.register_node(
            name="AIOS-Outdated-Peer",
            endpoint="http://outdated.aios:8000",
            public_key="pk_outdated",
            constitution_hash="sha256:c0n5t1t4t10n_v3",
        )
        # Remote peer sends mismatched altered version 1.0.0
        report = fed.synchronize_state(
            node.id,
            remote_policies={"security_policy": "1.0.0_altered", "federation_policy": "2.1.1"},
        )
        assert report.conflicts_detected == 1
        assert report.policies_synchronized == 1
        assert report.status == "conflict_review"
        assert node.status == NodeStatus.QUARANTINED

    def test_synchronize_unverified_node_denied(self):
        fed = FederationManager()
        node = fed.register_node(
            name="Unverified-Peer",
            endpoint="http://unverified:8000",
            public_key="pk_unv",
            constitution_hash="sha256:altered",
        )
        report = fed.synchronize_state(node.id, remote_policies={"security_policy": "2.1.1"})
        assert report.status == "denied_unverified_node"
        assert report.conflicts_detected == 1


# ============================================================
# 2. Federation REST API Tests
# ============================================================

@pytest.fixture
def app():
    from aios_core.api.app import create_app
    return create_app(
        db_path=":memory:",
        constitution_dir=CONSTITUTION_DIR,
        policies_dir=POLICIES_DIR,
    )


@pytest.fixture
async def client(app):
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as c:
        yield c


@pytest.mark.asyncio
class TestFederationRESTAPI:
    async def test_federation_node_registration_and_list(self, client):
        payload = {
            "name": "Cluster-Node-Alpha",
            "endpoint": "http://node-alpha.aios.net:8000",
            "public_key": "pk_alpha_ed25519",
            "constitution_hash": "sha256:c0n5t1t4t10n_v3",
        }
        resp_reg = await client.post("/api/v1/federation/nodes", json=payload)
        assert resp_reg.status_code == 201
        node = resp_reg.json()
        assert node["verified"] is True
        node_id = node["id"]

        # List all nodes
        resp_list = await client.get("/api/v1/federation/nodes")
        assert resp_list.status_code == 200
        nodes_list = resp_list.json()["nodes"]
        assert len(nodes_list) == 1
        assert nodes_list[0]["id"] == node_id

        # List verified only
        resp_list_ver = await client.get("/api/v1/federation/nodes?verified_only=true")
        assert len(resp_list_ver.json()["nodes"]) == 1

    async def test_federation_sync_endpoint(self, client):
        # Register node
        reg = await client.post("/api/v1/federation/nodes", json={
            "name": "Sync-Test-Node",
            "endpoint": "http://sync-node:8000",
            "constitution_hash": "sha256:c0n5t1t4t10n_v3",
        })
        node_id = reg.json()["id"]

        # Run sync
        sync_payload = {
            "remote_policies": {"security_policy": "2.1.1", "evolution_policy": "2.1.1"}
        }
        resp_sync = await client.post(f"/api/v1/federation/sync/{node_id}", json=sync_payload)
        assert resp_sync.status_code == 200
        report = resp_sync.json()
        assert report["status"] == "synchronized"
        assert report["conflicts_detected"] == 0

    async def test_federation_stats_endpoint(self, client):
        resp_stats = await client.get("/api/v1/federation/stats")
        assert resp_stats.status_code == 200
        data = resp_stats.json()
        assert data["version"] == "4.0.0"
        assert "total_nodes" in data
